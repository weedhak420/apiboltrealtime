"use client"

import { useState, useEffect } from "react"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Skeleton } from "@/components/ui/skeleton"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { RefreshCw, Activity, Database, Users, Zap, Clock, TrendingUp } from "lucide-react"
import { fetchPerformance } from "@/lib/api"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from "recharts"

interface PerformanceData {
  goroutine_count?: number
  cache_size?: number
  rate_limit_size?: number
  enhanced_rate_limiter?: {
    requests_per_minute?: number
    current_requests?: number
  }
  worker_pool?: {
    active_workers?: number
    queued_tasks?: number
  }
  database?: {
    connected?: boolean
    total_vehicles?: number
  }
  redis?: {
    connected?: boolean
    status?: string
  }
  analytics_worker?: {
    running?: boolean
    status?: string
  }
  system?: {
    status?: string
    uptime?: string
    version?: string
  }
  timestamp?: string
}

export default function PerformancePage() {
  const [performance, setPerformance] = useState<PerformanceData | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null)
  const [performanceHistory, setPerformanceHistory] = useState<Array<PerformanceData & { timestamp: string }>>([])

  const fetchPerformanceData = async () => {
    try {
      setLoading(true)
      setError(null)
      const data = await fetchPerformance()
      
      // Validate and set performance data with fallbacks
      setPerformance({
        goroutine_count: data.goroutine_count || 0,
        cache_size: data.cache_size || 0,
        rate_limit_size: data.rate_limit_size || 0,
        enhanced_rate_limiter: {
          requests_per_minute: data.enhanced_rate_limiter?.requests_per_minute || 0,
          current_requests: data.enhanced_rate_limiter?.current_requests || 0
        },
        worker_pool: {
          active_workers: data.worker_pool?.active_workers || 0,
          queued_tasks: data.worker_pool?.queued_tasks || 0
        },
        timestamp: data.timestamp || new Date().toISOString()
      })
      
      setLastUpdate(new Date())
      
      // Add to history (keep last 20 entries)
      setPerformanceHistory(prev => {
        const newHistory = [...prev, { 
          ...data, 
          timestamp: new Date().toISOString() 
        }]
        return newHistory.slice(-20)
      })
    } catch (err) {
      console.error('[PerformancePage] Failed to fetch performance data:', err)
      setError(err instanceof Error ? err.message : 'Failed to fetch performance data')
      
      // Set fallback data instead of clearing
      setPerformance({
        goroutine_count: 0,
        cache_size: 0,
        rate_limit_size: 0,
        enhanced_rate_limiter: {
          requests_per_minute: 0,
          current_requests: 0
        },
        worker_pool: {
          active_workers: 0,
          queued_tasks: 0
        },
        database: {
          connected: false,
          total_vehicles: 0
        },
        redis: {
          connected: false,
          status: 'disconnected'
        },
        analytics_worker: {
          running: false,
          status: 'stopped'
        },
        system: {
          status: 'error',
          uptime: '0s',
          version: '1.0.0'
        },
        timestamp: new Date().toISOString()
      })
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchPerformanceData()
    const interval = setInterval(fetchPerformanceData, 15000) // Refresh every 15 seconds
    return () => clearInterval(interval)
  }, [])

  const getPerformanceLevel = (value: number, thresholds: { low: number; medium: number; high: number }) => {
    if (value <= thresholds.low) return { level: 'low', color: 'text-green-500', bg: 'bg-green-50 dark:bg-green-950/20' }
    if (value <= thresholds.medium) return { level: 'medium', color: 'text-yellow-500', bg: 'bg-yellow-50 dark:bg-yellow-950/20' }
    return { level: 'high', color: 'text-red-500', bg: 'bg-red-50 dark:bg-red-950/20' }
  }

  const formatTimeLabel = (timestamp: string) => {
    return new Date(timestamp).toLocaleTimeString('th-TH', { 
      hour: '2-digit', 
      minute: '2-digit',
      second: '2-digit'
    })
  }

  if (loading && !performance) {
    return (
      <DashboardLayout>
        <div className="flex flex-col gap-6">
          <div>
            <h1 className="text-3xl font-bold tracking-tight text-balance">Performance Metrics</h1>
            <p className="text-muted-foreground mt-1">System performance monitoring and analytics</p>
          </div>
          <div className="grid gap-6">
            <Card>
              <CardHeader>
                <Skeleton className="h-6 w-32" />
                <Skeleton className="h-4 w-48" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-32 w-full" />
              </CardContent>
            </Card>
          </div>
        </div>
      </DashboardLayout>
    )
  }

  return (
    <DashboardLayout>
      <div className="flex flex-col gap-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight text-balance">Performance Metrics</h1>
            <p className="text-muted-foreground mt-1">System performance monitoring and analytics</p>
          </div>
          <div className="flex items-center gap-2">
            {lastUpdate && (
              <span className="text-sm text-muted-foreground">
                Last updated: {lastUpdate.toLocaleTimeString()}
              </span>
            )}
            <Button onClick={fetchPerformanceData} disabled={loading} size="sm">
              <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
              Refresh
            </Button>
          </div>
        </div>

        {error && (
          <Alert variant="destructive">
            <Activity className="h-4 w-4" />
            <AlertDescription>
              {error}
            </AlertDescription>
          </Alert>
        )}

        {performance ? (
          <>
            {/* Key Metrics */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center gap-2">
                    <Activity className="h-4 w-4 text-primary" />
                    <div>
                      <div className="text-2xl font-bold">{performance.goroutine_count || 'N/A'}</div>
                      <div className="text-sm text-muted-foreground">Goroutines</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center gap-2">
                    <Database className="h-4 w-4 text-green-500" />
                    <div>
                      <div className="text-2xl font-bold">{performance.cache_size || 'N/A'}</div>
                      <div className="text-sm text-muted-foreground">Cache Size</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center gap-2">
                    <Users className="h-4 w-4 text-blue-500" />
                    <div>
                      <div className="text-2xl font-bold">{performance.worker_pool?.active_workers || 'N/A'}</div>
                      <div className="text-sm text-muted-foreground">Active Workers</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center gap-2">
                    <Zap className="h-4 w-4 text-orange-500" />
                    <div>
                      <div className="text-2xl font-bold">{performance.rate_limit_size}</div>
                      <div className="text-sm text-muted-foreground">Rate Limit Queue</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Performance Charts */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Goroutine Trend */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Activity className="h-5 w-5" />
                    Goroutine Count Trend
                  </CardTitle>
                  <CardDescription>
                    Goroutine count over time
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {performanceHistory.length > 1 ? (
                    <div className="h-[250px] w-full">
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart data={performanceHistory}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis 
                            dataKey="timestamp" 
                            tickFormatter={formatTimeLabel}
                            tick={{ fontSize: 10 }}
                          />
                          <YAxis tick={{ fontSize: 12 }} />
                          <Tooltip 
                            labelFormatter={(value) => `Time: ${formatTimeLabel(value)}`}
                            formatter={(value) => [value, 'Goroutines']}
                          />
                          <Line 
                            type="monotone" 
                            dataKey="goroutine_count" 
                            stroke="#3b82f6" 
                            strokeWidth={2}
                            dot={{ r: 4 }}
                          />
                        </LineChart>
                      </ResponsiveContainer>
                    </div>
                  ) : (
                    <div className="h-[250px] flex items-center justify-center text-muted-foreground">
                      Collecting data...
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Cache Size Trend */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Database className="h-5 w-5" />
                    Cache Size Trend
                  </CardTitle>
                  <CardDescription>
                    Cache size over time
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {performanceHistory.length > 1 ? (
                    <div className="h-[250px] w-full">
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart data={performanceHistory}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis 
                            dataKey="timestamp" 
                            tickFormatter={formatTimeLabel}
                            tick={{ fontSize: 10 }}
                          />
                          <YAxis tick={{ fontSize: 12 }} />
                          <Tooltip 
                            labelFormatter={(value) => `Time: ${formatTimeLabel(value)}`}
                            formatter={(value) => [value, 'Cache Size']}
                          />
                          <Line 
                            type="monotone" 
                            dataKey="cache_size" 
                            stroke="#22c55e" 
                            strokeWidth={2}
                            dot={{ r: 4 }}
                          />
                        </LineChart>
                      </ResponsiveContainer>
                    </div>
                  ) : (
                    <div className="h-[250px] flex items-center justify-center text-muted-foreground">
                      Collecting data...
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Detailed Metrics */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Rate Limiter */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Zap className="h-5 w-5" />
                    Rate Limiter
                  </CardTitle>
                  <CardDescription>
                    Request rate limiting and throttling
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">Requests per Minute:</span>
                      <span className="font-medium">{performance.enhanced_rate_limiter?.requests_per_minute || 'N/A'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">Current Requests:</span>
                      <span className="font-medium">{performance.enhanced_rate_limiter?.current_requests || 'N/A'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">Queue Size:</span>
                      <span className="font-medium">{performance.rate_limit_size || 'N/A'}</span>
                    </div>
                    <div className="w-full bg-secondary rounded-full h-2">
                      <div 
                        className="bg-primary h-2 rounded-full transition-all duration-300"
                        style={{ 
                          width: `${performance.enhanced_rate_limiter?.requests_per_minute && performance.enhanced_rate_limiter?.current_requests 
                            ? Math.min((performance.enhanced_rate_limiter.current_requests / performance.enhanced_rate_limiter.requests_per_minute) * 100, 100)
                            : 0}%` 
                        }}
                      ></div>
                    </div>
                    <div className="text-xs text-muted-foreground text-center">
                      {performance.enhanced_rate_limiter?.requests_per_minute && performance.enhanced_rate_limiter?.current_requests
                        ? `${Math.round((performance.enhanced_rate_limiter.current_requests / performance.enhanced_rate_limiter.requests_per_minute) * 100)}% of rate limit used`
                        : 'Rate limit data unavailable'
                      }
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Worker Pool */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Users className="h-5 w-5" />
                    Worker Pool
                  </CardTitle>
                  <CardDescription>
                    Background worker performance
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">Active Workers:</span>
                      <span className="font-medium">{performance.worker_pool?.active_workers || 'N/A'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">Queued Tasks:</span>
                      <span className="font-medium">{performance.worker_pool?.queued_tasks || 'N/A'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">Queue Status:</span>
                      <Badge variant={performance.worker_pool?.queued_tasks && performance.worker_pool.queued_tasks > 0 ? "destructive" : "default"}>
                        {performance.worker_pool?.queued_tasks && performance.worker_pool.queued_tasks > 0 ? "Backlogged" : "Clear"}
                      </Badge>
                    </div>
                    <div className="w-full bg-secondary rounded-full h-2">
                      <div 
                        className="bg-green-500 h-2 rounded-full transition-all duration-300"
                        style={{ 
                          width: `${performance.worker_pool?.active_workers 
                            ? Math.min((performance.worker_pool.active_workers / 10) * 100, 100)
                            : 0}%` 
                        }}
                      ></div>
                    </div>
                    <div className="text-xs text-muted-foreground text-center">
                      Worker utilization
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* System Status */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Database Status */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Database className="h-5 w-5" />
                    Database Status
                  </CardTitle>
                  <CardDescription>
                    Database connection and statistics
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">Connection:</span>
                      <Badge variant={performance.database?.connected ? "default" : "destructive"}>
                        {performance.database?.connected ? "Connected" : "Disconnected"}
                      </Badge>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">Total Vehicles:</span>
                      <span className="font-medium">{performance.database?.total_vehicles || 'N/A'}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Redis Status */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Zap className="h-5 w-5" />
                    Redis Status
                  </CardTitle>
                  <CardDescription>
                    Cache and session storage
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">Connection:</span>
                      <Badge variant={performance.redis?.connected ? "default" : "destructive"}>
                        {performance.redis?.connected ? "Connected" : "Disconnected"}
                      </Badge>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">Status:</span>
                      <span className="font-medium capitalize">{performance.redis?.status || 'Unknown'}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Analytics Worker */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Activity className="h-5 w-5" />
                    Analytics Worker
                  </CardTitle>
                  <CardDescription>
                    Background analytics processing
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">Running:</span>
                      <Badge variant={performance.analytics_worker?.running ? "default" : "destructive"}>
                        {performance.analytics_worker?.running ? "Active" : "Stopped"}
                      </Badge>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">Status:</span>
                      <span className="font-medium capitalize">{performance.analytics_worker?.status || 'Unknown'}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Performance Indicators */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5" />
                  Performance Indicators
                </CardTitle>
                <CardDescription>
                  System performance health indicators
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className={`p-4 rounded-lg border ${getPerformanceLevel(performance.goroutine_count || 0, { low: 5, medium: 10, high: 20 }).bg}`}>
                    <div className="flex items-center gap-2 mb-2">
                      <Activity className="h-4 w-4" />
                      <span className="font-medium">Workers</span>
                    </div>
                    <div className={`text-2xl font-bold ${getPerformanceLevel(performance.goroutine_count || 0, { low: 5, medium: 10, high: 20 }).color}`}>
                      {performance.goroutine_count || 'N/A'}
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {getPerformanceLevel(performance.goroutine_count || 0, { low: 5, medium: 10, high: 20 }).level} load
                    </div>
                  </div>
                  
                  <div className={`p-4 rounded-lg border ${getPerformanceLevel(performance.cache_size || 0, { low: 0, medium: 1, high: 2 }).bg}`}>
                    <div className="flex items-center gap-2 mb-2">
                      <Database className="h-4 w-4" />
                      <span className="font-medium">Cache</span>
                    </div>
                    <div className={`text-2xl font-bold ${getPerformanceLevel(performance.cache_size || 0, { low: 0, medium: 1, high: 2 }).color}`}>
                      {performance.cache_size ? 'Active' : 'Inactive'}
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {performance.cache_size ? 'Connected' : 'Disconnected'}
                    </div>
                  </div>
                  
                  <div className={`p-4 rounded-lg border ${getPerformanceLevel(performance.worker_pool?.queued_tasks || 0, { low: 0, medium: 5, high: 10 }).bg}`}>
                    <div className="flex items-center gap-2 mb-2">
                      <Clock className="h-4 w-4" />
                      <span className="font-medium">Queue</span>
                    </div>
                    <div className={`text-2xl font-bold ${getPerformanceLevel(performance.worker_pool?.queued_tasks || 0, { low: 0, medium: 5, high: 10 }).color}`}>
                      {performance.worker_pool?.queued_tasks || 'N/A'}
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {getPerformanceLevel(performance.worker_pool?.queued_tasks || 0, { low: 0, medium: 5, high: 10 }).level} backlog
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </>
        ) : (
          <div className="text-center py-8">
            <Activity className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
            <p className="text-muted-foreground">No performance data available</p>
          </div>
        )}
      </div>
    </DashboardLayout>
  )
}