"use client"

import { useState, useEffect } from "react"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Skeleton } from "@/components/ui/skeleton"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { RefreshCw, History, Search, Filter, Download, MapPin, Navigation, Clock } from "lucide-react"
import { fetchVehicleHistory } from "@/lib/api"
import { VehicleHistoryRecord } from "@/types/vehicles"

export default function VehicleHistoryPage() {
  const [history, setHistory] = useState<VehicleHistoryRecord[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null)
  
  // Filters
  const [vehicleId, setVehicleId] = useState("")
  const [limit, setLimit] = useState(100)
  const [startTime, setStartTime] = useState("")
  const [endTime, setEndTime] = useState("")

  const fetchHistory = async () => {
    try {
      setLoading(true)
      setError(null)
      
      const params: any = {}
      if (vehicleId) params.vehicle_id = vehicleId
      if (limit) params.limit = limit
      if (startTime) params.start_time = startTime
      if (endTime) params.end_time = endTime
      
      const data = await fetchVehicleHistory(params)
      // Handle both API response formats: {records: [...]} and {data: [...]}
      const historyData = data.records || data.data || []
      setHistory(historyData)
      setLastUpdate(new Date())
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch vehicle history')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchHistory()
  }, [])

  const formatBearing = (bearing: number) => {
    const directions = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW']
    const index = Math.round(bearing / 45) % 8
    return directions[index]
  }

  const getCategoryColor = (category: string) => {
    switch (category?.toLowerCase()) {
      case 'bolt_taxi':
        return 'bg-blue-500'
      case 'taxi':
        return 'bg-green-500'
      case 'send motorbike':
        return 'bg-orange-500'
      case 'basic':
        return 'bg-blue-500'
      case 'comfort':
        return 'bg-green-500'
      case 'premium':
        return 'bg-yellow-500'
      case 'xl':
        return 'bg-purple-500'
      default:
        return 'bg-gray-500'
    }
  }

  const exportToCSV = () => {
    if (history.length === 0) return
    
    const headers = ['Index', 'Vehicle ID', 'Latitude', 'Longitude', 'Bearing', 'Category', 'Timestamp']
    const csvContent = [
      headers.join(','),
      ...history.map((record, index) => [
        index + 1,
        record.vehicle_id || record.id,
        record.lat,
        record.lng,
        record.bearing,
        record.category_name,
        record.timestamp
      ].join(','))
    ].join('\n')
    
    const blob = new Blob([csvContent], { type: 'text/csv' })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `vehicle-history-${new Date().toISOString().split('T')[0]}.csv`
    a.click()
    window.URL.revokeObjectURL(url)
  }

  if (loading && history.length === 0) {
    return (
      <DashboardLayout>
        <div className="flex flex-col gap-6">
          <div>
            <h1 className="text-3xl font-bold tracking-tight text-balance">Vehicle History</h1>
            <p className="text-muted-foreground mt-1">Historical vehicle tracking data and analytics</p>
          </div>
          <div className="grid gap-6">
            <Card>
              <CardHeader>
                <Skeleton className="h-6 w-32" />
                <Skeleton className="h-4 w-48" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-32 w-full" />
              </CardContent>
            </Card>
          </div>
        </div>
      </DashboardLayout>
    )
  }

  return (
    <DashboardLayout>
      <div className="flex flex-col gap-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight text-balance">Vehicle History</h1>
            <p className="text-muted-foreground mt-1">Historical vehicle tracking data and analytics</p>
          </div>
          <div className="flex items-center gap-2">
            {lastUpdate && (
              <span className="text-sm text-muted-foreground">
                Last updated: {lastUpdate.toLocaleTimeString()}
              </span>
            )}
            <Button onClick={fetchHistory} disabled={loading} size="sm">
              <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
              Refresh
            </Button>
            <Button onClick={exportToCSV} disabled={history.length === 0} size="sm" variant="outline">
              <Download className="h-4 w-4 mr-2" />
              Export CSV
            </Button>
          </div>
        </div>

        {error && (
          <Alert variant="destructive">
            <History className="h-4 w-4" />
            <AlertDescription>
              {error}
            </AlertDescription>
          </Alert>
        )}

        {/* Filters */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Filter className="h-5 w-5" />
              Filters
            </CardTitle>
            <CardDescription>
              Filter vehicle history data by various criteria
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="space-y-2">
                <Label htmlFor="vehicle-id">Vehicle ID</Label>
                <Input
                  id="vehicle-id"
                  placeholder="Enter vehicle ID"
                  value={vehicleId}
                  onChange={(e) => setVehicleId(e.target.value)}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="limit">Limit</Label>
                <Select value={limit.toString()} onValueChange={(value) => setLimit(parseInt(value))}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="50">50 records</SelectItem>
                    <SelectItem value="100">100 records</SelectItem>
                    <SelectItem value="250">250 records</SelectItem>
                    <SelectItem value="500">500 records</SelectItem>
                    <SelectItem value="1000">1000 records</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="start-time">Start Time</Label>
                <Input
                  id="start-time"
                  type="datetime-local"
                  value={startTime}
                  onChange={(e) => setStartTime(e.target.value)}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="end-time">End Time</Label>
                <Input
                  id="end-time"
                  type="datetime-local"
                  value={endTime}
                  onChange={(e) => setEndTime(e.target.value)}
                />
              </div>
            </div>
            
            <div className="flex justify-end mt-4">
              <Button onClick={fetchHistory} disabled={loading}>
                <Search className="h-4 w-4 mr-2" />
                Apply Filters
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <History className="h-4 w-4 text-primary" />
                <div>
                  <div className="text-2xl font-bold">{history.length}</div>
                  <div className="text-sm text-muted-foreground">Total Records</div>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <MapPin className="h-4 w-4 text-green-500" />
                <div>
                  <div className="text-2xl font-bold">
                    {new Set(history.map(h => h.vehicle_id || h.id)).size}
                  </div>
                  <div className="text-sm text-muted-foreground">Unique Vehicles</div>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <Navigation className="h-4 w-4 text-blue-500" />
                <div>
                  <div className="text-2xl font-bold">
                    {new Set(history.map(h => h.category_name)).size}
                  </div>
                  <div className="text-sm text-muted-foreground">Categories</div>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4 text-orange-500" />
                <div>
                  <div className="text-2xl font-bold">
                    {history.length > 0 ? 
                      Math.round((Date.now() - new Date(history[0].timestamp || history[0].created_at).getTime()) / (1000 * 60 * 60)) : 0}h
                  </div>
                  <div className="text-sm text-muted-foreground">Data Age</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* History Table */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <History className="h-5 w-5" />
              Vehicle History Records
            </CardTitle>
            <CardDescription>
              Detailed historical tracking data for all vehicles
            </CardDescription>
          </CardHeader>
          <CardContent>
            {history.length > 0 ? (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Index</TableHead>
                      <TableHead>Vehicle ID</TableHead>
                      <TableHead>Category</TableHead>
                      <TableHead>Coordinates</TableHead>
                      <TableHead>Bearing</TableHead>
                      <TableHead>Timestamp</TableHead>
                      <TableHead>Time Ago</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {history.map((record, index) => (
                      <TableRow key={`${record.vehicle_id || record.id}-${index}`}>
                        <TableCell className="font-mono text-sm">
                          {index + 1}
                        </TableCell>
                        <TableCell className="font-mono text-sm">
                          {record.vehicle_id || record.id}
                        </TableCell>
                        <TableCell>
                          <Badge 
                            variant="outline" 
                            className={`${getCategoryColor(record.category_name)} text-white`}
                          >
                            {record.category_name}
                          </Badge>
                        </TableCell>
                        <TableCell className="font-mono text-xs">
                          {record.lat.toFixed(4)}, {record.lng.toFixed(4)}
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Navigation 
                              className="h-3 w-3 text-muted-foreground" 
                              style={{ transform: `rotate(${record.bearing}deg)` }}
                            />
                            <span className="text-sm">
                              {Math.round(record.bearing)}° {formatBearing(record.bearing)}
                            </span>
                          </div>
                        </TableCell>
                        <TableCell className="text-sm">
                          {new Date(record.timestamp).toLocaleString()}
                        </TableCell>
                        <TableCell className="text-sm">
                          {(() => {
                            const now = new Date()
                            const recordTime = new Date(record.timestamp)
                            const diffMs = now.getTime() - recordTime.getTime()
                            const diffMins = Math.floor(diffMs / (1000 * 60))
                            const diffHours = Math.floor(diffMins / 60)
                            const diffDays = Math.floor(diffHours / 24)
                            
                            if (diffDays > 0) return `${diffDays}d ago`
                            if (diffHours > 0) return `${diffHours}h ago`
                            if (diffMins > 0) return `${diffMins}m ago`
                            return 'Just now'
                          })()}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            ) : (
              <div className="text-center py-8">
                <History className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <p className="text-muted-foreground">No history records found</p>
                {vehicleId && (
                  <p className="text-sm text-muted-foreground mt-2">
                    Try adjusting your filters or search for a different vehicle ID
                  </p>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}
