import { DashboardLayout } from "@/components/dashboard-layout"
import { SystemStatus } from "@/components/system-status"

export default function SystemPage() {
  return (
    <DashboardLayout>
      <div className="flex flex-col gap-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">สถานะระบบ</h1>
          <p className="text-muted-foreground mt-1">ติดตามสุขภาพและประสิทธิภาพของ API</p>
        </div>

        <SystemStatus />
      </div>
    </DashboardLayout>
  )
}
