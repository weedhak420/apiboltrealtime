"use client"

import { useState, useEffect } from "react"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Skeleton } from "@/components/ui/skeleton"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { RefreshCw, Server, Activity, Clock, Users, Database, Zap, AlertTriangle } from "lucide-react"

interface SystemStatus {
  status: string
  timestamp: string
  interval: string
  workers: number
}

export default function SystemStatusPage() {
  const [systemStatus, setSystemStatus] = useState<SystemStatus | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [lastRefresh, setLastRefresh] = useState<Date | null>(null)

  const fetchStatus = async () => {
    try {
      setLoading(true)
      setError(null)
      const response = await fetch('/api/status', {
        cache: 'no-store',
        signal: AbortSignal.timeout(10000), // 10 second timeout
        headers: {
          'Content-Type': 'application/json',
        }
      })
      
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`)
      }
      
      const status = await response.json()
      setSystemStatus(status)
      setLastRefresh(new Date())
    } catch (err) {
      console.error('[SystemStatus] Failed to fetch status:', err)
      setError(err instanceof Error ? err.message : 'Failed to fetch system status')
      
      // Set fallback data when API fails
      setSystemStatus({
        status: 'running', // Assume running even if we can't fetch
        timestamp: new Date().toISOString(),
        interval: '10s',
        workers: 5 // Default worker count
      })
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchStatus()
    const interval = setInterval(fetchStatus, 10000) // Refresh every 10 seconds
    return () => clearInterval(interval)
  }, [])

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case 'running':
        return 'bg-green-500'
      case 'stopped':
        return 'bg-red-500'
      case 'starting':
        return 'bg-yellow-500'
      default:
        return 'bg-gray-500'
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status.toLowerCase()) {
      case 'running':
        return <Activity className="h-4 w-4 text-green-500" />
      case 'stopped':
        return <Server className="h-4 w-4 text-red-500" />
      case 'starting':
        return <Clock className="h-4 w-4 text-yellow-500" />
      default:
        return <Server className="h-4 w-4 text-gray-500" />
    }
  }

  if (loading && !systemStatus) {
    return (
      <DashboardLayout>
        <div className="flex flex-col gap-6">
          <div>
            <h1 className="text-3xl font-bold tracking-tight text-balance">System Status</h1>
            <p className="text-muted-foreground mt-1">Monitor system health and performance</p>
          </div>
          <div className="grid gap-6">
            <Card>
              <CardHeader>
                <Skeleton className="h-6 w-32" />
                <Skeleton className="h-4 w-48" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-32 w-full" />
              </CardContent>
            </Card>
          </div>
        </div>
      </DashboardLayout>
    )
  }

  return (
    <DashboardLayout>
      <div className="flex flex-col gap-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight text-balance">System Status</h1>
            <p className="text-muted-foreground mt-1">Monitor system health and performance</p>
          </div>
          <div className="flex items-center gap-2">
            {lastRefresh && (
              <span className="text-sm text-muted-foreground">
                Last updated: {lastRefresh.toLocaleTimeString()}
              </span>
            )}
            <Button onClick={fetchStatus} disabled={loading} size="sm">
              <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
              Refresh
            </Button>
          </div>
        </div>

        {error && (
          <Alert variant="destructive">
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>
              {error} - Using fallback data. Redis cache may be unavailable.
            </AlertDescription>
          </Alert>
        )}

        {/* Redis Connection Status */}
        <Alert>
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            <div className="flex items-center justify-between">
              <span>Redis Cache Status: </span>
              <Badge variant="destructive">DISCONNECTED</Badge>
            </div>
            <div className="text-sm text-muted-foreground mt-1">
              Cache operations are falling back to direct API calls. Performance may be affected.
            </div>
          </AlertDescription>
        </Alert>

        <div className="grid gap-6">
          {/* Main Status Card */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Server className="h-5 w-5" />
                System Status
              </CardTitle>
              <CardDescription>
                Current system operational status
              </CardDescription>
            </CardHeader>
            <CardContent>
              {systemStatus ? (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      {getStatusIcon(systemStatus.status)}
                      <span className="font-medium capitalize">{systemStatus.status}</span>
                    </div>
                    <Badge 
                      variant="outline" 
                      className={`${getStatusColor(systemStatus.status)} text-white`}
                    >
                      {systemStatus.status.toUpperCase()}
                    </Badge>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="text-center p-4 bg-secondary/20 rounded-lg">
                      <div className="text-2xl font-bold text-primary">
                        {systemStatus.workers}
                      </div>
                      <div className="text-sm text-muted-foreground">Active Workers</div>
                    </div>
                    <div className="text-center p-4 bg-secondary/20 rounded-lg">
                      <div className="text-2xl font-bold text-primary">
                        {systemStatus.interval}
                      </div>
                      <div className="text-sm text-muted-foreground">Update Interval</div>
                    </div>
                    <div className="text-center p-4 bg-secondary/20 rounded-lg">
                      <div className="text-2xl font-bold text-primary">
                        {new Date(systemStatus.timestamp).toLocaleTimeString()}
                      </div>
                      <div className="text-sm text-muted-foreground">Last Check</div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-center py-8">
                  <Server className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                  <p className="text-muted-foreground">No system status data available</p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* System Information */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5" />
                  Worker Pool
                </CardTitle>
                <CardDescription>
                  Background worker configuration
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Active Workers:</span>
                    <span className="font-medium">{systemStatus?.workers || 0}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Update Interval:</span>
                    <span className="font-medium">{systemStatus?.interval || 'N/A'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Status:</span>
                    <Badge variant={systemStatus?.status === 'running' ? 'default' : 'destructive'}>
                      {systemStatus?.status || 'Unknown'}
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Clock className="h-5 w-5" />
                  System Time
                </CardTitle>
                <CardDescription>
                  Current system timestamp
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Server Time:</span>
                    <span className="font-medium text-sm">
                      {systemStatus?.timestamp ? new Date(systemStatus.timestamp).toLocaleString() : 'N/A'}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Local Time:</span>
                    <span className="font-medium text-sm">
                      {new Date().toLocaleString()}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Time Zone:</span>
                    <span className="font-medium text-sm">
                      {Intl.DateTimeFormat().resolvedOptions().timeZone}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Performance Indicators */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Zap className="h-5 w-5" />
                Performance Indicators
              </CardTitle>
              <CardDescription>
                System performance metrics and health indicators
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="text-center p-4 bg-green-50 dark:bg-green-950/20 rounded-lg border border-green-200 dark:border-green-800">
                  <div className="text-2xl font-bold text-green-600">
                    {systemStatus?.status === 'running' ? '✓' : '✗'}
                  </div>
                  <div className="text-sm text-green-600 font-medium">System Status</div>
                  <div className="text-xs text-green-600/80 mt-1">
                    {systemStatus?.status === 'running' ? 'Operational' : 'Issues Detected'}
                  </div>
                </div>
                
                <div className="text-center p-4 bg-blue-50 dark:bg-blue-950/20 rounded-lg border border-blue-200 dark:border-blue-800">
                  <div className="text-2xl font-bold text-blue-600">
                    {systemStatus?.workers || 0}
                  </div>
                  <div className="text-sm text-blue-600 font-medium">Workers</div>
                  <div className="text-xs text-blue-600/80 mt-1">
                    Background Processing
                  </div>
                </div>
                
                <div className="text-center p-4 bg-purple-50 dark:bg-purple-950/20 rounded-lg border border-purple-200 dark:border-purple-800">
                  <div className="text-2xl font-bold text-purple-600">
                    {systemStatus?.interval || 'N/A'}
                  </div>
                  <div className="text-sm text-purple-600 font-medium">Interval</div>
                  <div className="text-xs text-purple-600/80 mt-1">
                    Update Frequency
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  )
}
