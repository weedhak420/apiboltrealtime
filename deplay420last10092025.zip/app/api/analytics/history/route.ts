import { NextRequest, NextResponse } from "next/server"

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000"

// Fallback analytics data for when backend is not available
const fallbackAnalyticsData = {
  summary: {
    start: "2025-01-01T00:00:00Z",
    end: "2025-01-01T23:59:59Z",
    record_count: 150,
    vehicle_count: 12,
    total_distance_km: 45.2,
    avg_speed_kmh: 28.5,
    stop_count: 8
  },
  bearing_histogram: {
    N: 25,
    NE: 18,
    E: 32,
    SE: 15,
    S: 20,
    SW: 12,
    W: 28,
    NW: 10
  },
  hotspots: [
    { grid_lat: 18.7883, grid_lng: 98.9853, vehicles: 15 },
    { grid_lat: 18.7900, grid_lng: 98.9870, vehicles: 12 },
    { grid_lat: 18.7850, grid_lng: 98.9830, vehicles: 8 },
    { grid_lat: 18.7920, grid_lng: 98.9900, vehicles: 6 },
    { grid_lat: 18.7820, grid_lng: 98.9800, vehicles: 4 }
  ],
  vehicles: [
    {
      vehicle_id: "4289043010",
      points: 45,
      distance_km: 12.3,
      avg_speed_kmh: 25.8,
      stops: 3
    },
    {
      vehicle_id: "4289043011",
      points: 38,
      distance_km: 8.7,
      avg_speed_kmh: 22.1,
      stops: 2
    },
    {
      vehicle_id: "4289043012",
      points: 42,
      distance_km: 15.2,
      avg_speed_kmh: 31.4,
      stops: 4
    }
  ],
  timestamp: new Date().toISOString()
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const queryString = searchParams.toString()
    
    console.log(`Fetching analytics history from: ${API_BASE_URL}/api/analytics/history?${queryString}`)
    
    const response = await fetch(`${API_BASE_URL}/api/analytics/history?${queryString}`, {
      cache: "no-store",
      signal: AbortSignal.timeout(15000), // Increased timeout to 15 seconds
    })

    if (!response.ok) {
      console.error(`API responded with status: ${response.status}`)
      throw new Error(`API responded with status: ${response.status}`)
    }

    const data = await response.json()
    console.log("Successfully fetched analytics history:", data)
    return NextResponse.json(data)
  } catch (error) {
    console.error("Error fetching analytics history:", error)
    console.log("Using fallback analytics data - Go API not available")
    
    // Return fallback data instead of error
    return NextResponse.json(fallbackAnalyticsData, { status: 200 })
  }
}
