import { NextRequest, NextResponse } from 'next/server'

const BACKEND_URL = process.env.BACKEND_URL || 'http://localhost:8000'

export async function GET(request: NextRequest) {
  try {
    console.log('📊 Fetching basic analytics data...')
    
    const response = await fetch(`${BACKEND_URL}/api/analytics`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      },
      signal: AbortSignal.timeout(10000), // 10 second timeout
    })

    if (!response.ok) {
      console.error(`❌ Backend analytics failed: ${response.status} ${response.statusText}`)
      // Return fallback data when backend fails
      return NextResponse.json({
        total_vehicles: 0,
        locations: 0,
        timestamp: new Date().toISOString(),
        message: 'Backend analytics service unavailable'
      }, { status: 200 })
    }

    const data = await response.json()
    console.log('✅ Basic analytics data fetched successfully')
    
    return NextResponse.json(data)
    
  } catch (error) {
    console.error('❌ Basic analytics fetch error:', error)
    
    // Return fallback data when fetch fails
    return NextResponse.json({
      total_vehicles: 0,
      locations: 0,
      timestamp: new Date().toISOString(),
      message: 'Backend analytics service unavailable'
    }, { status: 200 })
  }
}
