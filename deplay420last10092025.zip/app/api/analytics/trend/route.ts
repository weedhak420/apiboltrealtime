import { NextResponse } from "next/server"
import { CacheManager, CACHE_KEYS, CACHE_TTL } from "@/lib/cache-utils"

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000"

// Fallback trend data for when backend is not available
const fallbackTrendData = {
  trends: [
    { time: "2025-01-01 00:00:00", vehicles: 8, smoothed: 8.2 },
    { time: "2025-01-01 01:00:00", vehicles: 12, smoothed: 10.1 },
    { time: "2025-01-01 02:00:00", vehicles: 15, smoothed: 12.8 },
    { time: "2025-01-01 03:00:00", vehicles: 18, smoothed: 15.2 },
    { time: "2025-01-01 04:00:00", vehicles: 22, smoothed: 18.1 },
    { time: "2025-01-01 05:00:00", vehicles: 25, smoothed: 21.3 },
    { time: "2025-01-01 06:00:00", vehicles: 28, smoothed: 24.5 },
    { time: "2025-01-01 07:00:00", vehicles: 32, smoothed: 27.8 },
    { time: "2025-01-01 08:00:00", vehicles: 35, smoothed: 30.9 },
    { time: "2025-01-01 09:00:00", vehicles: 38, smoothed: 33.7 },
    { time: "2025-01-01 10:00:00", vehicles: 42, smoothed: 37.2 },
    { time: "2025-01-01 11:00:00", vehicles: 45, smoothed: 40.1 }
  ],
  count: 12,
  interval: "hour",
  smoothing: "ema_0.3",
  timestamp: new Date().toISOString()
}

export async function GET(request: Request) {
  try {
    // Get query parameters for optimization
    const { searchParams } = new URL(request.url)
    const interval = searchParams.get('interval') || 'hour'
    const limit = searchParams.get('limit') || '24' // Limit to 24 hours
    
    console.log("Request URL:", request.url)
    console.log("Interval parameter:", interval)
    console.log("Limit parameter:", limit)
    
    // Create interval-specific cache key
    const trendCacheKey = `trend_cache_${interval}`
    
    // Check cache first for fast response
    console.log("Checking Redis cache for trend data...")
    const cached = await CacheManager.get(trendCacheKey)
    if (cached) {
      console.log("✅ Trend cache hit - returning cached data")
      return NextResponse.json(cached)
    }
    
    console.log("❌ Trend cache miss - fetching from Go API...")
    
    // Try the optimized endpoint first (if available)
    let response;
    try {
      response = await fetch(`${API_BASE_URL}/api/analytics/trend/fast?interval=${interval}&limit=${limit}`, {
        cache: "no-store",
        signal: AbortSignal.timeout(5000), // 5 seconds for fast endpoint
      })
      
      if (response.ok) {
        console.log("✅ Fast trend endpoint successful")
        const data = await response.json()
        await CacheManager.set(trendCacheKey, data, CACHE_TTL.TREND)
        return NextResponse.json(data)
      }
    } catch (fastError) {
      console.log("⚠️ Fast endpoint failed, trying standard endpoint...")
    }
    
    // Fallback to standard endpoint with shorter timeout
    response = await fetch(`${API_BASE_URL}/api/analytics/trend?interval=${interval}&limit=${limit}`, {
      cache: "no-store",
      signal: AbortSignal.timeout(10000), // Reduced to 10 seconds timeout
    })

    if (!response.ok) {
      throw new Error(`API responded with status: ${response.status}`)
    }

    const data = await response.json()
    console.log("✅ Trend data fetched from Go API successfully")

    // Save to cache for future requests
    await CacheManager.set(trendCacheKey, data, CACHE_TTL.TREND)

    return NextResponse.json(data)
  } catch (error) {
    console.error("❌ Error fetching trend:", error)

    // Try to get cached data as fallback
    try {
      console.log("🔄 Attempting to get cached trend data as fallback...")
      const cached = await CacheManager.get(trendCacheKey)
      if (cached) {
        console.log("✅ Using cached trend data as fallback")
        return NextResponse.json(cached)
      }
    } catch (cacheError) {
      console.warn("⚠️ Failed to get cached trend data:", cacheError)
    }

    console.log("🔄 Using static fallback trend data")
    return NextResponse.json(fallbackTrendData, { status: 200 })
  }
}
