import { NextResponse } from "next/server"
import { CacheManager, CACHE_KEYS, CACHE_TTL } from "@/lib/cache-utils"

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000"

// Fallback heatmap data for when backend is not available
const fallbackHeatmapData = {
  hotspots: [
    { grid_lat: 18.7883, grid_lng: 98.9853, vehicles: 15 },
    { grid_lat: 18.7900, grid_lng: 98.9870, vehicles: 12 },
    { grid_lat: 18.7850, grid_lng: 98.9830, vehicles: 8 },
    { grid_lat: 18.7920, grid_lng: 98.9900, vehicles: 6 },
    { grid_lat: 18.7820, grid_lng: 98.9800, vehicles: 4 }
  ],
  count: 5,
  limit: 50,
  timestamp: new Date().toISOString()
}

export async function GET(request: Request) {
  // Get query parameters for optimization (moved outside try block)
  const { searchParams } = new URL(request.url)
  const limit = searchParams.get('limit') || '20' // Reduce default limit
  const grid = searchParams.get('grid') || '0.01' // Larger grid for faster processing
  
  try {
    // Check cache first for fast response
    console.log("Checking Redis cache for heatmap data...")
    const cached = await CacheManager.get(CACHE_KEYS.HEATMAP)
    if (cached) {
      console.log("✅ Heatmap cache hit - returning cached data")
      return NextResponse.json(cached)
    }
    
    console.log("❌ Heatmap cache miss - fetching from Go API...")
    
    // Try the fast endpoint first (optimized for speed)
    let response;
    try {
      response = await fetch(`${API_BASE_URL}/api/analytics/heatmap/fast?limit=${limit}&interval=10min`, {
        cache: "no-store",
        signal: AbortSignal.timeout(2000), // 2 seconds timeout for fast endpoint
      })
      
      if (response.ok) {
        console.log("✅ Fast heatmap endpoint successful")
        const data = await response.json()
        await CacheManager.set(CACHE_KEYS.HEATMAP, data, CACHE_TTL.HEATMAP)
        return NextResponse.json(data)
      }
    } catch (apiError) {
      console.log("⚠️ Fast endpoint failed, trying standard endpoint...")
    }
    
    // Fallback to standard endpoint with longer timeout
    try {
      response = await fetch(`${API_BASE_URL}/api/analytics/heatmap?limit=${limit}&interval=10min`, {
        cache: "no-store",
        signal: AbortSignal.timeout(5000), // 5 seconds timeout for standard endpoint
      })
      
      if (response.ok) {
        console.log("✅ Standard heatmap endpoint successful")
        const data = await response.json()
        await CacheManager.set(CACHE_KEYS.HEATMAP, data, CACHE_TTL.HEATMAP)
        return NextResponse.json(data)
      }
    } catch (standardError) {
      console.log("⚠️ Standard endpoint also failed, using fallback...")
      throw standardError // Re-throw to trigger fallback
    }
  } catch (error) {
    console.error("❌ Error fetching heatmap:", error)

    // Try to get cached data as fallback
    try {
      console.log("🔄 Attempting to get cached heatmap data as fallback...")
      const cached = await CacheManager.get(CACHE_KEYS.HEATMAP)
      if (cached) {
        console.log("✅ Using cached heatmap data as fallback")
        return NextResponse.json(cached)
      }
    } catch (cacheError) {
      console.warn("⚠️ Failed to get cached heatmap data:", cacheError)
    }

    // Use enhanced fallback data with more realistic values
    const enhancedFallbackData = {
      hotspots: [
        { grid_lat: 18.7883, grid_lng: 98.9853, vehicles: 15 },
        { grid_lat: 18.7900, grid_lng: 98.9870, vehicles: 12 },
        { grid_lat: 18.7850, grid_lng: 98.9830, vehicles: 8 },
        { grid_lat: 18.7920, grid_lng: 98.9900, vehicles: 6 },
        { grid_lat: 18.7820, grid_lng: 98.9800, vehicles: 4 },
        { grid_lat: 18.7950, grid_lng: 98.9920, vehicles: 3 },
        { grid_lat: 18.7800, grid_lng: 98.9780, vehicles: 2 },
        { grid_lat: 18.7980, grid_lng: 98.9950, vehicles: 1 }
      ],
      count: 8,
      limit: parseInt(searchParams.get('limit') || '20'),
      grid: parseFloat(searchParams.get('grid') || '0.01'),
      timestamp: new Date().toISOString(),
      source: "fallback_enhanced"
    }

    console.log("🔄 Using enhanced static fallback heatmap data")
    return NextResponse.json(enhancedFallbackData, { status: 200 })
  }
}
