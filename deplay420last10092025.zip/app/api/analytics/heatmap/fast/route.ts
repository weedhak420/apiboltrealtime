import { NextRequest, NextResponse } from 'next/server'

const BACKEND_URL = process.env.BACKEND_URL || 'http://localhost:8000'

export async function GET(request: NextRequest) {
  try {
    console.log('🔥 Fetching fast heatmap data...')
    
    const { searchParams } = new URL(request.url)
    const limit = searchParams.get('limit') || '50'
    
    const response = await fetch(`${BACKEND_URL}/api/analytics/heatmap/fast?limit=${limit}`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      },
      signal: AbortSignal.timeout(5000), // 5 second timeout for fast endpoint
    })

    if (!response.ok) {
      console.error(`❌ Backend fast heatmap failed: ${response.status} ${response.statusText}`)
      return NextResponse.json(
        { 
          error: 'Backend fast heatmap unavailable',
          status: 'error',
          message: `Backend returned ${response.status}`,
          timestamp: new Date().toISOString()
        },
        { status: response.status }
      )
    }

    const data = await response.json()
    console.log('✅ Fast heatmap data fetched successfully')
    
    return NextResponse.json(data)
    
  } catch (error) {
    console.error('❌ Fast heatmap fetch error:', error)
    
    // Return fallback data when backend is unavailable
    const fallbackData = {
      hotspots: [],
      count: 0,
      limit: parseInt(new URL(request.url).searchParams.get('limit') || '50'),
      timestamp: new Date().toISOString(),
      source: 'fallback',
      message: 'Backend fast heatmap service unavailable'
    }
    
    return NextResponse.json(fallbackData, { status: 200 })
  }
}
