import { NextRequest, NextResponse } from 'next/server'

const BACKEND_URL = process.env.BACKEND_URL || 'http://localhost:8000'

export async function GET(request: NextRequest) {
  try {
    console.log('🔐 Fetching JWT status from backend...')
    
    const response = await fetch(`${BACKEND_URL}/api/jwt/status`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      },
      // Add timeout to prevent hanging
      signal: AbortSignal.timeout(10000), // 10 second timeout
    })

    if (!response.ok) {
      console.error(`❌ Backend JWT status failed: ${response.status} ${response.statusText}`)
      return NextResponse.json(
        { 
          error: 'Backend JWT status unavailable',
          status: 'error',
          message: `Backend returned ${response.status}`,
          timestamp: new Date().toISOString()
        },
        { status: response.status }
      )
    }

    const data = await response.json()
    console.log('✅ JWT status fetched successfully')
    
    return NextResponse.json(data)
    
  } catch (error) {
    console.error('❌ JWT status fetch error:', error)
    
    // Return fallback data when backend is unavailable
    const fallbackData = {
      status: 'no_token',
      message: 'Backend JWT service unavailable',
      token_info: {
        expires_at: new Date(Date.now() + 15 * 60 * 1000).toISOString(), // 15 minutes from now
        issued_at: new Date().toISOString(),
        user_id: 0,
        login_id: 0,
        is_valid: false,
        time_until_expiry: '0m0s'
      },
      rate_limiting: {
        max_concurrent: 10,
        requests_per_second: 5,
        current_requests: 0
      },
      error_handling: {
        retry_attempts: 0,
        last_error: error instanceof Error ? error.message : 'Unknown error',
        error_1005_count: 0,
        error_210_count: 0,
        http_429_count: 0
      },
      timestamp: new Date().toISOString()
    }
    
    return NextResponse.json(fallbackData, { status: 200 })
  }
}
