import { NextRequest, NextResponse } from 'next/server'

const BACKEND_URL = process.env.BACKEND_URL || 'http://localhost:8000'

export async function GET(request: NextRequest) {
  try {
    console.log('🟢 Readiness check...')
    
    const response = await fetch(`${BACKEND_URL}/readyz`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      },
      signal: AbortSignal.timeout(5000), // 5 second timeout
    })

    if (!response.ok) {
      console.error(`❌ Backend readiness check failed: ${response.status} ${response.statusText}`)
      return NextResponse.json(
        { 
          status: 'not_ready',
          message: `Backend returned ${response.status}`,
          timestamp: new Date().toISOString()
        },
        { status: response.status }
      )
    }

    const data = await response.json()
    console.log('✅ Readiness check successful')
    
    return NextResponse.json(data)
    
  } catch (error) {
    console.error('❌ Readiness check error:', error)
    
    return NextResponse.json(
      { 
        status: 'not_ready',
        message: error instanceof Error ? error.message : 'Readiness check failed',
        timestamp: new Date().toISOString()
      },
      { status: 200 }
    )
  }
}
