import { NextRequest, NextResponse } from 'next/server'

const BACKEND_URL = process.env.BACKEND_URL || 'http://localhost:8000'

export async function GET(request: NextRequest) {
  try {
    console.log('📊 Fetching metrics...')
    
    const response = await fetch(`${BACKEND_URL}/metrics`, {
      method: 'GET',
      headers: {
        'Content-Type': 'text/plain',
        'Accept': 'text/plain',
      },
      signal: AbortSignal.timeout(10000), // 10 second timeout
    })

    if (!response.ok) {
      console.error(`❌ Backend metrics failed: ${response.status} ${response.statusText}`)
      return NextResponse.json(
        { 
          error: 'Backend metrics unavailable',
          message: `Backend returned ${response.status}`,
          timestamp: new Date().toISOString()
        },
        { status: response.status }
      )
    }

    const data = await response.text()
    console.log('✅ Metrics fetched successfully')
    
    return new NextResponse(data, {
      headers: {
        'Content-Type': 'text/plain',
      }
    })
    
  } catch (error) {
    console.error('❌ Metrics fetch error:', error)
    
    return NextResponse.json(
      { 
        error: 'Metrics unavailable',
        message: error instanceof Error ? error.message : 'Metrics fetch failed',
        timestamp: new Date().toISOString()
      },
      { status: 500 }
    )
  }
}
