import { NextRequest, NextResponse } from 'next/server'
import performanceMonitor from '@/lib/performance-monitor'
import hybridCache from '@/lib/hybrid-cache'

export async function GET(request: NextRequest) {
  try {
    console.log('📊 Fetching performance metrics...')
    
    // Get performance statistics
    const stats = performanceMonitor.getStats()
    const cacheStats = performanceMonitor.getCacheStats()
    const hybridCacheStats = hybridCache.getStats()
    
    // Calculate additional metrics
    const avgResponseTime = stats.apiResponseTime.length > 0 
      ? stats.apiResponseTime.reduce((a, b) => a + b, 0) / stats.apiResponseTime.length 
      : 0
    
    const maxResponseTime = stats.apiResponseTime.length > 0 
      ? Math.max(...stats.apiResponseTime) 
      : 0
    
    const minResponseTime = stats.apiResponseTime.length > 0 
      ? Math.min(...stats.apiResponseTime) 
      : 0
    
    // Performance metrics response
    const performanceData = {
      timestamp: new Date().toISOString(),
      api: {
        total_requests: performanceMonitor['apiRequests'],
        error_rate: stats.errorRate,
        average_response_time: avgResponseTime,
        max_response_time: maxResponseTime,
        min_response_time: minResponseTime,
        response_times: stats.apiResponseTime
      },
      cache: {
        hits: cacheStats.hits,
        misses: cacheStats.misses,
        hit_rate: cacheStats.hitRate,
        total_requests: cacheStats.total
      },
      hybrid_cache: hybridCacheStats,
      memory: {
        heap_used: stats.memoryUsage,
        heap_used_mb: Math.round(stats.memoryUsage / 1024 / 1024 * 100) / 100
      },
      system: {
        uptime: process.uptime(),
        node_version: process.version,
        platform: process.platform
      }
    }
    
    console.log('✅ Performance metrics fetched successfully')
    
    return NextResponse.json(performanceData, {
      headers: {
        'Cache-Control': 'no-cache, no-store, must-revalidate',
        'Content-Type': 'application/json'
      }
    })
    
  } catch (error) {
    console.error('❌ Performance metrics fetch error:', error)
    
    return NextResponse.json(
      { 
        error: 'Failed to fetch performance metrics',
        message: error instanceof Error ? error.message : 'Unknown error',
        timestamp: new Date().toISOString()
      },
      { status: 500 }
    )
  }
}

// Prometheus metrics endpoint
export async function POST(request: NextRequest) {
  try {
    console.log('📊 Exporting Prometheus metrics...')
    
    const prometheusMetrics = performanceMonitor.exportPrometheusMetrics()
    
    return new NextResponse(prometheusMetrics, {
      headers: {
        'Content-Type': 'text/plain; version=0.0.4; charset=utf-8',
        'Cache-Control': 'no-cache, no-store, must-revalidate'
      }
    })
    
  } catch (error) {
    console.error('❌ Prometheus metrics export error:', error)
    
    return NextResponse.json(
      { 
        error: 'Failed to export Prometheus metrics',
        message: error instanceof Error ? error.message : 'Unknown error',
        timestamp: new Date().toISOString()
      },
      { status: 500 }
    )
  }
}
