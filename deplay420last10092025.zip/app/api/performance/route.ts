import { NextRequest, NextResponse } from 'next/server'

const BACKEND_URL = process.env.BACKEND_URL || 'http://localhost:8000'

export async function GET(request: NextRequest) {
  try {
    console.log('📊 Fetching performance metrics...')
    
    const response = await fetch(`${BACKEND_URL}/api/performance`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      },
      signal: AbortSignal.timeout(10000), // 10 second timeout
    })

    if (!response.ok) {
      console.error(`❌ Backend performance failed: ${response.status} ${response.statusText}`)
      return NextResponse.json(
        { 
          error: 'Backend performance unavailable',
          status: 'error',
          message: `Backend returned ${response.status}`,
          timestamp: new Date().toISOString()
        },
        { status: response.status }
      )
    }

    const data = await response.json()
    console.log('✅ Performance metrics fetched successfully')
    
    // Transform backend data to match frontend expectations
    const transformedData = {
      goroutine_count: data.worker_pool?.workers || 0,
      cache_size: data.redis?.connected ? 1 : 0, // Simple cache status
      rate_limit_size: data.worker_pool?.queue_size || 0,
      enhanced_rate_limiter: {
        requests_per_minute: 60, // Default rate limit
        current_requests: data.worker_pool?.active_jobs || 0
      },
      worker_pool: {
        active_workers: data.worker_pool?.workers || 0,
        queued_tasks: data.worker_pool?.queue_size || 0
      },
      database: {
        connected: data.database?.connected || false,
        total_vehicles: data.database?.total_vehicles || 0
      },
      redis: {
        connected: data.redis?.connected || false,
        status: data.redis?.status || 'unknown'
      },
      analytics_worker: {
        running: data.analytics_worker?.running || false,
        status: data.analytics_worker?.status || 'unknown'
      },
      system: {
        status: data.status || 'unknown',
        uptime: data.uptime || '0s',
        version: data.version || '1.0.0'
      },
      timestamp: data.timestamp || new Date().toISOString()
    }
    
    return NextResponse.json(transformedData)
    
  } catch (error) {
    console.error('❌ Performance fetch error:', error)
    
    // Return fallback data when backend is unavailable
    const fallbackData = {
      goroutine_count: 0,
      cache_size: 0,
      rate_limit_size: 0,
      enhanced_rate_limiter: {
        requests_per_minute: 60,
        current_requests: 0
      },
      worker_pool: {
        active_workers: 0,
        queued_tasks: 0
      },
      database: {
        connected: false,
        total_vehicles: 0
      },
      redis: {
        connected: false,
        status: 'disconnected'
      },
      analytics_worker: {
        running: false,
        status: 'stopped'
      },
      system: {
        status: 'error',
        uptime: '0s',
        version: '1.0.0'
      },
      message: 'Backend performance service unavailable',
      timestamp: new Date().toISOString()
    }
    
    return NextResponse.json(fallbackData, { status: 200 })
  }
}
