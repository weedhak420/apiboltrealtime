import { NextResponse } from "next/server"
import { CacheManager, CACHE_KEYS, CACHE_TTL } from "@/lib/cache-utils"
import hybridCache from "@/lib/hybrid-cache"

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000"

// Fallback vehicle data for when backend is not available
const fallbackVehicleData = {
  vehicles: [
    {
      id: "4289043010",
      lat: 18.7883,
      lng: 98.9853,
      bearing: 45.5,
      icon_url: "/car.svg",
      category_name: "Bolt_Taxi",
      source_location: "city_center",
      timestamp: new Date().toISOString(),
      speed: 25.8
    },
    {
      id: "4289043011",
      lat: 18.7900,
      lng: 98.9870,
      bearing: 120.3,
      icon_url: "/car.svg",
      category_name: "Bolt_Taxi",
      source_location: "airport",
      timestamp: new Date().toISOString(),
      speed: 18.2
    },
    {
      id: "4289043012",
      lat: 18.7850,
      lng: 98.9830,
      bearing: 280.7,
      icon_url: "/car.svg",
      category_name: "Bolt_Taxi",
      source_location: "shopping_mall",
      timestamp: new Date().toISOString(),
      speed: 32.1
    },
    {
      id: "4289043013",
      lat: 18.7920,
      lng: 98.9900,
      bearing: 15.2,
      icon_url: "/car.svg",
      category_name: "Bolt_Taxi",
      source_location: "university",
      timestamp: new Date().toISOString(),
      speed: 22.5
    },
    {
      id: "4289043014",
      lat: 18.7820,
      lng: 98.9800,
      bearing: 200.8,
      icon_url: "/car.svg",
      category_name: "Bolt_Taxi",
      source_location: "hospital",
      timestamp: new Date().toISOString(),
      speed: 28.9
    }
  ],
  count: 5,
  timestamp: new Date().toISOString(),
  source: "fallback"
}

export async function GET() {
  try {
    // Check hybrid cache first for fast response
    console.log("Checking hybrid cache for vehicles data...")
    const cached = await hybridCache.get(CACHE_KEYS.VEHICLES_LATEST)
    if (cached) {
      console.log("✅ Vehicles cache hit - returning cached data")
      return NextResponse.json(cached)
    }

    console.log("❌ Vehicles cache miss - fetching from Go API...")
    const response = await fetch(`${API_BASE_URL}/api/vehicles/latest`, {
      cache: "no-store",
      signal: AbortSignal.timeout(30000), // 30 seconds timeout
    })

    if (!response.ok) {
      throw new Error(`API responded with status: ${response.status}`)
    }

    const data = await response.json()
    console.log("✅ Vehicles data fetched from Go API successfully")

    // Save to hybrid cache for future requests (shorter TTL for real-time data)
    await hybridCache.set(CACHE_KEYS.VEHICLES_LATEST, data, CACHE_TTL.VEHICLES_LATEST)

    return NextResponse.json(data)
  } catch (error) {
    console.error("❌ Error fetching vehicles from Go API:", error)

    // Try to get cached data as fallback
    try {
      console.log("🔄 Attempting to get cached vehicles data as fallback...")
      const cached = await hybridCache.get(CACHE_KEYS.VEHICLES_LATEST)
      if (cached) {
        console.log("✅ Using cached vehicles data as fallback")
        return NextResponse.json(cached)
      }
    } catch (cacheError) {
      console.warn("⚠️ Failed to get cached vehicles data:", cacheError)
    }

    console.log("🔄 Using static fallback vehicles data")
    return NextResponse.json(fallbackVehicleData, { status: 200 })
  }
}
