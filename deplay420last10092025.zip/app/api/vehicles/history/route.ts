import { NextRequest, NextResponse } from "next/server"

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000"

// Fallback history data for when backend is not available
const fallbackHistoryData = {
  records: [
    {
      history_id: 1,
      vehicle_id: "4289043010",
      lat: 18.7883,
      lng: 98.9853,
      bearing: 45.5,
      category_name: "Bolt_Taxi",
      timestamp: "2025-01-01T10:00:00Z",
      created_at: "2025-01-01T10:00:00Z"
    },
    {
      history_id: 2,
      vehicle_id: "4289043010",
      lat: 18.7890,
      lng: 98.9860,
      bearing: 50.2,
      category_name: "Bolt_Taxi",
      timestamp: "2025-01-01T10:05:00Z",
      created_at: "2025-01-01T10:05:00Z"
    },
    {
      history_id: 3,
      vehicle_id: "4289043010",
      lat: 18.7900,
      lng: 98.9870,
      bearing: 55.8,
      category_name: "Bolt_Taxi",
      timestamp: "2025-01-01T10:10:00Z",
      created_at: "2025-01-01T10:10:00Z"
    },
    {
      history_id: 4,
      vehicle_id: "4289043010",
      lat: 18.7910,
      lng: 98.9880,
      bearing: 60.1,
      category_name: "Bolt_Taxi",
      timestamp: "2025-01-01T10:15:00Z",
      created_at: "2025-01-01T10:15:00Z"
    },
    {
      history_id: 5,
      vehicle_id: "4289043010",
      lat: 18.7920,
      lng: 98.9890,
      bearing: 65.3,
      category_name: "Bolt_Taxi",
      timestamp: "2025-01-01T10:20:00Z",
      created_at: "2025-01-01T10:20:00Z"
    }
  ],
  count: 5,
  limit: 100,
  vehicle_id: "4289043010",
  timestamp: new Date().toISOString()
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const queryString = searchParams.toString()
    
    console.log(`Fetching vehicle history from: ${API_BASE_URL}/api/vehicles/history?${queryString}`)
    console.log("Search params:", Object.fromEntries(searchParams.entries()))
    
    const response = await fetch(`${API_BASE_URL}/api/vehicles/history?${queryString}`, {
      cache: "no-store",
      signal: AbortSignal.timeout(15000), // Increased timeout to 15 seconds
    })

    if (!response.ok) {
      console.error(`API responded with status: ${response.status}`)
      throw new Error(`API responded with status: ${response.status}`)
    }

    const data = await response.json()
    console.log("Successfully fetched vehicle history:", data)
    console.log("Data count:", data.count)
    console.log("Data records/data:", data.records || data.data)
    
    // If no data found, return empty result instead of fallback
    if (data.count === 0 || (!data.records && !data.data)) {
      console.log("No data found for the specified criteria")
      return NextResponse.json({
        count: 0,
        records: [],
        data: [],
        status: "no_data",
        message: "No vehicle history found for the selected criteria"
      })
    }
    
    return NextResponse.json(data)
  } catch (error) {
    console.error("Error fetching vehicle history:", error)
    console.log("Using fallback history data - Go API not available")
    
    // Return fallback data instead of error
    return NextResponse.json(fallbackHistoryData, { status: 200 })
  }
}
