import { NextRequest, NextResponse } from 'next/server'

const BACKEND_URL = process.env.BACKEND_URL || 'http://localhost:8000'

export async function GET(request: NextRequest) {
  try {
    console.log('💚 Health check...')
    
    const response = await fetch(`${BACKEND_URL}/healthz`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      },
      signal: AbortSignal.timeout(5000), // 5 second timeout
    })

    if (!response.ok) {
      console.error(`❌ Backend health check failed: ${response.status} ${response.statusText}`)
      return NextResponse.json(
        { 
          status: 'unhealthy',
          message: `Backend returned ${response.status}`,
          timestamp: new Date().toISOString()
        },
        { status: response.status }
      )
    }

    const data = await response.json()
    console.log('✅ Health check successful')
    
    return NextResponse.json(data)
    
  } catch (error) {
    console.error('❌ Health check error:', error)
    
    return NextResponse.json(
      { 
        status: 'unhealthy',
        message: error instanceof Error ? error.message : 'Health check failed',
        timestamp: new Date().toISOString()
      },
      { status: 200 }
    )
  }
}
