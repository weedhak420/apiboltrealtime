import { NextRequest, NextResponse } from 'next/server'

const BACKEND_URL = process.env.BACKEND_URL || 'http://localhost:8000'

export async function POST(request: NextRequest) {
  try {
    console.log('🧹 Clearing cache...')
    
    const response = await fetch(`${BACKEND_URL}/api/cache/clear`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      },
      signal: AbortSignal.timeout(10000), // 10 second timeout
    })

    if (!response.ok) {
      console.error(`❌ Backend cache clear failed: ${response.status} ${response.statusText}`)
      return NextResponse.json({
        success: false,
        message: `Backend cache clear failed: ${response.status}`,
        timestamp: new Date().toISOString()
      }, { status: response.status })
    }

    const data = await response.json()
    console.log('✅ Cache cleared successfully')
    
    return NextResponse.json(data)
    
  } catch (error) {
    console.error('❌ Cache clear error:', error)
    
    return NextResponse.json({
      success: false,
      message: `Cache clear failed: ${error instanceof Error ? error.message : 'Unknown error'}`,
      timestamp: new Date().toISOString()
    }, { status: 500 })
  }
}

export async function GET(request: NextRequest) {
  try {
    console.log('🧹 Getting cache clear status...')
    
    const response = await fetch(`${BACKEND_URL}/api/cache/clear`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      },
      signal: AbortSignal.timeout(10000), // 10 second timeout
    })

    if (!response.ok) {
      console.error(`❌ Backend cache clear status failed: ${response.status} ${response.statusText}`)
      return NextResponse.json({
        success: false,
        message: `Backend cache clear status failed: ${response.status}`,
        timestamp: new Date().toISOString()
      }, { status: response.status })
    }

    const data = await response.json()
    console.log('✅ Cache clear status fetched successfully')
    
    return NextResponse.json(data)
    
  } catch (error) {
    console.error('❌ Cache clear status error:', error)
    
    return NextResponse.json({
      success: false,
      message: `Cache clear status failed: ${error instanceof Error ? error.message : 'Unknown error'}`,
      timestamp: new Date().toISOString()
    }, { status: 500 })
  }
}