import { NextResponse } from "next/server"
import { CacheManager } from "@/lib/cache-utils"
import { isConnected } from "@/lib/redis"

export async function GET() {
  try {
    const stats = await CacheManager.getStats()
    
    return NextResponse.json({
      status: "success",
      redis: {
        connected: isConnected,
        keys: stats.keys,
        memory: stats.memory,
        url: process.env.REDIS_URL ?? "redis://192.168.1.200:6379/0"
      },
      cache_keys: {
        vehicles_latest: "vehicles_latest_cache",
        heatmap: "heatmap_cache",
        trend: "trend_cache",
        vehicles_history: "vehicles_history_cache",
        analytics_history: "analytics_history_cache"
      },
      cache_ttl: {
        vehicles_latest: "30 seconds",
        heatmap: "60 seconds", 
        trend: "60 seconds",
        vehicles_history: "5 minutes",
        analytics_history: "5 minutes"
      },
      performance: {
        cache_timeout: "2 seconds",
        connection_timeout: "5 seconds",
        max_retries: 2
      },
      timestamp: new Date().toISOString()
    })
  } catch (error) {
    console.error("Error fetching cache status:", error)
    
    return NextResponse.json({
      status: "error",
      message: "Failed to fetch cache status",
      redis: {
        connected: isConnected,
        keys: 0,
        memory: "Unknown",
        url: process.env.REDIS_URL ?? "redis://192.168.1.200:6379/0"
      },
      timestamp: new Date().toISOString()
    }, { status: 500 })
  }
}
