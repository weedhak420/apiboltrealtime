import { NextRequest, NextResponse } from 'next/server'

const BACKEND_URL = process.env.BACKEND_URL || 'http://localhost:8000'

export async function GET(request: NextRequest) {
  try {
    console.log('🔐 Getting valid external token...')
    
    const response = await fetch(`${BACKEND_URL}/api/external-token/get`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      },
      signal: AbortSignal.timeout(10000), // 10 second timeout
    })

    if (!response.ok) {
      console.error(`❌ Backend external token get failed: ${response.status} ${response.statusText}`)
      return NextResponse.json(
        { 
          error: 'Backend external token get failed',
          status: 'error',
          message: `Backend returned ${response.status}`,
          timestamp: new Date().toISOString()
        },
        { status: response.status }
      )
    }

    const data = await response.json()
    console.log('✅ External token retrieved successfully')
    
    return NextResponse.json(data)
    
  } catch (error) {
    console.error('❌ External token get error:', error)
    
    // Return fallback data when backend is unavailable
    const fallbackData = {
      success: false,
      message: 'Backend external token service unavailable',
      token: null,
      timestamp: new Date().toISOString()
    }
    
    return NextResponse.json(fallbackData, { status: 200 })
  }
}
