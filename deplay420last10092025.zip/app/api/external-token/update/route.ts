import { NextRequest, NextResponse } from 'next/server'

const BACKEND_URL = process.env.BACKEND_URL || 'http://localhost:8000'

export async function POST(request: NextRequest) {
  try {
    console.log('🔐 Updating external token...')
    
    const body = await request.json()
    const { token, user_id, login_id } = body
    
    if (!token || !user_id || !login_id) {
      return NextResponse.json(
        { error: 'Missing required fields: token, user_id, login_id' },
        { status: 400 }
      )
    }
    
    const response = await fetch(`${BACKEND_URL}/api/external-token/update`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      },
      body: JSON.stringify({ token, user_id, login_id }),
      signal: AbortSignal.timeout(10000), // 10 second timeout
    })

    if (!response.ok) {
      console.error(`❌ Backend external token update failed: ${response.status} ${response.statusText}`)
      return NextResponse.json(
        { 
          error: 'Backend external token update failed',
          status: 'error',
          message: `Backend returned ${response.status}`,
          timestamp: new Date().toISOString()
        },
        { status: response.status }
      )
    }

    const data = await response.json()
    console.log('✅ External token updated successfully')
    
    return NextResponse.json(data)
    
  } catch (error) {
    console.error('❌ External token update error:', error)
    
    return NextResponse.json(
      { 
        error: 'External token update failed',
        message: error instanceof Error ? error.message : 'Unknown error',
        timestamp: new Date().toISOString()
      },
      { status: 500 }
    )
  }
}
