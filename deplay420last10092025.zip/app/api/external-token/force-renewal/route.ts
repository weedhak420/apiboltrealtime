import { NextRequest, NextResponse } from 'next/server'

const BACKEND_URL = process.env.BACKEND_URL || 'http://localhost:8000'

export async function POST(request: NextRequest) {
  try {
    console.log('🔄 Forcing external token renewal...')
    
    const response = await fetch(`${BACKEND_URL}/api/external-token/force-renewal`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      },
      signal: AbortSignal.timeout(15000), // 15 second timeout for renewal
    })

    if (!response.ok) {
      console.error(`❌ Backend external token force renewal failed: ${response.status} ${response.statusText}`)
      return NextResponse.json(
        { 
          error: 'Backend external token force renewal failed',
          status: 'error',
          message: `Backend returned ${response.status}`,
          timestamp: new Date().toISOString()
        },
        { status: response.status }
      )
    }

    const data = await response.json()
    console.log('✅ External token force renewal successful')
    
    return NextResponse.json(data)
    
  } catch (error) {
    console.error('❌ External token force renewal error:', error)
    
    return NextResponse.json(
      { 
        error: 'External token force renewal failed',
        message: error instanceof Error ? error.message : 'Unknown error',
        timestamp: new Date().toISOString()
      },
      { status: 500 }
    )
  }
}
