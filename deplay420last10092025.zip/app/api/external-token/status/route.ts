import { NextRequest, NextResponse } from 'next/server'

const BACKEND_URL = process.env.BACKEND_URL || 'http://localhost:8000'

export async function GET(request: NextRequest) {
  try {
    console.log('🔐 Fetching external token status...')
    
    const response = await fetch(`${BACKEND_URL}/api/external-token/status`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      },
      signal: AbortSignal.timeout(10000), // 10 second timeout
    })

    if (!response.ok) {
      console.error(`❌ Backend external token status failed: ${response.status} ${response.statusText}`)
      return NextResponse.json(
        { 
          error: 'Backend external token status unavailable',
          status: 'error',
          message: `Backend returned ${response.status}`,
          timestamp: new Date().toISOString()
        },
        { status: response.status }
      )
    }

    const data = await response.json()
    console.log('✅ External token status fetched successfully')
    
    return NextResponse.json(data)
    
  } catch (error) {
    console.error('❌ External token status fetch error:', error)
    
    // Return fallback data when backend is unavailable
    const fallbackData = {
      external_token: null,
      is_expired: true,
      expiry_time: new Date().toISOString(),
      current_token: {
        token: null,
        expires_at: new Date().toISOString(),
        issued_at: new Date().toISOString(),
        user_id: 0,
        login_id: 0
      },
      message: 'Backend external token service unavailable',
      timestamp: new Date().toISOString()
    }
    
    return NextResponse.json(fallbackData, { status: 200 })
  }
}
