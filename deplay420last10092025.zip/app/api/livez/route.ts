import { NextRequest, NextResponse } from 'next/server'

const BACKEND_URL = process.env.BACKEND_URL || 'http://localhost:8000'

export async function GET(request: NextRequest) {
  try {
    console.log('❤️ Liveness check...')
    
    const response = await fetch(`${BACKEND_URL}/livez`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      },
      signal: AbortSignal.timeout(5000), // 5 second timeout
    })

    if (!response.ok) {
      console.error(`❌ Backend liveness check failed: ${response.status} ${response.statusText}`)
      return NextResponse.json(
        { 
          status: 'dead',
          message: `Backend returned ${response.status}`,
          timestamp: new Date().toISOString()
        },
        { status: response.status }
      )
    }

    const data = await response.json()
    console.log('✅ Liveness check successful')
    
    return NextResponse.json(data)
    
  } catch (error) {
    console.error('❌ Liveness check error:', error)
    
    return NextResponse.json(
      { 
        status: 'dead',
        message: error instanceof Error ? error.message : 'Liveness check failed',
        timestamp: new Date().toISOString()
      },
      { status: 200 }
    )
  }
}
