"use client"

import { useEffect, useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Skeleton } from "@/components/ui/skeleton"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { fetchVehicleHistory, fetchAnalyticsHistory, fetchHeatmap, fetchTrend, fetchLatestVehicles } from "@/lib/api"
import HistoryMap from "@/components/history-map"
import HistoryCharts from "@/components/history-charts"
import { Calendar, MapPin, BarChart3, RefreshCw, Car } from "lucide-react"

export default function HistoryPage() {
  const [vehicleId, setVehicleId] = useState<string>("")
  const [vehicles, setVehicles] = useState<any[]>([])
  const [vehiclesLoading, setVehiclesLoading] = useState(false)
  const [range, setRange] = useState<{ start: string; end: string }>({
    start: new Date(Date.now() - 6 * 60 * 60 * 1000).toISOString(),
    end: new Date().toISOString()
  })
  const [history, setHistory] = useState<any>(null)
  const [analytics, setAnalytics] = useState<any>(null)
  const [heatmap, setHeatmap] = useState<any>(null)
  const [trend, setTrend] = useState<any>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const reload = async () => {
    setLoading(true)
    setError(null)
    
    try {
      // Validate time range
      if (new Date(range.start) >= new Date(range.end)) {
        throw new Error("Start time must be before end time")
      }
      
      // Check if time range is too large (more than 7 days)
      const timeDiff = new Date(range.end).getTime() - new Date(range.start).getTime()
      const daysDiff = timeDiff / (1000 * 60 * 60 * 24)
      
      if (daysDiff > 7) {
        throw new Error("Time range cannot exceed 7 days. Please select a smaller range.")
      }
      
      console.log("Fetching data with params:", {
        vehicle_id: vehicleId || undefined,
        start_time: range.start,
        end_time: range.end
      })
      
      // Fetch data sequentially to avoid overwhelming the API
      console.log("Fetching vehicle history...")
      console.log("vehicleId:", vehicleId)
      console.log("vehicleId type:", typeof vehicleId)
      console.log("vehicleId length:", vehicleId?.length)
      
      // Add loading delay for smooth UX
      await new Promise(resolve => setTimeout(resolve, 50))
      
      const h = await fetchVehicleHistory({ 
        vehicle_id: vehicleId || undefined, 
        limit: 1000, // Reduced limit for better performance
        start_time: range.start, 
        end_time: range.end 
      })
      console.log("Vehicle history result:", h)
      console.log("Vehicle history records/data:", h?.records || h?.data)
      console.log("Vehicle history count:", h?.count)
      
      // Check if no data found
      if (h?.count === 0 || (!h?.records && !h?.data)) {
        console.log("No vehicle history data found - continuing with analytics...")
        setHistory({ count: 0, records: [], data: [] })
        // Continue with analytics even if no history data
      } else {
        setHistory(h)
      }
      
      console.log("Fetching analytics history...")
      const a = await fetchAnalyticsHistory({ 
        vehicle_id: vehicleId || undefined, 
        start: range.start, 
        end: range.end, 
        grid: 0.001, 
        stop_min_sec: 120, 
        stop_max_move_m: 10 
      })
      console.log("Analytics history result:", a)
      
      console.log("Fetching heatmap...")
      const hm = await fetchHeatmap(50) // Reduced heatmap points
      console.log("Heatmap result:", hm)
      
      console.log("Fetching trend...")
      const t = await fetchTrend("hour")
      console.log("Trend result:", t)
      
      console.log("All data fetched successfully:", { h, a, hm, t })
      
      setHistory(h)
      setAnalytics(a)
      setHeatmap(hm)
      setTrend(t)
    } catch (err) {
      console.error("Failed to load history data:", err)
      setError(err instanceof Error ? err.message : "Failed to load data")
    } finally {
      setLoading(false)
    }
  }

  // Load vehicles list
  const loadVehicles = async () => {
    setVehiclesLoading(true)
    try {
      const vehiclesData = await fetchLatestVehicles()
      console.log("Loaded vehicles:", vehiclesData)
      setVehicles(vehiclesData.vehicles || [])
    } catch (err) {
      console.error("Failed to load vehicles:", err)
      setVehicles([]) // Set empty array on error
    } finally {
      setVehiclesLoading(false)
    }
  }

  useEffect(() => {
    loadVehicles() // Load vehicles list
    reload() // Initial load
  }, [])

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">ประวัติรถและการวิเคราะห์</h1>
          <p className="text-muted-foreground">
            วิเคราะห์การเคลื่อนไหว เส้นทาง และเมตริกประสิทธิภาพของรถ
          </p>
        </div>
        <Badge variant="outline" className="gap-2">
          <BarChart3 className="h-4 w-4" />
          การวิเคราะห์
        </Badge>
      </div>

      {/* Filters */}
      <Card className="p-6">
          <div className="grid gap-4 md:grid-cols-4">
          <div className="space-y-2">
            <Label htmlFor="vehicle-id">รหัสรถ (ไม่บังคับ)</Label>
            <Select value={vehicleId || "all"} onValueChange={(value) => setVehicleId(value === "all" ? "" : value)}>
              <SelectTrigger>
                <SelectValue placeholder="เลือกรหัสรถ" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">ดูรถทั้งหมด</SelectItem>
                {vehiclesLoading ? (
                  <SelectItem value="loading" disabled>
                    <div className="flex items-center gap-2">
                      <RefreshCw className="h-4 w-4 animate-spin" />
                      กำลังโหลด...
                    </div>
                  </SelectItem>
                ) : (
                  vehicles.slice(0, 50).map((vehicle, index) => (
                    <SelectItem key={`${vehicle.id}-${index}`} value={vehicle.id}>
                      <div className="flex items-center gap-2">
                        <Car className="h-4 w-4" />
                        <span className="font-mono text-sm">{vehicle.id}</span>
                        <Badge variant="outline" className="text-xs">
                          {vehicle.category_name || 'Unknown'}
                        </Badge>
                      </div>
                    </SelectItem>
                  ))
                )}
              </SelectContent>
            </Select>
            <p className="text-xs text-muted-foreground">
              เลือกรถเฉพาะหรือดูรถทั้งหมด
            </p>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="start-time">เวลาเริ่มต้น</Label>
            <Input
              id="start-time"
              type="datetime-local"
              value={range.start.slice(0, 16)}
              onChange={(e) => setRange({ ...range, start: new Date(e.target.value).toISOString() })}
            />
            <p className="text-xs text-muted-foreground">
              สูงสุด 7 วัน
            </p>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="end-time">เวลาสิ้นสุด</Label>
            <Input
              id="end-time"
              type="datetime-local"
              value={range.end.slice(0, 16)}
              onChange={(e) => setRange({ ...range, end: new Date(e.target.value).toISOString() })}
            />
            <p className="text-xs text-muted-foreground">
              เวลาปัจจุบัน: {new Date().toLocaleString('th-TH')}
            </p>
          </div>
          
          <div className="flex items-end">
            <Button onClick={reload} disabled={loading} className="w-full">
              {loading ? (
                <>
                  <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                  กำลังโหลด...
                </>
              ) : (
                <>
                  <RefreshCw className="h-4 w-4 mr-2" />
                  โหลดข้อมูล
                </>
              )}
            </Button>
          </div>
        </div>
        
        {/* Quick Time Range Buttons */}
        <div className="flex flex-wrap gap-2 mt-4">
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => setRange({
              start: new Date(Date.now() - 1 * 60 * 60 * 1000).toISOString(),
              end: new Date().toISOString()
            })}
          >
            1 ชั่วโมงที่แล้ว
          </Button>
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => setRange({
              start: new Date(Date.now() - 6 * 60 * 60 * 1000).toISOString(),
              end: new Date().toISOString()
            })}
          >
            6 ชั่วโมงที่แล้ว
          </Button>
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => setRange({
              start: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
              end: new Date().toISOString()
            })}
          >
            24 ชั่วโมงที่แล้ว
          </Button>
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => setRange({
              start: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
              end: new Date().toISOString()
            })}
          >
            3 วันที่แล้ว
          </Button>
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => setRange({
              start: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
              end: new Date().toISOString()
            })}
          >
            7 วันที่แล้ว
          </Button>
        </div>
      </Card>

      {/* Error Display */}
      {error && (
        <Card className="p-4 border-red-200 bg-red-50">
          <div className="text-red-600">
            <strong>ข้อผิดพลาด:</strong> {error}
          </div>
        </Card>
      )}

      {/* Data Summary */}
      <Card className="p-6">
        <h3 className="text-lg font-semibold mb-4">สรุปข้อมูล</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
          <div className="text-center">
            <div className="text-2xl font-bold text-blue-600">
              {analytics?.summary?.record_count || history?.records?.length || history?.count || 0}
            </div>
            <div className="text-sm text-muted-foreground">รายการ</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-green-600">
              {analytics?.summary?.vehicle_count || analytics?.vehicles?.length || 0}
            </div>
            <div className="text-sm text-muted-foreground">รถ</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-orange-600">
              {analytics?.summary?.total_distance_km?.toFixed(1) || 0} km
            </div>
            <div className="text-sm text-muted-foreground">ระยะทาง</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-purple-600">
              {analytics?.summary?.avg_speed_kmh?.toFixed(1) || 0} km/h
            </div>
            <div className="text-sm text-muted-foreground">ความเร็วเฉลี่ย</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-red-600">
              {analytics?.summary?.max_speed_kmh?.toFixed(1) || 0} km/h
            </div>
            <div className="text-sm text-muted-foreground">ความเร็วสูงสุด</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-cyan-600">
              {analytics?.summary?.duration_hours?.toFixed(1) || 0} hrs
            </div>
            <div className="text-sm text-muted-foreground">ระยะเวลา</div>
          </div>
        </div>
      </Card>

      {/* No Data Message */}
      {history && (history.count === 0 || (!history.records && !history.data)) && (
        <Card className="p-6">
          <div className="text-center py-8">
            <div className="text-4xl mb-4">📊</div>
            <h3 className="text-lg font-semibold mb-2">ไม่พบข้อมูล</h3>
            <p className="text-sm text-muted-foreground">
              ไม่พบข้อมูลประวัติรถสำหรับเกณฑ์ที่เลือก กรุณาลองเปลี่ยนช่วงเวลาหรือเลือกรถอื่น
            </p>
          </div>
        </Card>
      )}

      {/* History Records Table */}
      {history && history.records && history.records.length > 0 && (
        <Card className="p-6">
          <h3 className="text-lg font-semibold mb-4">รายการประวัติล่าสุด</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b">
                  <th className="text-left p-2">รหัสรถ</th>
                  <th className="text-left p-2">หมวดหมู่</th>
                  <th className="text-left p-2">ตำแหน่ง</th>
                  <th className="text-left p-2">ทิศทาง</th>
                  <th className="text-left p-2">เวลา</th>
                </tr>
              </thead>
              <tbody>
                {history.records.slice(0, 10).map((record: any, index: number) => (
                  <tr key={index} className="border-b hover:bg-gray-50">
                    <td className="p-2 font-mono text-xs">{record.vehicle_id || record.id}</td>
                    <td className="p-2">
                      <Badge variant="outline">{record.category_name || 'Unknown'}</Badge>
                    </td>
                    <td className="p-2 text-xs">
                      {record.lat?.toFixed(6)}, {record.lng?.toFixed(6)}
                    </td>
                    <td className="p-2">{record.bearing || 0}°</td>
                    <td className="p-2 text-xs">
                      {new Date(record.timestamp).toLocaleString('th-TH')}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {history.records.length > 10 && (
            <div className="mt-4 text-center text-sm text-muted-foreground">
              แสดง 10 จาก {history.records.length} รายการ
            </div>
          )}
        </Card>
      )}

      {/* Map */}
      <Card className="p-6">
        <div className="flex items-center gap-2 mb-4">
          <MapPin className="h-5 w-5" />
          <h3 className="text-lg font-semibold">แผนที่เส้นทาง</h3>
        </div>
        {loading ? (
          <Skeleton className="h-[60vh] w-full" />
        ) : (history && (history.records?.length > 0 || history.data?.length > 0)) || (analytics && analytics.summary?.record_count > 0) ? (
          <HistoryMap history={history} analytics={analytics} />
        ) : (
          <div className="h-[60vh] bg-secondary/20 flex items-center justify-center">
            <div className="text-center">
              <div className="text-4xl mb-4">🗺️</div>
              <h3 className="text-lg font-semibold mb-2">No Route Data</h3>
              <p className="text-sm text-muted-foreground">
                No vehicle history found for the selected criteria.
              </p>
              <div className="mt-4 text-xs text-muted-foreground">
                Debug: history={JSON.stringify(history, null, 2)}
              </div>
            </div>
          </div>
        )}
      </Card>

      {/* Charts */}
      <Card className="p-6">
        <div className="flex items-center gap-2 mb-4">
          <BarChart3 className="h-5 w-5" />
          <h3 className="text-lg font-semibold">กราฟการวิเคราะห์</h3>
        </div>
        {loading ? (
          <div className="grid md:grid-cols-2 gap-4">
            <Skeleton className="h-64 w-full" />
            <Skeleton className="h-64 w-full" />
            <Skeleton className="h-64 w-full" />
            <Skeleton className="h-64 w-full" />
          </div>
        ) : (history && (history.records?.length > 0 || history.data?.length > 0)) || (analytics && analytics.summary?.record_count > 0) ? (
          <HistoryCharts
            history={history}
            analytics={analytics}
            heatmap={heatmap}
            trend={trend}
          />
        ) : (
          <div className="h-64 bg-secondary/20 flex items-center justify-center">
            <div className="text-center">
              <div className="text-4xl mb-4">📊</div>
              <h3 className="text-lg font-semibold mb-2">No Chart Data</h3>
              <p className="text-sm text-muted-foreground">
                No data available for analysis charts.
              </p>
              <div className="mt-4 text-xs text-muted-foreground">
                Debug: history={JSON.stringify(history, null, 2)}
              </div>
            </div>
          </div>
        )}
      </Card>
    </div>
  )
}
