import type { Metadata } from 'next'
import { Bai_Jamjuree } from 'next/font/google'
import { Analytics } from '@vercel/analytics/next'
import { ThemeProvider } from '@/components/theme-provider'
import { QueryProvider } from '@/components/query-provider'
import './globals.css'

const baiJamjuree = Bai_Jamjuree({
  subsets: ['thai', 'latin'],
  weight: ['200', '300', '400', '500', '600', '700'],
  style: ['normal', 'italic'],
  variable: '--font-bai-jamjuree',
})

export const metadata: Metadata = {
  title: 'Bolt Taxi Tracker - ระบบติดตามรถแท็กซี่',
  description: 'ระบบติดตามรถแท็กซี่แบบเรียลไทม์ในเชียงใหม่',
  generator: 'v0.app',
  other: {
    'preload-css': 'false',
  },
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="th" suppressHydrationWarning>
      <body className={`${baiJamjuree.variable} font-bai-jamjuree`}>
        <QueryProvider>
          <ThemeProvider
            attribute="class"
            defaultTheme="system"
            enableSystem={true}
            disableTransitionOnChange
          >
            {children}
          </ThemeProvider>
        </QueryProvider>
        <Analytics />
      </body>
    </html>
  )
}
