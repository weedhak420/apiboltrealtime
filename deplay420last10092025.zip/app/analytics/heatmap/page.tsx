"use client"

import { useState, useEffect } from "react"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Skeleton } from "@/components/ui/skeleton"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { RefreshCw, MapPin, TrendingUp, BarChart3, Settings } from "lucide-react"
import { fetchHeatmap } from "@/lib/api"
import dynamic from "next/dynamic"

// Dynamically import the simple map component
const SimpleHeatmapMap = dynamic(() => import("@/components/simple-heatmap-map"), {
  ssr: false,
  loading: () => (
    <div className="h-[500px] bg-secondary/20 flex items-center justify-center">
      <Skeleton className="h-8 w-48 mx-auto" />
    </div>
  ),
})


interface HeatmapData {
  grid_lat: number
  grid_lng: number
  vehicles: number
}

interface HeatmapResponse {
  hotspots: HeatmapData[]
  count: number
  limit: number
  timestamp: string
}

export default function HeatmapPage() {
  const [heatmapData, setHeatmapData] = useState<HeatmapData[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null)
  const [limit, setLimit] = useState(50)
  const [selectedHotspot, setSelectedHotspot] = useState<HeatmapData | null>(null)

  // Suppress WebSocket errors for heatmap page
  useEffect(() => {
    const originalConsoleError = console.error
    console.error = (...args) => {
      const message = args.join(' ')
      if (message.includes('WebSocket') || message.includes('socket.io')) {
        console.warn('WebSocket error suppressed for heatmap:', message)
        return
      }
      originalConsoleError.apply(console, args)
    }

    return () => {
      console.error = originalConsoleError
    }
  }, [])

  const fetchHeatmapData = async () => {
    try {
      setLoading(true)
      setError(null)
      console.log('Fetching heatmap data with limit:', limit)
      const data: HeatmapResponse = await fetchHeatmap(limit)
      console.log('Heatmap API response:', data)
      console.log('Hotspots data:', data.hotspots)
      console.log('Hotspots length:', data.hotspots?.length)
      setHeatmapData(data.hotspots || [])
      setLastUpdate(new Date())
    } catch (err) {
      console.error('Error fetching heatmap data:', err)
      setError(err instanceof Error ? err.message : 'Failed to fetch heatmap data')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchHeatmapData()
    const interval = setInterval(fetchHeatmapData, 30000) // Refresh every 30 seconds
    return () => clearInterval(interval)
  }, [limit])

  const getIntensityColor = (vehicles: number, maxVehicles: number) => {
    const intensity = vehicles / maxVehicles
    if (intensity > 0.8) return 'bg-red-500'
    if (intensity > 0.6) return 'bg-orange-500'
    if (intensity > 0.4) return 'bg-yellow-500'
    if (intensity > 0.2) return 'bg-green-500'
    return 'bg-blue-500'
  }

  const maxVehicles = Math.max(...heatmapData.map(h => h.vehicles), 1)

  if (loading && heatmapData.length === 0) {
    return (
      <DashboardLayout>
        <div className="flex flex-col gap-6">
          <div>
            <h1 className="text-3xl font-bold tracking-tight text-balance">Vehicle Heatmap</h1>
            <p className="text-muted-foreground mt-1">Vehicle concentration hotspots and density analysis</p>
          </div>
          <div className="grid gap-6">
            <Card>
              <CardHeader>
                <Skeleton className="h-6 w-32" />
                <Skeleton className="h-4 w-48" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-32 w-full" />
              </CardContent>
            </Card>
          </div>
        </div>
      </DashboardLayout>
    )
  }

  return (
    <DashboardLayout>
      <div className="flex flex-col gap-6 animate-in fade-in duration-700">
        <div className="flex items-center justify-between animate-in slide-in-from-top duration-500">
          <div>
            <h1 className="text-3xl font-bold tracking-tight text-balance bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              Vehicle Heatmap
            </h1>
            <p className="text-muted-foreground mt-1 animate-in fade-in duration-700 delay-200">
              Vehicle concentration hotspots and density analysis
            </p>
          </div>
          <div className="flex items-center gap-2 animate-in slide-in-from-right duration-500 delay-300">
            {lastUpdate && (
              <span className="text-sm text-muted-foreground animate-in fade-in duration-500 delay-400">
                Last updated: {lastUpdate.toLocaleTimeString()}
              </span>
            )}
            <Select value={limit.toString()} onValueChange={(value) => setLimit(parseInt(value))}>
              <SelectTrigger className="w-32 transition-all duration-300 hover:scale-105">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="25">25 hotspots</SelectItem>
                <SelectItem value="50">50 hotspots</SelectItem>
                <SelectItem value="100">100 hotspots</SelectItem>
                <SelectItem value="250">250 hotspots</SelectItem>
                <SelectItem value="500">500 hotspots</SelectItem>
              </SelectContent>
            </Select>
            <Button 
              onClick={fetchHeatmapData} 
              disabled={loading} 
              size="sm"
              className="transition-all duration-300 hover:scale-105"
            >
              <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
              Refresh
            </Button>
          </div>
        </div>

        {error && (
          <Alert variant="destructive">
            <MapPin className="h-4 w-4" />
            <AlertDescription>
              {error}
            </AlertDescription>
          </Alert>
        )}

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="animate-in fade-in duration-500 delay-500 hover:scale-105 transition-all">
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <MapPin className="h-4 w-4 text-primary" />
                <div>
                  <div className="text-2xl font-bold">{heatmapData.length}</div>
                  <div className="text-sm text-muted-foreground">Hotspots</div>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="animate-in fade-in duration-500 delay-600 hover:scale-105 transition-all">
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <TrendingUp className="h-4 w-4 text-green-500" />
                <div>
                  <div className="text-2xl font-bold">{maxVehicles}</div>
                  <div className="text-sm text-muted-foreground">Max Density</div>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="animate-in fade-in duration-500 delay-700 hover:scale-105 transition-all">
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <BarChart3 className="h-4 w-4 text-blue-500" />
                <div>
                  <div className="text-2xl font-bold">
                    {heatmapData.length > 0 ? 
                      Math.round(heatmapData.reduce((sum, h) => sum + h.vehicles, 0) / heatmapData.length) : 0}
                  </div>
                  <div className="text-sm text-muted-foreground">Avg Density</div>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="animate-in fade-in duration-500 delay-800 hover:scale-105 transition-all">
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <Settings className="h-4 w-4 text-orange-500" />
                <div>
                  <div className="text-2xl font-bold">{limit}</div>
                  <div className="text-sm text-muted-foreground">Limit</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Heatmap Visualization */}
        <Card className="animate-in fade-in duration-700 delay-900 hover:shadow-lg transition-all">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MapPin className="h-5 w-5" />
              Heatmap Visualization
            </CardTitle>
            <CardDescription>
              Interactive heatmap showing vehicle concentration hotspots
            </CardDescription>
          </CardHeader>
          <CardContent>
            <SimpleHeatmapMap
              hotspots={heatmapData}
              onHotspotSelect={setSelectedHotspot}
            />
          </CardContent>
        </Card>

        {/* Hotspots Table */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="h-5 w-5" />
              Hotspot Details
            </CardTitle>
            <CardDescription>
              Detailed information about vehicle concentration hotspots
            </CardDescription>
          </CardHeader>
          <CardContent>
            {heatmapData.length > 0 ? (
              <div className="overflow-x-auto">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {heatmapData
                    .sort((a, b) => b.vehicles - a.vehicles)
                    .map((hotspot, index) => (
                    <div
                      key={`${hotspot.grid_lat}-${hotspot.grid_lng}`}
                      className={`p-4 rounded-lg border cursor-pointer transition-colors hover:bg-secondary/50 ${
                        selectedHotspot?.grid_lat === hotspot.grid_lat && 
                        selectedHotspot?.grid_lng === hotspot.grid_lng
                          ? 'bg-primary/10 border-primary'
                          : 'bg-secondary/20'
                      }`}
                      onClick={() => setSelectedHotspot(hotspot)}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <div className={`w-3 h-3 rounded-full ${getIntensityColor(hotspot.vehicles, maxVehicles)}`}></div>
                          <span className="font-medium">#{index + 1}</span>
                        </div>
                        <Badge variant="outline">
                          {hotspot.vehicles} vehicles
                        </Badge>
                      </div>
                      <div className="text-sm text-muted-foreground">
                        <div>Lat: {hotspot.grid_lat.toFixed(4)}</div>
                        <div>Lng: {hotspot.grid_lng.toFixed(4)}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="text-center py-8">
                <MapPin className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <p className="text-muted-foreground">No heatmap data available</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Selected Hotspot Details */}
        {selectedHotspot && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MapPin className="h-5 w-5" />
                Selected Hotspot Details
              </CardTitle>
              <CardDescription>
                Detailed information for the selected hotspot
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Grid Latitude:</span>
                    <span className="font-mono text-sm">{selectedHotspot.grid_lat.toFixed(6)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Grid Longitude:</span>
                    <span className="font-mono text-sm">{selectedHotspot.grid_lng.toFixed(6)}</span>
                  </div>
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Vehicle Count:</span>
                    <span className="font-medium text-lg">{selectedHotspot.vehicles}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Intensity:</span>
                    <Badge 
                      variant="outline" 
                      className={`${getIntensityColor(selectedHotspot.vehicles, maxVehicles)} text-white`}
                    >
                      {Math.round((selectedHotspot.vehicles / maxVehicles) * 100)}%
                    </Badge>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </DashboardLayout>
  )
}
