"use client"

import { useState, useEffect, useCallback } from "react"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { TrendingUp, AlertCircle } from "lucide-react"

export default function TrendDebugPage() {
  const [loading, setLoading] = useState(true)
  const [data, setData] = useState<any>(null)
  const [interval, setInterval] = useState<'hour' | 'day'>('hour')
  const [renderCount, setRenderCount] = useState(0)
  const [fetchCount, setFetchCount] = useState(0)

  // Track renders to detect infinite loops
  useEffect(() => {
    setRenderCount(prev => prev + 1)
  })

  const fetchTrendData = useCallback(async () => {
    try {
      setLoading(true)
      setFetchCount(prev => prev + 1)
      console.log(`Fetching trend data #${fetchCount + 1} with interval:`, interval)
      
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000))
      
      setData({
        message: `Trend data fetched successfully! (Fetch #${fetchCount + 1})`,
        interval,
        timestamp: new Date().toISOString()
      })
    } catch (err) {
      console.error('Fetch error:', err)
    } finally {
      setLoading(false)
    }
  }, [interval, fetchCount])

  // Initial data fetch
  useEffect(() => {
    fetchTrendData()
  }, [fetchTrendData])

  // Auto-refresh interval
  useEffect(() => {
    const refreshInterval = interval === 'hour' ? 5000 : 10000 // Shorter intervals for testing
    const intervalId = setInterval(fetchTrendData, refreshInterval)
    return () => clearInterval(intervalId)
  }, [fetchTrendData, interval])

  return (
    <DashboardLayout>
      <div className="p-6">
        <div className="flex items-center gap-2 mb-6">
          <TrendingUp className="h-6 w-6 text-primary" />
          <h1 className="text-3xl font-bold">Trend Debug Page</h1>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertCircle className="h-5 w-5" />
                Debug Info
              </CardTitle>
              <CardDescription>
                Monitor for infinite loops and performance issues
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Render Count:</span>
                  <span className="font-mono text-sm">{renderCount}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Fetch Count:</span>
                  <span className="font-mono text-sm">{fetchCount}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Current Interval:</span>
                  <span className="font-mono text-sm">{interval}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Loading:</span>
                  <span className="font-mono text-sm">{loading ? 'Yes' : 'No'}</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Controls</CardTitle>
              <CardDescription>
                Test different intervals and refresh behavior
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex gap-2">
                  <Button 
                    variant={interval === 'hour' ? 'default' : 'outline'}
                    onClick={() => setInterval('hour')}
                    size="sm"
                  >
                    Hourly
                  </Button>
                  <Button 
                    variant={interval === 'day' ? 'default' : 'outline'}
                    onClick={() => setInterval('day')}
                    size="sm"
                  >
                    Daily
                  </Button>
                </div>
                
                <Button 
                  onClick={fetchTrendData}
                  disabled={loading}
                  size="sm"
                  className="w-full"
                >
                  {loading ? 'Fetching...' : 'Manual Fetch'}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Data Output</CardTitle>
            <CardDescription>
              Latest fetched data and status
            </CardDescription>
          </CardHeader>
          <CardContent>
            {data ? (
              <div className="space-y-2">
                <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                  <p className="text-green-800 font-medium">✅ {data.message}</p>
                  <p className="text-green-600 text-sm mt-1">
                    Interval: {data.interval} | Time: {new Date(data.timestamp).toLocaleTimeString()}
                  </p>
                </div>
                <pre className="text-xs bg-gray-100 p-2 rounded overflow-auto">
                  {JSON.stringify(data, null, 2)}
                </pre>
              </div>
            ) : (
              <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                <p className="text-yellow-800">⏳ No data available yet...</p>
              </div>
            )}
          </CardContent>
        </Card>

        <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
          <h3 className="font-medium text-blue-900 mb-2">Debug Instructions:</h3>
          <ul className="text-sm text-blue-800 space-y-1">
            <li>• Watch the Render Count - it should not increase rapidly</li>
            <li>• Fetch Count should only increase when data is actually fetched</li>
            <li>• If Render Count increases without user interaction, there's an infinite loop</li>
            <li>• Try switching between Hourly and Daily intervals</li>
            <li>• Check browser console for any error messages</li>
          </ul>
        </div>
      </div>
    </DashboardLayout>
  )
}
