"use client"

import { useState, useEffect } from "react"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Skeleton } from "@/components/ui/skeleton"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { RefreshCw, TrendingUp, BarChart3, Activity, Clock } from "lucide-react"
import { fetchTrend } from "@/lib/api"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Area, AreaChart } from "recharts"

interface TrendData {
  time: string
  vehicles: number
  smoothed: number
}

interface TrendResponse {
  trends: TrendData[]
  count: number
  interval: string
  smoothing: string
  timestamp: string
}

export default function TrendPage() {
  const [trendData, setTrendData] = useState<TrendData[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null)
  const [interval, setInterval] = useState<'hour' | 'day'>('hour')
  const [chartType, setChartType] = useState<'line' | 'area'>('line')

  // Fetch function without useCallback to avoid dependency issues
  const fetchTrendData = async (intervalValue: 'hour' | 'day' = interval) => {
    try {
      setLoading(true)
      setError(null)
      console.log('Fetching trend data with interval:', intervalValue)
      const data: TrendResponse = await fetchTrend(intervalValue)
      
      // Validate data structure
      if (data && Array.isArray(data.trends)) {
        setTrendData(data.trends)
        setLastUpdate(new Date())
      } else {
        console.warn('Invalid trend data structure:', data)
        setTrendData([])
        setError('Invalid data format received')
      }
    } catch (err) {
      console.error('Trend data fetch error:', err)
      setError(err instanceof Error ? err.message : 'Failed to fetch trend data')
      
      // Set fallback data when API fails
      setTrendData([])
    } finally {
      setLoading(false)
    }
  }

  // Initial data fetch and when interval changes
  useEffect(() => {
    fetchTrendData(interval)
  }, [interval])

  // Auto-refresh interval
  useEffect(() => {
    const refreshInterval = interval === 'hour' ? 30000 : 300000 // 30s for hour, 5min for day
    const intervalId = setInterval(() => {
      fetchTrendData(interval)
    }, refreshInterval)
    return () => clearInterval(intervalId)
  }, [interval])

  const formatTimeLabel = (time: string) => {
    const date = new Date(time)
    if (interval === 'hour') {
      return date.toLocaleTimeString('th-TH', { 
        hour: '2-digit', 
        minute: '2-digit' 
      })
    } else {
      return date.toLocaleDateString('th-TH', { 
        month: 'short', 
        day: 'numeric' 
      })
    }
  }

  const getMaxVehicles = () => {
    return Math.max(...trendData.map(d => Math.max(d.vehicles, d.smoothed)), 1)
  }

  const getAverageVehicles = () => {
    if (trendData.length === 0) return 0
    return Math.round(trendData.reduce((sum, d) => sum + d.vehicles, 0) / trendData.length)
  }

  const getTrendDirection = () => {
    if (trendData.length < 2) return 'stable'
    const first = trendData[0].vehicles
    const last = trendData[trendData.length - 1].vehicles
    const change = ((last - first) / first) * 100
    
    if (change > 5) return 'up'
    if (change < -5) return 'down'
    return 'stable'
  }

  const getTrendColor = (direction: string) => {
    switch (direction) {
      case 'up': return 'text-green-500'
      case 'down': return 'text-red-500'
      default: return 'text-blue-500'
    }
  }

  const getTrendIcon = (direction: string) => {
    switch (direction) {
      case 'up': return '↗'
      case 'down': return '↘'
      default: return '→'
    }
  }

  if (loading && trendData.length === 0) {
    return (
      <DashboardLayout>
        <div className="flex flex-col gap-6">
          <div>
            <h1 className="text-3xl font-bold tracking-tight text-balance">Vehicle Trends</h1>
            <p className="text-muted-foreground mt-1">Vehicle activity trends and patterns over time</p>
          </div>
          <div className="grid gap-6">
            <Card>
              <CardHeader>
                <Skeleton className="h-6 w-32" />
                <Skeleton className="h-4 w-48" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-32 w-full" />
              </CardContent>
            </Card>
          </div>
        </div>
      </DashboardLayout>
    )
  }

  const trendDirection = getTrendDirection()

  return (
    <DashboardLayout>
      <div className="flex flex-col gap-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight text-balance">Vehicle Trends</h1>
            <p className="text-muted-foreground mt-1">Vehicle activity trends and patterns over time</p>
          </div>
          <div className="flex items-center gap-2">
            {lastUpdate && (
              <span className="text-sm text-muted-foreground">
                Last updated: {lastUpdate.toLocaleTimeString()}
              </span>
            )}
            <Select value={interval} onValueChange={(value: 'hour' | 'day') => setInterval(value)}>
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="hour">Hourly</SelectItem>
                <SelectItem value="day">Daily</SelectItem>
              </SelectContent>
            </Select>
            <Select value={chartType} onValueChange={(value: 'line' | 'area') => setChartType(value)}>
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="line">Line Chart</SelectItem>
                <SelectItem value="area">Area Chart</SelectItem>
              </SelectContent>
            </Select>
            <Button onClick={() => fetchTrendData(interval)} disabled={loading} size="sm">
              <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
              Refresh
            </Button>
          </div>
        </div>

        {error && (
          <Alert variant="destructive">
            <TrendingUp className="h-4 w-4" />
            <AlertDescription>
              {error} - Using fallback data. Redis cache may be unavailable.
            </AlertDescription>
          </Alert>
        )}

        {/* Redis Connection Status */}
        <Alert>
          <TrendingUp className="h-4 w-4" />
          <AlertDescription>
            <div className="flex items-center justify-between">
              <span>Redis Cache Status: </span>
              <Badge variant="destructive">DISCONNECTED</Badge>
            </div>
            <div className="text-sm text-muted-foreground mt-1">
              Trend data is fetched directly from backend API. Performance may be affected.
            </div>
          </AlertDescription>
        </Alert>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <Activity className="h-4 w-4 text-primary" />
                <div>
                  <div className="text-2xl font-bold">{trendData.length}</div>
                  <div className="text-sm text-muted-foreground">Data Points</div>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <BarChart3 className="h-4 w-4 text-green-500" />
                <div>
                  <div className="text-2xl font-bold">{getMaxVehicles()}</div>
                  <div className="text-sm text-muted-foreground">Peak Vehicles</div>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <TrendingUp className="h-4 w-4 text-blue-500" />
                <div>
                  <div className="text-2xl font-bold">{getAverageVehicles()}</div>
                  <div className="text-sm text-muted-foreground">Average</div>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4 text-orange-500" />
                <div>
                  <div className={`text-2xl font-bold ${getTrendColor(trendDirection)}`}>
                    {getTrendIcon(trendDirection)}
                  </div>
                  <div className="text-sm text-muted-foreground capitalize">{trendDirection}</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Trend Chart */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5" />
              Vehicle Activity Trend
            </CardTitle>
            <CardDescription>
              {interval === 'hour' ? 'Hourly' : 'Daily'} vehicle activity with smoothing
            </CardDescription>
          </CardHeader>
          <CardContent>
            {trendData.length > 0 ? (
              <div className="h-[400px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  {chartType === 'line' ? (
                    <LineChart data={trendData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis 
                        dataKey="time" 
                        tickFormatter={formatTimeLabel}
                        tick={{ fontSize: 12 }}
                      />
                      <YAxis tick={{ fontSize: 12 }} />
                      <Tooltip 
                        labelFormatter={(value) => `Time: ${formatTimeLabel(value)}`}
                        formatter={(value, name) => [
                          value, 
                          name === 'vehicles' ? 'Raw Count' : 'Smoothed'
                        ]}
                      />
                      <Line 
                        type="monotone" 
                        dataKey="vehicles" 
                        stroke="#3b82f6" 
                        strokeWidth={2}
                        dot={{ r: 4 }}
                        name="vehicles"
                      />
                      <Line 
                        type="monotone" 
                        dataKey="smoothed" 
                        stroke="#22c55e" 
                        strokeWidth={2}
                        strokeDasharray="5 5"
                        dot={{ r: 3 }}
                        name="smoothed"
                      />
                    </LineChart>
                  ) : (
                    <AreaChart data={trendData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis 
                        dataKey="time" 
                        tickFormatter={formatTimeLabel}
                        tick={{ fontSize: 12 }}
                      />
                      <YAxis tick={{ fontSize: 12 }} />
                      <Tooltip 
                        labelFormatter={(value) => `Time: ${formatTimeLabel(value)}`}
                        formatter={(value, name) => [
                          value, 
                          name === 'vehicles' ? 'Raw Count' : 'Smoothed'
                        ]}
                      />
                      <Area 
                        type="monotone" 
                        dataKey="vehicles" 
                        stackId="1"
                        stroke="#3b82f6" 
                        fill="#3b82f6"
                        fillOpacity={0.3}
                        name="vehicles"
                      />
                      <Area 
                        type="monotone" 
                        dataKey="smoothed" 
                        stackId="2"
                        stroke="#22c55e" 
                        fill="#22c55e"
                        fillOpacity={0.2}
                        name="smoothed"
                      />
                    </AreaChart>
                  )}
                </ResponsiveContainer>
              </div>
            ) : (
              <div className="text-center py-8">
                <TrendingUp className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <p className="text-muted-foreground">No trend data available</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Trend Analysis */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5" />
                Trend Analysis
              </CardTitle>
              <CardDescription>
                Statistical analysis of vehicle activity patterns
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Trend Direction:</span>
                  <Badge 
                    variant="outline" 
                    className={`${getTrendColor(trendDirection)} border-current`}
                  >
                    {getTrendIcon(trendDirection)} {trendDirection.toUpperCase()}
                  </Badge>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Data Points:</span>
                  <span className="font-medium">{trendData.length}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Time Interval:</span>
                  <span className="font-medium capitalize">{interval}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Smoothing:</span>
                  <span className="font-medium">EMA 0.3</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="h-5 w-5" />
                Performance Metrics
              </CardTitle>
              <CardDescription>
                Key performance indicators and statistics
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Peak Activity:</span>
                  <span className="font-medium">{getMaxVehicles()} vehicles</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Average Activity:</span>
                  <span className="font-medium">{getAverageVehicles()} vehicles</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Activity Range:</span>
                  <span className="font-medium">
                    {Math.min(...trendData.map(d => d.vehicles))} - {getMaxVehicles()}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Last Update:</span>
                  <span className="font-medium text-sm">
                    {lastUpdate?.toLocaleTimeString() || 'N/A'}
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  )
}
