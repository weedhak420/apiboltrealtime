"use client"

import { useState, useEffect } from "react"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Skeleton } from "@/components/ui/skeleton"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { RefreshCw, BarChart3, MapPin, Navigation, Clock, Activity, TrendingUp } from "lucide-react"
import { fetchAnalyticsHistory } from "@/lib/api"
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip } from "recharts"

interface AnalyticsSummary {
  summary: {
    start: string
    end: string
    record_count: number
    vehicle_count: number
    total_distance_km: number
    avg_speed_kmh: number
    stop_count: number
  }
  bearing_histogram: {
    N: number
    NE: number
    E: number
    SE: number
    S: number
    SW: number
    W: number
    NW: number
  }
  hotspots: Array<{
    grid_lat: number
    grid_lng: number
    vehicles: number
  }>
  vehicles: Array<{
    vehicle_id: string
    points: number
    distance_km: number
    avg_speed_kmh: number
    stops: number
  }>
  timestamp: string
}

export default function AnalyticsSummaryPage() {
  const [analytics, setAnalytics] = useState<AnalyticsSummary | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null)

  const fetchAnalytics = async () => {
    try {
      setLoading(true)
      setError(null)
      
      // Fetch last 24 hours of data
      const endTime = new Date()
      const startTime = new Date(endTime.getTime() - 24 * 60 * 60 * 1000)
      
      const data = await fetchAnalyticsHistory({
        start: startTime.toISOString(),
        end: endTime.toISOString(),
        limit: 1000
      })
      
      setAnalytics(data)
      setLastUpdate(new Date())
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch analytics data')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchAnalytics()
    const interval = setInterval(fetchAnalytics, 60000) // Refresh every minute
    return () => clearInterval(interval)
  }, [])

  const getBearingData = () => {
    if (!analytics?.bearing_histogram) return []
    
    const histogram = analytics.bearing_histogram
    return Object.entries(histogram).map(([direction, count]) => ({
      direction,
      count,
      percentage: Math.round((count / Object.values(histogram).reduce((sum, val) => sum + val, 0)) * 100)
    }))
  }

  const getTopVehicles = () => {
    if (!analytics?.vehicles) return []
    return analytics.vehicles
      .sort((a, b) => b.points - a.points)
      .slice(0, 10)
  }

  const getTopHotspots = () => {
    if (!analytics?.hotspots) return []
    return analytics.hotspots
      .sort((a, b) => b.vehicles - a.vehicles)
      .slice(0, 5)
  }

  const COLORS = ['#3b82f6', '#22c55e', '#f59e0b', '#ef4444', '#8b5cf6', '#06b6d4', '#84cc16', '#f97316']

  if (loading && !analytics) {
    return (
      <DashboardLayout>
        <div className="flex flex-col gap-6">
          <div>
            <h1 className="text-3xl font-bold tracking-tight text-balance">Analytics Summary</h1>
            <p className="text-muted-foreground mt-1">Comprehensive analytics and insights from vehicle data</p>
          </div>
          <div className="grid gap-6">
            <Card>
              <CardHeader>
                <Skeleton className="h-6 w-32" />
                <Skeleton className="h-4 w-48" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-32 w-full" />
              </CardContent>
            </Card>
          </div>
        </div>
      </DashboardLayout>
    )
  }

  return (
    <DashboardLayout>
      <div className="flex flex-col gap-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight text-balance">Analytics Summary</h1>
            <p className="text-muted-foreground mt-1">Comprehensive analytics and insights from vehicle data</p>
          </div>
          <div className="flex items-center gap-2">
            {lastUpdate && (
              <span className="text-sm text-muted-foreground">
                Last updated: {lastUpdate.toLocaleTimeString()}
              </span>
            )}
            <Button onClick={fetchAnalytics} disabled={loading} size="sm">
              <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
              Refresh
            </Button>
          </div>
        </div>

        {error && (
          <Alert variant="destructive">
            <BarChart3 className="h-4 w-4" />
            <AlertDescription>
              {error}
            </AlertDescription>
          </Alert>
        )}

        {analytics ? (
          <>
            {/* Summary Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center gap-2">
                    <Activity className="h-4 w-4 text-primary" />
                    <div>
                      <div className="text-2xl font-bold">{analytics.summary.record_count}</div>
                      <div className="text-sm text-muted-foreground">Total Records</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center gap-2">
                    <Navigation className="h-4 w-4 text-green-500" />
                    <div>
                      <div className="text-2xl font-bold">{analytics.summary.vehicle_count}</div>
                      <div className="text-sm text-muted-foreground">Unique Vehicles</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center gap-2">
                    <MapPin className="h-4 w-4 text-blue-500" />
                    <div>
                      <div className="text-2xl font-bold">{analytics.summary.total_distance_km.toFixed(1)}</div>
                      <div className="text-sm text-muted-foreground">Total Distance (km)</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center gap-2">
                    <TrendingUp className="h-4 w-4 text-orange-500" />
                    <div>
                      <div className="text-2xl font-bold">{analytics.summary.avg_speed_kmh.toFixed(1)}</div>
                      <div className="text-sm text-muted-foreground">Avg Speed (km/h)</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Charts Row */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Bearing Distribution */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Navigation className="h-5 w-5" />
                    Bearing Distribution
                  </CardTitle>
                  <CardDescription>
                    Vehicle movement direction analysis
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-[300px] w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={getBearingData()}
                          cx="50%"
                          cy="50%"
                          labelLine={false}
                          label={({ direction, percentage }) => `${direction} (${percentage}%)`}
                          outerRadius={80}
                          fill="#8884d8"
                          dataKey="count"
                        >
                          {getBearingData().map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              {/* Top Vehicles */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Activity className="h-5 w-5" />
                    Top Vehicles by Activity
                  </CardTitle>
                  <CardDescription>
                    Most active vehicles by data points
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-[300px] w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={getTopVehicles()}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis 
                          dataKey="vehicle_id" 
                          tick={{ fontSize: 10 }}
                          angle={-45}
                          textAnchor="end"
                          height={80}
                        />
                        <YAxis tick={{ fontSize: 12 }} />
                        <Tooltip 
                          formatter={(value, name) => [
                            value, 
                            name === 'points' ? 'Data Points' : name
                          ]}
                        />
                        <Bar dataKey="points" fill="#3b82f6" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Data Tables */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Top Hotspots */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <MapPin className="h-5 w-5" />
                    Top Hotspots
                  </CardTitle>
                  <CardDescription>
                    Areas with highest vehicle concentration
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {getTopHotspots().map((hotspot, index) => (
                      <div key={`${hotspot.grid_lat}-${hotspot.grid_lng}`} className="flex items-center justify-between p-3 bg-secondary/20 rounded-lg">
                        <div className="flex items-center gap-3">
                          <div className="w-6 h-6 rounded-full bg-primary text-white flex items-center justify-center text-xs font-bold">
                            {index + 1}
                          </div>
                          <div>
                            <div className="font-medium">
                              {hotspot.grid_lat.toFixed(4)}, {hotspot.grid_lng.toFixed(4)}
                            </div>
                            <div className="text-sm text-muted-foreground">
                              {hotspot.vehicles} vehicles
                            </div>
                          </div>
                        </div>
                        <Badge variant="outline">
                          {hotspot.vehicles} vehicles
                        </Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Vehicle Performance */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="h-5 w-5" />
                    Vehicle Performance
                  </CardTitle>
                  <CardDescription>
                    Performance metrics for tracked vehicles
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {getTopVehicles().slice(0, 5).map((vehicle, index) => (
                      <div key={vehicle.vehicle_id} className="flex items-center justify-between p-3 bg-secondary/20 rounded-lg">
                        <div className="flex items-center gap-3">
                          <div className="w-6 h-6 rounded-full bg-green-500 text-white flex items-center justify-center text-xs font-bold">
                            {index + 1}
                          </div>
                          <div>
                            <div className="font-medium font-mono text-sm">
                              {vehicle.vehicle_id.slice(0, 12)}...
                            </div>
                            <div className="text-sm text-muted-foreground">
                              {vehicle.points} points • {vehicle.stops} stops
                            </div>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-sm font-medium">
                            {vehicle.distance_km.toFixed(1)} km
                          </div>
                          <div className="text-xs text-muted-foreground">
                            {vehicle.avg_speed_kmh.toFixed(1)} km/h
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Time Range Info */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Clock className="h-5 w-5" />
                  Analysis Period
                </CardTitle>
                <CardDescription>
                  Time range and data collection information
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="text-center p-4 bg-secondary/20 rounded-lg">
                    <div className="text-lg font-bold">
                      {new Date(analytics.summary.start).toLocaleDateString()}
                    </div>
                    <div className="text-sm text-muted-foreground">Start Date</div>
                  </div>
                  <div className="text-center p-4 bg-secondary/20 rounded-lg">
                    <div className="text-lg font-bold">
                      {new Date(analytics.summary.end).toLocaleDateString()}
                    </div>
                    <div className="text-sm text-muted-foreground">End Date</div>
                  </div>
                  <div className="text-center p-4 bg-secondary/20 rounded-lg">
                    <div className="text-lg font-bold">
                      {analytics.summary.stop_count}
                    </div>
                    <div className="text-sm text-muted-foreground">Total Stops</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </>
        ) : (
          <div className="text-center py-8">
            <BarChart3 className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
            <p className="text-muted-foreground">No analytics data available</p>
          </div>
        )}
      </div>
    </DashboardLayout>
  )
}
