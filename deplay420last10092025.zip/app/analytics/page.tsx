import { DashboardLayout } from "@/components/dashboard-layout"
import { AnalyticsCharts } from "@/components/analytics-charts"

export default function AnalyticsPage() {
  return (
    <DashboardLayout>
      <div className="flex flex-col gap-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">การวิเคราะห์</h1>
          <p className="text-muted-foreground mt-1">การกระจายรถและแนวโน้ม</p>
        </div>

        <AnalyticsCharts />
      </div>
    </DashboardLayout>
  )
}
