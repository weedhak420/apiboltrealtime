"use client"

import { Suspense } from "react"
import dynamic from "next/dynamic"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Skeleton } from "@/components/ui/skeleton"

// Lazy load the optimized map component
const OptimizedLiveMap = dynamic(() => import("@/components/optimized-live-map"), {
  ssr: false,
  loading: () => (
    <div className="w-full h-[600px] bg-gray-100 rounded-lg flex items-center justify-center">
      <div className="space-y-4 w-full max-w-md">
        <Skeleton className="h-4 w-full" />
        <Skeleton className="h-4 w-3/4" />
        <Skeleton className="h-4 w-1/2" />
        <div className="flex space-x-2">
          <Skeleton className="h-8 w-8 rounded-full" />
          <Skeleton className="h-8 w-8 rounded-full" />
          <Skeleton className="h-8 w-8 rounded-full" />
        </div>
      </div>
    </div>
  )
})

// Map controls component
const MapControls = () => (
  <Card className="mb-6">
    <CardHeader>
      <CardTitle>Map Controls</CardTitle>
    </CardHeader>
    <CardContent>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="space-y-2">
          <label className="text-sm font-medium">Vehicle Filter</label>
          <select className="w-full p-2 border rounded-md">
            <option value="all">All Vehicles</option>
            <option value="moving">Moving Only</option>
            <option value="stopped">Stopped Only</option>
          </select>
        </div>
        <div className="space-y-2">
          <label className="text-sm font-medium">Update Interval</label>
          <select className="w-full p-2 border rounded-md">
            <option value="1">1 second</option>
            <option value="2">2 seconds</option>
            <option value="5">5 seconds</option>
            <option value="10">10 seconds</option>
          </select>
        </div>
        <div className="space-y-2">
          <label className="text-sm font-medium">Map Style</label>
          <select className="w-full p-2 border rounded-md">
            <option value="standard">Standard</option>
            <option value="satellite">Satellite</option>
            <option value="terrain">Terrain</option>
          </select>
        </div>
      </div>
    </CardContent>
  </Card>
)

// Performance metrics component
const PerformanceMetrics = () => (
  <Card className="mb-6">
    <CardHeader>
      <CardTitle>Performance Metrics</CardTitle>
    </CardHeader>
    <CardContent>
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="text-center">
          <div className="text-2xl font-bold text-green-600">~50ms</div>
          <div className="text-sm text-gray-500">Cache Hit Time</div>
        </div>
        <div className="text-center">
          <div className="text-2xl font-bold text-blue-600">500+</div>
          <div className="text-sm text-gray-500">Vehicles Clustered</div>
        </div>
        <div className="text-center">
          <div className="text-2xl font-bold text-purple-600">~1s</div>
          <div className="text-sm text-gray-500">Initial Load</div>
        </div>
        <div className="text-center">
          <div className="text-2xl font-bold text-orange-600">90%</div>
          <div className="text-sm text-gray-500">Cache Hit Rate</div>
        </div>
      </div>
    </CardContent>
  </Card>
)

export default function OptimizedMapPage() {
  return (
    <div className="container mx-auto p-4 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Optimized Live Map</h1>
          <p className="text-gray-600">
            High-performance vehicle tracking with marker clustering and caching
          </p>
        </div>
        <div className="flex space-x-2">
          <button className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">
            Refresh
          </button>
          <button className="px-4 py-2 border border-gray-300 rounded hover:bg-gray-50">
            Settings
          </button>
        </div>
      </div>

      <PerformanceMetrics />
      
      <MapControls />

      <Card>
        <CardHeader>
          <CardTitle>Live Vehicle Tracking</CardTitle>
        </CardHeader>
        <CardContent>
          <Suspense fallback={
            <div className="w-full h-[600px] bg-gray-100 rounded-lg flex items-center justify-center">
              <div className="space-y-4 w-full max-w-md">
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-3/4" />
                <Skeleton className="h-4 w-1/2" />
                <div className="flex space-x-2">
                  <Skeleton className="h-8 w-8 rounded-full" />
                  <Skeleton className="h-8 w-8 rounded-full" />
                  <Skeleton className="h-8 w-8 rounded-full" />
                </div>
              </div>
            </div>
          }>
            <OptimizedLiveMap />
          </Suspense>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Optimization Features</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="space-y-2">
              <h3 className="font-semibold text-green-600">✅ Marker Clustering</h3>
              <p className="text-sm text-gray-600">
                Groups nearby vehicles to reduce rendering load
              </p>
            </div>
            <div className="space-y-2">
              <h3 className="font-semibold text-blue-600">✅ React Query Caching</h3>
              <p className="text-sm text-gray-600">
                5-10 second cache reduces API calls by 90%
              </p>
            </div>
            <div className="space-y-2">
              <h3 className="font-semibold text-purple-600">✅ WebSocket Updates</h3>
              <p className="text-sm text-gray-600">
                Real-time updates only for changed vehicles
              </p>
            </div>
            <div className="space-y-2">
              <h3 className="font-semibold text-orange-600">✅ Lazy Loading</h3>
              <p className="text-sm text-gray-600">
                Components load on-demand for faster initial render
              </p>
            </div>
            <div className="space-y-2">
              <h3 className="font-semibold text-red-600">✅ Skeleton Loading</h3>
              <p className="text-sm text-gray-600">
                Better UX with loading states instead of blank screens
              </p>
            </div>
            <div className="space-y-2">
              <h3 className="font-semibold text-indigo-600">✅ Memoization</h3>
              <p className="text-sm text-gray-600">
                React.memo prevents unnecessary re-renders
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
