import { DashboardLayout } from "@/components/dashboard-layout"
import RealtimeCharts from "@/components/realtime-charts"
import { ConnectionBanner } from "@/components/connection-banner"

export default function Home() {
  return (
    <DashboardLayout>
      <div className="flex flex-col gap-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight text-balance">ระบบติดตามรถแท็กซี่ Bolt</h1>
            <p className="text-muted-foreground mt-1">การวิเคราะห์และติดตามแบบเรียลไทม์ในเชียงใหม่</p>
          </div>
        </div>

        <ConnectionBanner />

        <RealtimeCharts />
      </div>
    </DashboardLayout>
  )
}
