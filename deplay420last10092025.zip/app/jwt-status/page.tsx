"use client"

import { useState, useEffect } from "react"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Skeleton } from "@/components/ui/skeleton"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { RefreshCw, Shield, Clock, AlertTriangle, CheckCircle, XCircle } from "lucide-react"
import { fetchJWTStatus } from "@/lib/api"

interface JWTStatus {
  status: string
  token_info?: {
    expires_at: string
    issued_at: string
    user_id: number
    login_id: number
    is_valid: boolean
    time_until_expiry: string
  }
  rate_limiting?: {
    max_concurrent: number
    requests_per_second: number
    current_requests: number
  }
  error_handling?: {
    retry_attempts: number
    last_error: string | null
    error_1005_count: number
    error_210_count: number
    http_429_count: number
  }
  message?: string
}

export default function JWTStatusPage() {
  const [jwtStatus, setJwtStatus] = useState<JWTStatus | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [lastRefresh, setLastRefresh] = useState<Date | null>(null)

  const fetchStatus = async () => {
    try {
      setLoading(true)
      setError(null)
      const status = await fetchJWTStatus()
      setJwtStatus(status)
      setLastRefresh(new Date())
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch JWT status')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchStatus()
    const interval = setInterval(fetchStatus, 30000) // Refresh every 30 seconds
    return () => clearInterval(interval)
  }, [])

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
        return 'bg-green-500'
      case 'expired':
        return 'bg-red-500'
      case 'no_token':
        return 'bg-yellow-500'
      default:
        return 'bg-gray-500'
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'active':
        return <CheckCircle className="h-4 w-4 text-green-500" />
      case 'expired':
        return <XCircle className="h-4 w-4 text-red-500" />
      case 'no_token':
        return <AlertTriangle className="h-4 w-4 text-yellow-500" />
      default:
        return <Shield className="h-4 w-4 text-gray-500" />
    }
  }

  const formatTimeUntilExpiry = (timeString: string) => {
    // Parse time string like "45m30s" or "2h15m"
    const match = timeString.match(/(\d+)h|(\d+)m|(\d+)s/)
    if (match) {
      return timeString
    }
    return timeString
  }

  if (loading && !jwtStatus) {
    return (
      <DashboardLayout>
        <div className="flex flex-col gap-6">
          <div>
            <h1 className="text-3xl font-bold tracking-tight text-balance">JWT Token Status</h1>
            <p className="text-muted-foreground mt-1">Monitor JWT token status and authentication health</p>
          </div>
          <div className="grid gap-6">
            <Card>
              <CardHeader>
                <Skeleton className="h-6 w-32" />
                <Skeleton className="h-4 w-48" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-32 w-full" />
              </CardContent>
            </Card>
          </div>
        </div>
      </DashboardLayout>
    )
  }

  return (
    <DashboardLayout>
      <div className="flex flex-col gap-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight text-balance">JWT Token Status</h1>
            <p className="text-muted-foreground mt-1">Monitor JWT token status and authentication health</p>
          </div>
          <div className="flex items-center gap-2">
            {lastRefresh && (
              <span className="text-sm text-muted-foreground">
                Last updated: {lastRefresh.toLocaleTimeString()}
              </span>
            )}
            <Button onClick={fetchStatus} disabled={loading} size="sm">
              <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
              Refresh
            </Button>
          </div>
        </div>

        {error && (
          <Alert variant="destructive">
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>
              {error}
            </AlertDescription>
          </Alert>
        )}

        <div className="grid gap-6">
          {/* Main Status Card */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-5 w-5" />
                Token Status
              </CardTitle>
              <CardDescription>
                Current JWT token authentication status
              </CardDescription>
            </CardHeader>
            <CardContent>
              {jwtStatus ? (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      {getStatusIcon(jwtStatus.status)}
                      <span className="font-medium capitalize">{jwtStatus.status}</span>
                    </div>
                    <Badge 
                      variant="outline" 
                      className={`${getStatusColor(jwtStatus.status)} text-white`}
                    >
                      {jwtStatus.status.toUpperCase()}
                    </Badge>
                  </div>

                  {jwtStatus.message && (
                    <Alert>
                      <AlertTriangle className="h-4 w-4" />
                      <AlertDescription>{jwtStatus.message}</AlertDescription>
                    </Alert>
                  )}

                  {jwtStatus.token_info && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span className="text-sm text-muted-foreground">User ID:</span>
                          <span className="font-medium">{jwtStatus.token_info.user_id}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-sm text-muted-foreground">Login ID:</span>
                          <span className="font-medium">{jwtStatus.token_info.login_id}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-sm text-muted-foreground">Valid:</span>
                          <Badge variant={jwtStatus.token_info.is_valid ? "default" : "destructive"}>
                            {jwtStatus.token_info.is_valid ? "Yes" : "No"}
                          </Badge>
                        </div>
                      </div>
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span className="text-sm text-muted-foreground">Issued At:</span>
                          <span className="font-medium text-sm">
                            {new Date(jwtStatus.token_info.issued_at).toLocaleString()}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-sm text-muted-foreground">Expires At:</span>
                          <span className="font-medium text-sm">
                            {new Date(jwtStatus.token_info.expires_at).toLocaleString()}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-sm text-muted-foreground">Time Until Expiry:</span>
                          <span className="font-medium text-sm">
                            {formatTimeUntilExpiry(jwtStatus.token_info.time_until_expiry)}
                          </span>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                <div className="text-center py-8">
                  <Shield className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                  <p className="text-muted-foreground">No JWT status data available</p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Rate Limiting Card */}
          {jwtStatus?.rate_limiting && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Clock className="h-5 w-5" />
                  Rate Limiting
                </CardTitle>
                <CardDescription>
                  Current rate limiting configuration and usage
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="text-center p-4 bg-secondary/20 rounded-lg">
                    <div className="text-2xl font-bold text-primary">
                      {jwtStatus.rate_limiting.max_concurrent}
                    </div>
                    <div className="text-sm text-muted-foreground">Max Concurrent</div>
                  </div>
                  <div className="text-center p-4 bg-secondary/20 rounded-lg">
                    <div className="text-2xl font-bold text-primary">
                      {jwtStatus.rate_limiting.requests_per_second}
                    </div>
                    <div className="text-sm text-muted-foreground">Requests/Second</div>
                  </div>
                  <div className="text-center p-4 bg-secondary/20 rounded-lg">
                    <div className="text-2xl font-bold text-primary">
                      {jwtStatus.rate_limiting.current_requests}
                    </div>
                    <div className="text-sm text-muted-foreground">Current Requests</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Error Handling Card */}
          {jwtStatus?.error_handling && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5" />
                  Error Handling
                </CardTitle>
                <CardDescription>
                  Error statistics and retry attempts
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  <div className="text-center p-4 bg-secondary/20 rounded-lg">
                    <div className="text-2xl font-bold text-primary">
                      {jwtStatus.error_handling.retry_attempts}
                    </div>
                    <div className="text-sm text-muted-foreground">Retry Attempts</div>
                  </div>
                  <div className="text-center p-4 bg-secondary/20 rounded-lg">
                    <div className="text-2xl font-bold text-orange-500">
                      {jwtStatus.error_handling.error_1005_count}
                    </div>
                    <div className="text-sm text-muted-foreground">Error 1005 (Too Many Requests)</div>
                  </div>
                  <div className="text-center p-4 bg-secondary/20 rounded-lg">
                    <div className="text-2xl font-bold text-red-500">
                      {jwtStatus.error_handling.error_210_count}
                    </div>
                    <div className="text-sm text-muted-foreground">Error 210 (Invalid Token)</div>
                  </div>
                  <div className="text-center p-4 bg-secondary/20 rounded-lg">
                    <div className="text-2xl font-bold text-yellow-500">
                      {jwtStatus.error_handling.http_429_count}
                    </div>
                    <div className="text-sm text-muted-foreground">HTTP 429 (Rate Limited)</div>
                  </div>
                </div>
                
                {jwtStatus.error_handling.last_error && (
                  <div className="mt-4 p-3 bg-destructive/10 border border-destructive/20 rounded-lg">
                    <div className="text-sm font-medium text-destructive">Last Error:</div>
                    <div className="text-sm text-destructive/80 mt-1">
                      {jwtStatus.error_handling.last_error}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </DashboardLayout>
  )
}
