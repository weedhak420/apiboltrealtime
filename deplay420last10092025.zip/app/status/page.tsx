"use client"

import { useEffect, useState } from "react"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { CheckCircle, XCircle, AlertCircle, RefreshCw } from "lucide-react"

interface StatusCheck {
  name: string
  status: "connected" | "disconnected" | "error"
  responseTime?: number
  error?: string
}

export default function StatusPage() {
  const [statusChecks, setStatusChecks] = useState<StatusCheck[]>([])
  const [loading, setLoading] = useState(false)

  const checkBackendStatus = async () => {
    setLoading(true)
    const checks: StatusCheck[] = []

    // Check main API endpoints
    const endpoints = [
      { name: "Vehicles Latest", url: "/api/vehicles/latest" },
      { name: "Analytics Heatmap", url: "/api/analytics/heatmap" },
      { name: "Analytics Trend", url: "/api/analytics/trend" },
      { name: "Vehicle History", url: "/api/vehicles/history" },
      { name: "Analytics History", url: "/api/analytics/history" },
      { name: "Cache Status", url: "/api/cache/status" }
    ]

    for (const endpoint of endpoints) {
      const startTime = Date.now()
      try {
        const response = await fetch(endpoint.url, { 
          cache: "no-store",
          signal: AbortSignal.timeout(5000)
        })
        const responseTime = Date.now() - startTime
        
        if (response.ok) {
          checks.push({
            name: endpoint.name,
            status: "connected",
            responseTime
          })
        } else {
          checks.push({
            name: endpoint.name,
            status: "error",
            responseTime,
            error: `HTTP ${response.status}`
          })
        }
      } catch (error) {
        const responseTime = Date.now() - startTime
        checks.push({
          name: endpoint.name,
          status: "disconnected",
          responseTime,
          error: error instanceof Error ? error.message : "Unknown error"
        })
      }
    }

    setStatusChecks(checks)
    setLoading(false)
  }

  useEffect(() => {
    checkBackendStatus()
  }, [])

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "connected":
        return <CheckCircle className="h-5 w-5 text-green-500" />
      case "error":
        return <AlertCircle className="h-5 w-5 text-yellow-500" />
      default:
        return <XCircle className="h-5 w-5 text-red-500" />
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "connected":
        return <Badge className="bg-green-500">Connected</Badge>
      case "error":
        return <Badge className="bg-yellow-500">Error</Badge>
      default:
        return <Badge className="bg-red-500">Disconnected</Badge>
    }
  }

  const overallStatus = statusChecks.length > 0 
    ? statusChecks.every(check => check.status === "connected") 
      ? "healthy" 
      : statusChecks.some(check => check.status === "connected")
        ? "partial"
        : "unhealthy"
    : "unknown"

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">System Status</h1>
          <p className="text-muted-foreground">
            Monitor backend API connectivity and performance
          </p>
        </div>
        <div className="flex items-center gap-4">
          <Badge 
            variant="outline" 
            className={
              overallStatus === "healthy" 
                ? "border-green-500 text-green-500" 
                : overallStatus === "partial"
                ? "border-yellow-500 text-yellow-500"
                : "border-red-500 text-red-500"
            }
          >
            {overallStatus === "healthy" ? "All Systems Operational" :
             overallStatus === "partial" ? "Partial Connectivity" :
             "Backend Unavailable"}
          </Badge>
          <Button onClick={checkBackendStatus} disabled={loading}>
            {loading ? (
              <>
                <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                Checking...
              </>
            ) : (
              <>
                <RefreshCw className="h-4 w-4 mr-2" />
                Refresh
              </>
            )}
          </Button>
        </div>
      </div>

      {/* Status Grid */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {statusChecks.map((check, index) => (
          <Card key={index} className="p-4">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                {getStatusIcon(check.status)}
                <span className="font-medium">{check.name}</span>
              </div>
              {getStatusBadge(check.status)}
            </div>
            
            {check.responseTime && (
              <div className="text-sm text-muted-foreground">
                Response time: {check.responseTime}ms
              </div>
            )}
            
            {check.error && (
              <div className="text-sm text-red-500 mt-1">
                Error: {check.error}
              </div>
            )}
          </Card>
        ))}
      </div>

      {/* Backend Information */}
      <Card className="p-6">
        <h3 className="text-lg font-semibold mb-4">Backend Configuration</h3>
        <div className="space-y-2 text-sm">
          <div className="flex justify-between">
            <span className="text-muted-foreground">API Base URL:</span>
            <span className="font-mono">{process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000"}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">WebSocket URL:</span>
            <span className="font-mono">{process.env.NEXT_PUBLIC_WS_URL || "ws://localhost:8000"}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">Fallback Mode:</span>
            <span className="text-green-500">Enabled</span>
          </div>
        </div>
      </Card>

      {/* Instructions */}
      <Card className="p-6">
        <h3 className="text-lg font-semibold mb-4">Getting Started</h3>
        <div className="space-y-3 text-sm">
          <p>
            <strong>To connect to your Go backend:</strong>
          </p>
          <ol className="list-decimal list-inside space-y-1 ml-4">
            <li>Start your Go API server on port 8000</li>
            <li>Ensure the server is accessible at <code className="bg-secondary px-1 rounded">http://localhost:8000</code></li>
            <li>Click "Refresh" to check connectivity</li>
            <li>Once connected, you'll see real-time data instead of fallback data</li>
          </ol>
          <p className="text-muted-foreground">
            <strong>Note:</strong> The application will work with fallback data even when the backend is not available.
          </p>
        </div>
      </Card>
    </div>
  )
}
