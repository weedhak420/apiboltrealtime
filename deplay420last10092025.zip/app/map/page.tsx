import { DashboardLayout } from "@/components/dashboard-layout"
import OptimizedLiveMapWithData from "@/components/optimized-live-map-with-data"

export default function MapPage() {
  return (
    <DashboardLayout>
      <div className="flex flex-col gap-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-balance">แผนที่รถแบบเรียลไทม์</h1>
          <p className="text-muted-foreground mt-1">การติดตามรถแบบเรียลไทม์ประสิทธิภาพสูงในเชียงใหม่</p>
        </div>
        <OptimizedLiveMapWithData 
          maxVehicles={500}
          enableClustering={true}
          animationDuration={800}
          refreshInterval={5000}
        />
      </div>
    </DashboardLayout>
  )
}
