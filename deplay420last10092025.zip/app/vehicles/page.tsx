"use client"

import { useState, useEffect } from "react"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Skeleton } from "@/components/ui/skeleton"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { RefreshCw, Car, MapPin, Navigation, Clock, Eye } from "lucide-react"
import { fetchLatestVehicles } from "@/lib/api"
import { Vehicle } from "@/types/vehicles"
import dynamic from "next/dynamic"

// Dynamically import the map component with fallback
const LiveMapFull = dynamic(() => import("@/components/live-map-full"), {
  ssr: false,
  loading: () => (
    <div className="h-[400px] bg-secondary/20 flex items-center justify-center">
      <div className="text-center">
        <Skeleton className="h-8 w-48 mx-auto mb-4" />
        <Skeleton className="h-4 w-32 mx-auto" />
        <p className="text-sm text-muted-foreground mt-2">Loading map...</p>
      </div>
    </div>
  ),
})

// Fallback map component
const SimpleVehicleMap = dynamic(() => import("@/components/simple-vehicle-map"), {
  ssr: false,
  loading: () => (
    <div className="h-[400px] bg-secondary/20 flex items-center justify-center">
      <div className="text-center">
        <Skeleton className="h-8 w-48 mx-auto mb-4" />
        <Skeleton className="h-4 w-32 mx-auto" />
        <p className="text-sm text-muted-foreground mt-2">Loading fallback map...</p>
      </div>
    </div>
  ),
})

export default function VehiclesPage() {
  const [vehicles, setVehicles] = useState<Vehicle[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null)
  const [selectedVehicle, setSelectedVehicle] = useState<Vehicle | null>(null)
  const [showMap, setShowMap] = useState(false)
  const [mapError, setMapError] = useState(false)

  const fetchVehicles = async () => {
    try {
      setLoading(true)
      setError(null)
      const data = await fetchLatestVehicles()
      setVehicles(data.vehicles || [])
      setLastUpdate(new Date())
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch vehicles')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchVehicles()
    const interval = setInterval(fetchVehicles, 5000) // Refresh every 5 seconds
    return () => clearInterval(interval)
  }, [])

  // Handle map errors
  useEffect(() => {
    const handleMapError = () => {
      console.warn('Map component failed, switching to fallback')
      setMapError(true)
    }

    // Listen for map errors
    window.addEventListener('map-error', handleMapError)
    return () => window.removeEventListener('map-error', handleMapError)
  }, [])

  const getCategoryColor = (category: string) => {
    switch (category?.toLowerCase()) {
      case 'bolt_taxi':
        return 'bg-blue-500'
      case 'taxi':
        return 'bg-green-500'
      default:
        return 'bg-gray-500'
    }
  }

  const formatBearing = (bearing: number) => {
    const directions = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW']
    const index = Math.round(bearing / 45) % 8
    return directions[index]
  }

  if (loading && vehicles.length === 0) {
    return (
      <DashboardLayout>
        <div className="flex flex-col gap-6">
          <div>
            <h1 className="text-3xl font-bold tracking-tight text-balance">Live Vehicles</h1>
            <p className="text-muted-foreground mt-1">Real-time vehicle tracking and monitoring</p>
          </div>
          <div className="grid gap-6">
            <Card>
              <CardHeader>
                <Skeleton className="h-6 w-32" />
                <Skeleton className="h-4 w-48" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-32 w-full" />
              </CardContent>
            </Card>
          </div>
        </div>
      </DashboardLayout>
    )
  }

  return (
    <DashboardLayout>
      <div className="flex flex-col gap-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight text-balance">Live Vehicles</h1>
            <p className="text-muted-foreground mt-1">Real-time vehicle tracking and monitoring</p>
          </div>
          <div className="flex items-center gap-2">
            {lastUpdate && (
              <span className="text-sm text-muted-foreground">
                Last updated: {lastUpdate.toLocaleTimeString()}
              </span>
            )}
            <Button onClick={fetchVehicles} disabled={loading} size="sm">
              <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
              Refresh
            </Button>
            <Button 
              variant="outline" 
              onClick={() => setShowMap(!showMap)}
              size="sm"
            >
              <MapPin className="h-4 w-4 mr-2" />
              {showMap ? 'Hide Map' : 'Show Map'}
            </Button>
            {showMap && mapError && (
              <Button 
                variant="outline" 
                onClick={() => setMapError(false)}
                size="sm"
              >
                <RefreshCw className="h-4 w-4 mr-2" />
                Retry Map
              </Button>
            )}
          </div>
        </div>

        {error && (
          <Alert variant="destructive">
            <Car className="h-4 w-4" />
            <AlertDescription>
              {error}
            </AlertDescription>
          </Alert>
        )}

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <Car className="h-4 w-4 text-primary" />
                <div>
                  <div className="text-2xl font-bold">{vehicles.length}</div>
                  <div className="text-sm text-muted-foreground">Total Vehicles</div>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <Navigation className="h-4 w-4 text-green-500" />
                <div>
                  <div className="text-2xl font-bold">
                    {vehicles.filter(v => v.bearing && v.bearing > 0).length}
                  </div>
                  <div className="text-sm text-muted-foreground">Moving</div>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <MapPin className="h-4 w-4 text-blue-500" />
                <div>
                  <div className="text-2xl font-bold">
                    {new Set(vehicles.map(v => v.source_location)).size}
                  </div>
                  <div className="text-sm text-muted-foreground">Locations</div>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4 text-orange-500" />
                <div>
                  <div className="text-2xl font-bold">
                    {lastUpdate ? Math.round((Date.now() - lastUpdate.getTime()) / 1000) : 0}s
                  </div>
                  <div className="text-sm text-muted-foreground">Last Update</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Map View */}
        {showMap && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MapPin className="h-5 w-5" />
                Vehicle Map
              </CardTitle>
              <CardDescription>
                Interactive map showing vehicle locations
              </CardDescription>
            </CardHeader>
            <CardContent>
              {!mapError ? (
                <LiveMapFull
                  vehicles={vehicles}
                  selectedVehicle={selectedVehicle}
                  onVehicleSelect={setSelectedVehicle}
                />
              ) : (
                <SimpleVehicleMap
                  vehicles={vehicles}
                  selectedVehicle={selectedVehicle}
                  onVehicleSelect={setSelectedVehicle}
                />
              )}
            </CardContent>
          </Card>
        )}

        {/* Vehicles Table */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Car className="h-5 w-5" />
              Vehicle Details
            </CardTitle>
            <CardDescription>
              Detailed information about all tracked vehicles
            </CardDescription>
          </CardHeader>
          <CardContent>
            {vehicles.length > 0 ? (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Vehicle ID</TableHead>
                      <TableHead>Category</TableHead>
                      <TableHead>Location</TableHead>
                      <TableHead>Coordinates</TableHead>
                      <TableHead>Bearing</TableHead>
                      <TableHead>Distance</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {vehicles.map((vehicle, index) => (
                      <TableRow key={`${vehicle.id}-${index}`}>
                        <TableCell className="font-mono text-sm">
                          {vehicle.id.slice(0, 12)}...
                        </TableCell>
                        <TableCell>
                          <Badge 
                            variant="outline" 
                            className={`${getCategoryColor(vehicle.category_name)} text-white`}
                          >
                            {vehicle.category_name || 'Unknown'}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <MapPin className="h-3 w-3 text-muted-foreground" />
                            <span className="text-sm">
                              {vehicle.source_location || 'Unknown'}
                            </span>
                          </div>
                        </TableCell>
                        <TableCell className="font-mono text-xs">
                          {vehicle.lat.toFixed(4)}, {vehicle.lng.toFixed(4)}
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Navigation 
                              className="h-3 w-3 text-muted-foreground" 
                              style={{ transform: `rotate(${vehicle.bearing || 0}deg)` }}
                            />
                            <span className="text-sm">
                              {Math.round(vehicle.bearing || 0)}° {formatBearing(vehicle.bearing || 0)}
                            </span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <span className="text-sm">
                            {vehicle.distance ? `${vehicle.distance.toFixed(1)}m` : 'N/A'}
                          </span>
                        </TableCell>
                        <TableCell>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => setSelectedVehicle(vehicle)}
                          >
                            <Eye className="h-3 w-3 mr-1" />
                            View
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            ) : (
              <div className="text-center py-8">
                <Car className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <p className="text-muted-foreground">No vehicles found</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Selected Vehicle Details */}
        {selectedVehicle && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Car className="h-5 w-5" />
                Selected Vehicle Details
              </CardTitle>
              <CardDescription>
                Detailed information for vehicle {selectedVehicle.id}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Vehicle ID:</span>
                    <span className="font-mono text-sm">{selectedVehicle.id}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Category:</span>
                    <Badge 
                      variant="outline" 
                      className={`${getCategoryColor(selectedVehicle.category_name)} text-white`}
                    >
                      {selectedVehicle.category_name}
                    </Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Source Location:</span>
                    <span className="text-sm">{selectedVehicle.source_location || 'Unknown'}</span>
                  </div>
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Latitude:</span>
                    <span className="font-mono text-sm">{selectedVehicle.lat.toFixed(6)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Longitude:</span>
                    <span className="font-mono text-sm">{selectedVehicle.lng.toFixed(6)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Bearing:</span>
                    <span className="text-sm">
                      {Math.round(selectedVehicle.bearing || 0)}° {formatBearing(selectedVehicle.bearing || 0)}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Distance:</span>
                    <span className="text-sm">
                      {selectedVehicle.distance ? `${selectedVehicle.distance.toFixed(1)}m` : 'N/A'}
                    </span>
                  </div>
                </div>
              </div>
              
              {selectedVehicle.timestamp && (
                <div className="mt-4 p-3 bg-secondary/20 rounded-lg">
                  <div className="text-sm text-muted-foreground">Last Updated:</div>
                  <div className="text-sm font-medium">
                    {new Date(selectedVehicle.timestamp).toLocaleString()}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        )}
      </div>
    </DashboardLayout>
  )
}
