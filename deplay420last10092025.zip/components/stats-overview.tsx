"use client"

import { useEffect, useState } from "react"
import { Card } from "@/components/ui/card"
import { Skeleton } from "@/components/ui/skeleton"
import { Car, Layers, Activity, Clock } from "lucide-react"

interface Vehicle {
  id: string
  category_name: string
}

interface VehicleData {
  vehicles: Vehicle[]
  count: number
}

export function StatsOverview() {
  const [data, setData] = useState<VehicleData | null>(null)
  const [lastUpdated, setLastUpdated] = useState<Date>(new Date())
  const [secondsAgo, setSecondsAgo] = useState(0)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch("/api/vehicles/latest")
        const result = await response.json()
        setData(result)
        setLastUpdated(new Date())
        setLoading(false)
      } catch (error) {
        console.error("[v0] Failed to fetch vehicle data:", error)
        setLoading(false)
      }
    }

    fetchData()
    const interval = setInterval(fetchData, 5000)
    return () => clearInterval(interval)
  }, [])

  useEffect(() => {
    const interval = setInterval(() => {
      const seconds = Math.floor((Date.now() - lastUpdated.getTime()) / 1000)
      setSecondsAgo(seconds)
    }, 1000)
    return () => clearInterval(interval)
  }, [lastUpdated])

  const categoriesCount = data?.vehicles ? new Set(data.vehicles.map((v) => v.category_name)).size : 0

  const statCards = [
    {
      title: "Total Vehicles",
      title_th: "รถทั้งหมด",
      value: data?.count || 0,
      icon: Car,
      color: "text-blue-500",
    },
    {
      title: "Categories",
      title_th: "ประเภท",
      value: categoriesCount,
      icon: Layers,
      color: "text-purple-500",
    },
    {
      title: "System Status",
      title_th: "สถานะระบบ",
      value: data ? "Online" : "Offline",
      icon: Activity,
      color: data ? "text-green-500" : "text-red-500",
    },
    {
      title: "Last Updated",
      title_th: "อัปเดตล่าสุด",
      value: `${secondsAgo}s ago`,
      icon: Clock,
      color: "text-orange-500",
    },
  ]

  if (loading) {
    return (
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {[1, 2, 3, 4].map((i) => (
          <Card key={i} className="p-6">
            <div className="flex items-center justify-between mb-3">
              <Skeleton className="h-4 w-24" />
              <Skeleton className="h-5 w-5 rounded" />
            </div>
            <Skeleton className="h-9 w-16" />
          </Card>
        ))}
      </div>
    )
  }

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      {statCards.map((stat) => (
        <Card key={stat.title} className="p-6">
          <div className="flex items-center justify-between">
            <div className="flex flex-col gap-1">
              <p className="text-sm font-medium text-muted-foreground">{stat.title}</p>
              <p className="text-xs text-muted-foreground opacity-70">{stat.title_th}</p>
            </div>
            <stat.icon className={`h-5 w-5 ${stat.color}`} />
          </div>
          <div className="mt-3">
            <p className="text-3xl font-bold tracking-tight">{stat.value}</p>
          </div>
        </Card>
      ))}
    </div>
  )
}
