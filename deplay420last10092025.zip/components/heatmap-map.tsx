"use client"

import { useEffect, useRef, useState } from "react"
import { MapContainer, TileLayer, useMap } from "react-leaflet"
import { useTheme } from "next-themes"
import L from "leaflet"
import "leaflet/dist/leaflet.css"

interface HeatmapData {
  grid_lat: number
  grid_lng: number
  vehicles: number
}

interface HeatmapMapProps {
  hotspots: HeatmapData[]
  onHotspotSelect: (hotspot: HeatmapData | null) => void
}

// Custom hook to handle tile layer switching
function TileLayerUpdater({ isDark }: { isDark: boolean }) {
  const map = useMap()
  const [currentLayer, setCurrentLayer] = useState<string | null>(null)

  useEffect(() => {
    // Remove existing tile layer
    if (currentLayer) {
      map.eachLayer((layer) => {
        if (layer instanceof L.TileLayer) {
          map.removeLayer(layer)
        }
      })
    }

    // Add new tile layer based on theme with fallback
    const tileLayer = L.tileLayer(
      isDark 
        ? 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png'
        : 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
      {
        attribution: isDark 
          ? '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>'
          : '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
        subdomains: isDark ? 'abcd' : 'abc',
        maxZoom: 20,
        errorTileUrl: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==',
        crossOrigin: true,
        timeout: 10000,
        retry: 3
      }
    )

    // Add fallback tile layer
    const fallbackLayer = L.tileLayer(
      'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
      {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
        maxZoom: 20,
        opacity: 0.5
      }
    )

    // Add error handling for tile loading
    tileLayer.on('tileerror', (error) => {
      console.warn('Tile loading error:', error)
      // Add fallback layer if main layer fails
      if (!map.hasLayer(fallbackLayer)) {
        fallbackLayer.addTo(map)
      }
    })

    tileLayer.on('tileload', () => {
      console.log('Tile loaded successfully')
    })

    // Add both layers
    tileLayer.addTo(map)
    fallbackLayer.addTo(map)
    setCurrentLayer(isDark ? 'dark' : 'light')
  }, [isDark, map])

  return null
}

// Map updater component for heatmap visualization
function HeatmapUpdater({ hotspots, onHotspotSelect }: HeatmapMapProps) {
  const map = useMap()
  const markersRef = useRef<Map<string, L.Marker>>(new Map())
  const [selectedHotspot, setSelectedHotspot] = useState<HeatmapData | null>(null)

  const getIntensityColor = (vehicles: number, maxVehicles: number) => {
    const intensity = vehicles / maxVehicles
    if (intensity > 0.8) return '#dc2626' // bright red
    if (intensity > 0.6) return '#ea580c' // bright orange
    if (intensity > 0.4) return '#d97706' // bright amber
    if (intensity > 0.2) return '#16a34a' // bright green
    return '#2563eb' // bright blue
  }

  const getIconSize = (vehicles: number, maxVehicles: number) => {
    const baseSize = 24
    const maxSize = 48
    const intensity = vehicles / maxVehicles
    return baseSize + (maxSize - baseSize) * intensity
  }

  // Create custom icon for heatmap markers
  const createHeatmapIcon = (vehicles: number, maxVehicles: number) => {
    const size = getIconSize(vehicles, maxVehicles)
    const color = getIntensityColor(vehicles, maxVehicles)
    const intensity = vehicles / maxVehicles
    
    // Choose icon based on intensity
    let iconChar = '📍' // default pin
    if (intensity > 0.8) iconChar = '🔥' // fire for high intensity
    else if (intensity > 0.6) iconChar = '⚡' // lightning for medium-high
    else if (intensity > 0.4) iconChar = '⭐' // star for medium
    else if (intensity > 0.2) iconChar = '🚗' // car for low-medium
    else iconChar = '📍' // pin for low

    return L.divIcon({
      html: `
        <div style="
          width: ${size}px;
          height: ${size}px;
          background: linear-gradient(135deg, ${color}, ${color}dd);
          border: 4px solid #ffffff;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: ${size * 0.6}px;
          box-shadow: 0 4px 12px rgba(0,0,0,0.4), 0 0 0 2px ${color}40;
          position: relative;
          animation: pulse 2s infinite;
        ">
          <span style="
            filter: drop-shadow(0 2px 4px rgba(0,0,0,0.7));
            text-shadow: 0 1px 2px rgba(255,255,255,0.8);
          ">${iconChar}</span>
          <div style="
            position: absolute;
            bottom: -12px;
            left: 50%;
            transform: translateX(-50%);
            background: ${color};
            color: white;
            padding: 3px 8px;
            border-radius: 12px;
            font-size: 11px;
            font-weight: bold;
            white-space: nowrap;
            box-shadow: 0 2px 6px rgba(0,0,0,0.4);
            border: 2px solid white;
          ">${vehicles}</div>
        </div>
        <style>
          @keyframes pulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.05); }
          }
        </style>
      `,
      className: 'custom-heatmap-icon',
      iconSize: [size, size],
      iconAnchor: [size / 2, size / 2],
      popupAnchor: [0, -size / 2]
    })
  }

  useEffect(() => {
    console.log('HeatmapUpdater - hotspots:', hotspots)
    console.log('HeatmapUpdater - hotspots length:', hotspots?.length)
    
    if (!hotspots || hotspots.length === 0) {
      console.log('HeatmapUpdater - No hotspots data, returning')
      return
    }

    let isMounted = true

    // Clear existing markers safely
    const clearMarkers = () => {
      try {
        markersRef.current.forEach(marker => {
          if (marker && map.hasLayer(marker)) {
            map.removeLayer(marker)
          }
        })
        markersRef.current.clear()
      } catch (error) {
        console.warn('Error clearing markers:', error)
      }
    }

    clearMarkers()

    const maxVehicles = Math.max(...hotspots.map(h => h.vehicles || 0), 1)
    console.log('HeatmapUpdater - maxVehicles:', maxVehicles)

    // Add new heatmap markers with smooth animation
    hotspots.forEach((hotspot, index) => {
      if (!isMounted) return

      // Validate hotspot data
      if (!hotspot || typeof hotspot.grid_lat !== 'number' || typeof hotspot.grid_lng !== 'number') {
        console.warn('Invalid hotspot data:', hotspot)
        return
      }

      try {
        console.log(`Creating marker ${index + 1}/${hotspots.length}:`, {
          lat: hotspot.grid_lat,
          lng: hotspot.grid_lng,
          vehicles: hotspot.vehicles
        })

        const icon = createHeatmapIcon(hotspot.vehicles || 0, maxVehicles)
        
        const marker = L.marker([hotspot.grid_lat, hotspot.grid_lng], {
          icon: icon
        })

        // Add popup with hotspot information
        const popupColor = getIntensityColor(hotspot.vehicles || 0, maxVehicles)
        marker.bindPopup(`
          <div style="
            background: linear-gradient(135deg, #ffffff, #f8fafc);
            border: 2px solid #e2e8f0;
            border-radius: 12px;
            padding: 16px;
            box-shadow: 0 8px 25px rgba(0,0,0,0.15);
            min-width: 200px;
          ">
            <div style="
              font-weight: bold;
              font-size: 14px;
              color: #1e293b;
              margin-bottom: 8px;
              text-align: center;
            ">🔥 Hotspot Details</div>
            <div style="
              font-size: 12px;
              color: #334155;
              line-height: 1.6;
            ">
              <div style="
                background: #f1f5f9;
                padding: 6px 8px;
                border-radius: 6px;
                margin: 4px 0;
                border-left: 3px solid ${popupColor};
              ">
                <strong style="color: #1e293b;">Vehicles:</strong> 
                <span style="color: ${popupColor}; font-weight: bold;">${hotspot.vehicles || 0}</span>
              </div>
              <div style="margin: 4px 0; color: #475569;">
                <strong>Lat:</strong> ${hotspot.grid_lat.toFixed(4)}
              </div>
              <div style="margin: 4px 0; color: #475569;">
                <strong>Lng:</strong> ${hotspot.grid_lng.toFixed(4)}
              </div>
              <div style="
                background: ${popupColor}20;
                padding: 4px 8px;
                border-radius: 4px;
                margin: 4px 0;
                text-align: center;
                font-weight: bold;
                color: ${popupColor};
              ">
                Intensity: ${Math.round(((hotspot.vehicles || 0) / maxVehicles) * 100)}%
              </div>
            </div>
          </div>
        `)

        // Add click handler
        marker.on('click', () => {
          if (isMounted) {
            setSelectedHotspot(hotspot)
            onHotspotSelect(hotspot)
          }
        })

        // Add smooth entrance animation
        setTimeout(() => {
          if (isMounted) {
            marker.addTo(map)
            markersRef.current.set(`${hotspot.grid_lat}-${hotspot.grid_lng}`, marker)
            console.log(`Marker ${index + 1} added to map`)
          }
        }, index * 50) // Staggered animation

      } catch (error) {
        console.error(`Error creating marker ${index + 1}:`, error)
        console.error('Hotspot data:', hotspot)
      }
    })

    // Fit map to show all hotspots with delay to ensure markers are added
    if (hotspots.length > 0) {
      const timeoutId = setTimeout(() => {
        if (!isMounted) return
        
        try {
          console.log('Fitting bounds - markers count:', markersRef.current.size)
          if (markersRef.current.size > 0) {
            const group = new L.FeatureGroup(markersRef.current.values())
            const bounds = group.getBounds()
            console.log('Bounds:', bounds)
            if (bounds && bounds.isValid()) {
              map.fitBounds(bounds.pad(0.1))
              console.log('Map bounds fitted successfully')
            } else {
              console.warn('Invalid bounds, using default center')
              map.setView([18.7883, 98.9853], 12)
            }
          } else {
            console.warn('No markers to fit bounds')
            map.setView([18.7883, 98.9853], 12)
          }
        } catch (error) {
          console.error('Error fitting bounds:', error)
          map.setView([18.7883, 98.9853], 12)
        }
      }, hotspots.length * 50 + 500) // Wait for all markers to be added

      return () => {
        isMounted = false
        clearTimeout(timeoutId)
        clearMarkers()
      }
    }

    return () => {
      isMounted = false
      clearMarkers()
    }
  }, [hotspots, map, onHotspotSelect])

  return null
}

export default function HeatmapMap({ hotspots, onHotspotSelect }: HeatmapMapProps) {
  const [mounted, setMounted] = useState(false)
  const [mapError, setMapError] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [loadingProgress, setLoadingProgress] = useState(0)
  const { theme, resolvedTheme } = useTheme()
  
  const isDark = resolvedTheme === 'dark'
  
  console.log('HeatmapMap - props:', { hotspots, onHotspotSelect })
  console.log('HeatmapMap - hotspots length:', hotspots?.length)
  console.log('HeatmapMap - mounted:', mounted)
  console.log('HeatmapMap - isLoading:', isLoading)

  useEffect(() => {
    setMounted(true)
    
    // Simulate smooth loading progress
    const progressInterval = setInterval(() => {
      setLoadingProgress(prev => {
        if (prev >= 100) {
          clearInterval(progressInterval)
          setTimeout(() => setIsLoading(false), 300)
          return 100
        }
        return prev + Math.random() * 15
      })
    }, 100)
    
    // Cleanup on unmount
    return () => {
      setMounted(false)
      clearInterval(progressInterval)
    }
  }, [])

  // Force loading to false if we have hotspots data
  useEffect(() => {
    if (hotspots && hotspots.length > 0) {
      setIsLoading(false)
    }
  }, [hotspots])

  // Disable WebSocket for heatmap - use HTTP only
  useEffect(() => {
    // Override any WebSocket connections that might interfere
    if (typeof window !== 'undefined') {
      // Disable WebSocket auto-connection
      const originalWebSocket = window.WebSocket
      window.WebSocket = class extends originalWebSocket {
        constructor(url: string | URL, protocols?: string | string[]) {
          console.log('WebSocket connection blocked for heatmap:', url)
          throw new Error('WebSocket disabled for heatmap component')
        }
      }
      
      return () => {
        window.WebSocket = originalWebSocket
      }
    }
  }, [])

  // Force map to render immediately when data is available
  useEffect(() => {
    if (hotspots && hotspots.length > 0) {
      console.log('Hotspots available, forcing map render')
      setIsLoading(false)
    }
  }, [hotspots])

  if (!mounted) {
    return (
      <div className="h-[500px] bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800 flex items-center justify-center relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-400/20 to-purple-400/20 animate-pulse"></div>
        <div className="text-center relative z-10">
          <div className="relative mb-6">
            <div className="w-16 h-16 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin mx-auto"></div>
            <div className="absolute inset-0 w-16 h-16 border-4 border-transparent border-t-purple-400 rounded-full animate-spin mx-auto" style={{animationDelay: '0.5s'}}></div>
          </div>
          <h3 className="text-lg font-semibold text-gray-800 dark:text-white mb-2">Loading Heatmap</h3>
          <p className="text-sm text-gray-600 dark:text-gray-300 mb-4">Preparing interactive map...</p>
          <div className="w-48 bg-gray-200 dark:bg-gray-700 rounded-full h-2 mx-auto">
            <div 
              className="bg-gradient-to-r from-blue-500 to-purple-500 h-2 rounded-full transition-all duration-300 ease-out"
              style={{ width: `${loadingProgress}%` }}
            ></div>
          </div>
          <p className="text-xs text-gray-500 dark:text-gray-400 mt-2">{Math.round(loadingProgress)}%</p>
        </div>
      </div>
    )
  }

  if (isLoading) {
    return (
      <div className="h-[500px] bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800 flex items-center justify-center relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-400/20 to-purple-400/20 animate-pulse"></div>
        <div className="text-center relative z-10">
          <div className="relative mb-6">
            <div className="w-16 h-16 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin mx-auto"></div>
            <div className="absolute inset-0 w-16 h-16 border-4 border-transparent border-t-purple-400 rounded-full animate-spin mx-auto" style={{animationDelay: '0.5s'}}></div>
          </div>
          <h3 className="text-lg font-semibold text-gray-800 dark:text-white mb-2">Rendering Map</h3>
          <p className="text-sm text-gray-600 dark:text-gray-300 mb-4">Adding heatmap markers...</p>
          <div className="w-48 bg-gray-200 dark:bg-gray-700 rounded-full h-2 mx-auto">
            <div 
              className="bg-gradient-to-r from-blue-500 to-purple-500 h-2 rounded-full transition-all duration-300 ease-out"
              style={{ width: `${loadingProgress}%` }}
            ></div>
          </div>
          <p className="text-xs text-gray-500 dark:text-gray-400 mt-2">{Math.round(loadingProgress)}%</p>
        </div>
      </div>
    )
  }

  // Show message if no hotspots data
  if (!hotspots || hotspots.length === 0) {
    return (
      <div className="h-[500px] bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800 flex items-center justify-center relative overflow-hidden">
        <div className="text-center">
          <div className="text-6xl mb-4">🗺️</div>
          <h3 className="text-lg font-semibold text-gray-800 dark:text-white mb-2">No Heatmap Data</h3>
          <p className="text-sm text-gray-600 dark:text-gray-300 mb-4">
            No vehicle hotspots found. Try adjusting the limit or check your data source.
          </p>
          <div className="text-xs text-gray-500 dark:text-gray-400">
            Hotspots: {hotspots?.length || 0}
          </div>
        </div>
      </div>
    )
  }

  if (mapError) {
    return (
      <div className="relative h-[500px]">
        <div className="h-full bg-secondary/20 flex items-center justify-center">
          <div className="text-center">
            <div className="text-4xl mb-4">🗺️</div>
            <h3 className="text-lg font-semibold mb-2">Map Unavailable</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Unable to load map tiles. Please check your connection.
            </p>
            <button 
              onClick={() => setMapError(false)}
              className="px-4 py-2 bg-primary text-primary-foreground rounded-md text-sm hover:bg-primary/90"
            >
              Retry
            </button>
          </div>
        </div>
      </div>
    )
  }

  // Center of Chiang Mai, Thailand
  const center: [number, number] = [18.7883, 98.9853]
  const zoom = 12

  return (
    <div className="relative h-[500px] animate-in fade-in duration-700">
      {/* Legend */}
      <div className="absolute top-4 right-4 z-[1000] bg-white dark:bg-gray-900 p-4 rounded-xl shadow-2xl border-2 border-gray-300 dark:border-gray-500 backdrop-blur-sm animate-in slide-in-from-right duration-500 delay-300">
        <div className="text-sm font-bold mb-3 text-center bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
          🗺️ Heatmap Icons
        </div>
        <div className="space-y-3 text-xs">
          <div className="flex items-center gap-3 p-2 rounded-lg bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 animate-in fade-in duration-500 delay-500">
            <div className="w-7 h-7 rounded-full bg-red-600 flex items-center justify-center text-white text-sm font-bold shadow-lg">🔥</div>
            <span className="font-bold text-red-800 dark:text-red-200">High Intensity (80%+)</span>
          </div>
          <div className="flex items-center gap-3 p-2 rounded-lg bg-orange-50 dark:bg-orange-900/20 border border-orange-200 dark:border-orange-800 animate-in fade-in duration-500 delay-600">
            <div className="w-7 h-7 rounded-full bg-orange-600 flex items-center justify-center text-white text-sm font-bold shadow-lg">⚡</div>
            <span className="font-bold text-orange-800 dark:text-orange-200">Medium-High (60-80%)</span>
          </div>
          <div className="flex items-center gap-3 p-2 rounded-lg bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 animate-in fade-in duration-500 delay-700">
            <div className="w-7 h-7 rounded-full bg-amber-600 flex items-center justify-center text-white text-sm font-bold shadow-lg">⭐</div>
            <span className="font-bold text-amber-800 dark:text-amber-200">Medium (40-60%)</span>
          </div>
          <div className="flex items-center gap-3 p-2 rounded-lg bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 animate-in fade-in duration-500 delay-800">
            <div className="w-7 h-7 rounded-full bg-green-600 flex items-center justify-center text-white text-sm font-bold shadow-lg">🚗</div>
            <span className="font-bold text-green-800 dark:text-green-200">Low-Medium (20-40%)</span>
          </div>
          <div className="flex items-center gap-3 p-2 rounded-lg bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 animate-in fade-in duration-500 delay-900">
            <div className="w-7 h-7 rounded-full bg-blue-600 flex items-center justify-center text-white text-sm font-bold shadow-lg">📍</div>
            <span className="font-bold text-blue-800 dark:text-blue-200">Low (0-20%)</span>
          </div>
        </div>
      </div>

      <div className="animate-in fade-in duration-1000 delay-200">
        <MapContainer
          center={center}
          zoom={zoom}
          style={{ height: '100%', width: '100%' }}
          className="z-0 rounded-lg overflow-hidden shadow-lg"
          whenCreated={(map) => {
            console.log('Map created successfully')
            map.on('tileerror', (error) => {
              console.error('Tile error:', error)
              setMapError(true)
            })
            map.on('load', () => {
              console.log('Map loaded successfully')
            })
          }}
        >
          <TileLayerUpdater isDark={isDark} />
          <HeatmapUpdater hotspots={hotspots} onHotspotSelect={onHotspotSelect} />
        </MapContainer>
      </div>
    </div>
  )
}
