"use client"

import { useEffect, useState } from "react"
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Skeleton } from "@/components/ui/skeleton"
import {
  LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, 
  BarChart, Bar, PieChart, Pie, Cell, AreaChart, Area
} from "recharts"
import { fetchLatestVehicles, fetchTrend } from "@/lib/api"
import { TrendingUp, Car, Activity, Wifi, WifiOff } from "lucide-react"

interface VehicleData {
  id: string
  category_name: string
  lat: number
  lng: number
  bearing: number
  timestamp: string
}

interface TrendData {
  time: string
  vehicles: number
  smoothed?: number
}

interface CategoryData {
  category: string
  count: number
  color: string
}

const COLORS = ['#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6', '#06B6D4']

export default function RealtimeCharts() {
  const [vehicles, setVehicles] = useState<VehicleData[]>([])
  const [trend, setTrend] = useState<TrendData[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [lastUpdate, setLastUpdate] = useState<Date>(new Date())

  // Fetch data function
  const fetchData = async () => {
    try {
      const [vehiclesResponse, trendResponse] = await Promise.all([
        fetchLatestVehicles(),
        fetch('/api/analytics/trend/fast?interval=hour&limit=10', {
          cache: 'no-store',
          headers: {
            'Content-Type': 'application/json',
          }
        }).then(res => res.json())
      ])
      
      setVehicles(vehiclesResponse.vehicles || [])
      setTrend(trendResponse.trends || [])
      setLastUpdate(new Date())
      setError(null)
    } catch (err) {
      console.error("Error fetching realtime charts:", err)
      setError(err instanceof Error ? err.message : "Failed to fetch data")
    } finally {
      setLoading(false)
    }
  }

  // Auto-refresh every 3 seconds
  useEffect(() => {
    fetchData()
    const interval = setInterval(fetchData, 3000)
    return () => clearInterval(interval)
  }, [])

  // Process category data
  const categoryData: CategoryData[] = Object.entries(
    vehicles.reduce((acc: Record<string, number>, vehicle) => {
      const category = vehicle.category_name || 'Unknown'
      acc[category] = (acc[category] || 0) + 1
      return acc
    }, {})
  ).map(([category, count], index) => ({
    category,
    count,
    color: COLORS[index % COLORS.length]
  }))

  // Process trend data for last 10 points
  const recentTrend = trend.slice(-10).map((item, index) => ({
    ...item,
    index: index + 1,
    time: new Date(item.time).toLocaleTimeString('th-TH', { 
      hour: '2-digit', 
      minute: '2-digit' 
    })
  }))

  // Calculate active vs offline (simulated)
  const totalVehicles = 1000 // Simulated total
  const activeVehicles = vehicles.length
  const offlineVehicles = Math.max(0, totalVehicles - activeVehicles)

  const activeOfflineData = [
    { name: "Active", value: activeVehicles, color: "#10B981" },
    { name: "Offline", value: offlineVehicles, color: "#EF4444" }
  ]

  // Process distance coverage data (use distance field if available, otherwise use vehicles * 0.8)
  const distanceTrend = trend.slice(-10).map((item, index) => ({
    ...item,
    index: index + 1,
    vehicles: (item as any).distance || Math.round(item.vehicles * 0.8), // Use distance field or calculate from vehicles
    time: new Date(item.time).toLocaleTimeString('th-TH', { 
      hour: '2-digit', 
      minute: '2-digit' 
    })
  }))

  if (loading) {
    return (
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {[...Array(6)].map((_, i) => (
          <Card key={i}>
            <CardHeader>
              <Skeleton className="h-6 w-32" />
            </CardHeader>
            <CardContent>
              <Skeleton className="h-48 w-full" />
            </CardContent>
          </Card>
        ))}
      </div>
    )
  }

  if (error) {
    return (
      <Card className="p-6 border-red-200 bg-red-50">
        <div className="text-red-600 text-center">
          <strong>Error loading charts:</strong> {error}
        </div>
      </Card>
    )
  }

  return (
    <div className="space-y-6">
      {/* Stats Overview */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">รถทั้งหมด</p>
                <p className="text-2xl font-bold text-blue-600">{vehicles.length}</p>
              </div>
              <Car className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">ใช้งานอยู่</p>
                <p className="text-2xl font-bold text-green-600">{activeVehicles}</p>
              </div>
              <Activity className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">หมวดหมู่</p>
                <p className="text-2xl font-bold text-purple-600">{categoryData.length}</p>
              </div>
              <TrendingUp className="h-8 w-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">อัปเดตล่าสุด</p>
                <p className="text-sm font-bold text-gray-600">
                  {lastUpdate.toLocaleTimeString('th-TH')}
                </p>
              </div>
              <Badge variant="outline" className="gap-1">
                <Wifi className="h-3 w-3" />
                สด
              </Badge>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts Grid */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {/* Vehicles Trend Chart */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5" />
              แนวโน้มรถ (10 ล่าสุด)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={200}>
              <LineChart data={recentTrend}>
                <XAxis 
                  dataKey="index" 
                  tick={{ fontSize: 12 }}
                  axisLine={false}
                  tickLine={false}
                />
                <YAxis 
                  tick={{ fontSize: 12 }}
                  axisLine={false}
                  tickLine={false}
                />
                <Tooltip 
                  labelFormatter={(value) => `Point ${value}`}
                  formatter={(value: number) => [value, 'Vehicles']}
                />
                <Line 
                  type="monotone" 
                  dataKey="vehicles" 
                  stroke="#3B82F6" 
                  strokeWidth={3}
                  dot={{ fill: '#3B82F6', strokeWidth: 2, r: 4 }}
                  isAnimationActive={true}
                  animationDuration={1000}
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Vehicles by Category */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Car className="h-5 w-5" />
              รถตามหมวดหมู่
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={categoryData}>
                <XAxis 
                  dataKey="category" 
                  tick={{ fontSize: 10 }}
                  axisLine={false}
                  tickLine={false}
                />
                <YAxis 
                  tick={{ fontSize: 12 }}
                  axisLine={false}
                  tickLine={false}
                />
                <Tooltip 
                  formatter={(value: number) => [value, 'Vehicles']}
                />
                <Bar 
                  dataKey="count" 
                  fill="#10B981"
                  radius={[4, 4, 0, 0]}
                  animationDuration={800}
                />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Active vs Offline */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Activity className="h-5 w-5" />
              ออนไลน์ vs ออฟไลน์
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie
                  data={activeOfflineData}
                  cx="50%"
                  cy="50%"
                  outerRadius={70}
                  dataKey="value"
                  label={({ name, value, percent }) => 
                    `${name}: ${value} (${(percent * 100).toFixed(0)}%)`
                  }
                  labelLine={false}
                >
                  {activeOfflineData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip formatter={(value: number) => [value, 'Vehicles']} />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Distance Coverage */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5" />
              การครอบคลุมระยะทาง
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={200}>
              <AreaChart data={distanceTrend}>
                <XAxis 
                  dataKey="index" 
                  tick={{ fontSize: 12 }}
                  axisLine={false}
                  tickLine={false}
                />
                <YAxis 
                  tick={{ fontSize: 12 }}
                  axisLine={false}
                  tickLine={false}
                />
                <Tooltip 
                  labelFormatter={(value) => `Point ${value}`}
                  formatter={(value: number) => [value, 'Distance (km)']}
                />
                <Area 
                  type="monotone" 
                  dataKey="vehicles" 
                  stroke="#8B5CF6" 
                  fill="#8B5CF6"
                  fillOpacity={0.3}
                  strokeWidth={2}
                  isAnimationActive={true}
                  animationDuration={1200}
                />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Speed Distribution */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Activity className="h-5 w-5" />
              การกระจายความเร็ว
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={categoryData}>
                <XAxis 
                  dataKey="category" 
                  tick={{ fontSize: 10 }}
                  axisLine={false}
                  tickLine={false}
                />
                <YAxis 
                  tick={{ fontSize: 12 }}
                  axisLine={false}
                  tickLine={false}
                />
                <Tooltip 
                  formatter={(value: number) => [value, 'Avg Speed (km/h)']}
                />
                <Bar 
                  dataKey="count" 
                  fill="#F59E0B"
                  radius={[4, 4, 0, 0]}
                  animationDuration={1000}
                />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* System Status */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Wifi className="h-5 w-5" />
              สถานะระบบ
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm">สถานะ API</span>
              <Badge variant="outline" className="gap-1 text-green-600">
                <Wifi className="h-3 w-3" />
                ออนไลน์
              </Badge>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm">ความสดของข้อมูล</span>
              <Badge variant="outline" className="text-blue-600">
                {Math.floor((Date.now() - lastUpdate.getTime()) / 1000)} วินาทีที่แล้ว
              </Badge>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm">ความถี่การอัปเดต</span>
              <Badge variant="outline" className="text-purple-600">
                ทุก 3 วินาที
              </Badge>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm">จำนวนรายการทั้งหมด</span>
              <Badge variant="outline" className="text-orange-600">
                {vehicles.length} คัน
              </Badge>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
