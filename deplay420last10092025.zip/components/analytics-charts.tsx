"use client"

import { useEffect, useState } from "react"
import { Card } from "@/components/ui/card"
import { BarChart3, TrendingUp, MapPin } from "lucide-react"

interface Hotspot {
  grid_lat: number
  grid_lng: number
  vehicles: number
}

interface TrendPoint {
  time: string
  vehicles: number
}

export function AnalyticsCharts() {
  const [hotspots, setHotspots] = useState<Hotspot[]>([])
  const [trends, setTrends] = useState<TrendPoint[]>([])

  useEffect(() => {
    const fetchAnalytics = async () => {
      try {
        const [heatmapRes, trendRes] = await Promise.all([
          fetch("/api/analytics/heatmap?limit=10", {
            cache: "no-store",
            signal: AbortSignal.timeout(10000) // 10 second timeout
          }),
          fetch("/api/analytics/trend?interval=hour", {
            cache: "no-store", 
            signal: AbortSignal.timeout(10000) // 10 second timeout
          }),
        ])

        if (!heatmapRes.ok || !trendRes.ok) {
          throw new Error(`HTTP ${heatmapRes.status} / ${trendRes.status}`)
        }

        const heatmapData = await heatmapRes.json()
        const trendData = await trendRes.json()

        setHotspots(heatmapData.hotspots || [])
        setTrends(trendData.trends || [])
      } catch (error) {
        console.error("[AnalyticsCharts] Failed to fetch analytics:", error)
        // Don't clear existing data on error, just log it
      }
    }

    fetchAnalytics()
    // Increase interval to reduce API calls
    const interval = setInterval(fetchAnalytics, 60000) // 1 minute instead of 30 seconds
    return () => clearInterval(interval)
  }, [])

  return (
    <div className="grid gap-6 lg:grid-cols-2">
      {/* Heatmap Hotspots */}
      <Card className="p-6">
        <div className="flex items-center gap-2 mb-6">
          <MapPin className="h-5 w-5 text-chart-2" />
          <h2 className="text-lg font-semibold">จุดร้อนยอดนิยม</h2>
        </div>

        <div className="space-y-4">
          {hotspots.slice(0, 8).map((hotspot, index) => {
            const maxVehicles = Math.max(...hotspots.map((h) => h.vehicles))
            const percentage = (hotspot.vehicles / maxVehicles) * 100

            return (
              <div key={index} className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">
                    {hotspot.grid_lat.toFixed(4)}, {hotspot.grid_lng.toFixed(4)}
                  </span>
                  <span className="font-semibold">{hotspot.vehicles} คัน</span>
                </div>
                <div className="h-2 rounded-full bg-secondary overflow-hidden">
                  <div className="h-full bg-chart-2 transition-all duration-500" style={{ width: `${percentage}%` }} />
                </div>
              </div>
            )
          })}
        </div>
      </Card>

      {/* Trend Chart */}
      <Card className="p-6">
        <div className="flex items-center gap-2 mb-6">
          <TrendingUp className="h-5 w-5 text-chart-1" />
          <h2 className="text-lg font-semibold">แนวโน้มรถ</h2>
        </div>

        <div className="space-y-4">
          {trends.slice(0, 8).map((point, index) => {
            const maxVehicles = Math.max(...trends.map((t) => t.vehicles))
            const percentage = (point.vehicles / maxVehicles) * 100

            return (
              <div key={index} className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">
                    {new Date(point.time).toLocaleTimeString("th-TH", {
                      hour: "2-digit",
                      minute: "2-digit",
                    })}
                  </span>
                  <span className="font-semibold">{point.vehicles} คัน</span>
                </div>
                <div className="h-2 rounded-full bg-secondary overflow-hidden">
                  <div className="h-full bg-chart-1 transition-all duration-500" style={{ width: `${percentage}%` }} />
                </div>
              </div>
            )
          })}
        </div>
      </Card>

      {/* Summary Stats */}
      <Card className="p-6 lg:col-span-2">
        <div className="flex items-center gap-2 mb-6">
          <BarChart3 className="h-5 w-5 text-chart-3" />
          <h2 className="text-lg font-semibold">สถิติสรุป</h2>
        </div>

        <div className="grid gap-6 md:grid-cols-3">
          <div className="space-y-2">
            <p className="text-sm text-muted-foreground">จุดร้อนทั้งหมด</p>
            <p className="text-3xl font-bold">{hotspots.length}</p>
          </div>
          <div className="space-y-2">
            <p className="text-sm text-muted-foreground">รถสูงสุด</p>
            <p className="text-3xl font-bold">{Math.max(...trends.map((t) => t.vehicles), 0)}</p>
          </div>
          <div className="space-y-2">
            <p className="text-sm text-muted-foreground">รถเฉลี่ย</p>
            <p className="text-3xl font-bold">
              {trends.length > 0 ? Math.round(trends.reduce((sum, t) => sum + t.vehicles, 0) / trends.length) : 0}
            </p>
          </div>
        </div>
      </Card>
    </div>
  )
}
