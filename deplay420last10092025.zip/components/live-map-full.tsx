"use client"

import { useEffect, useRef, useState } from "react"
import { MapContainer, TileLayer, Marker, Popup, useMap } from "react-leaflet"
import { useTheme } from "next-themes"
import L from "leaflet"
import "leaflet/dist/leaflet.css"
import AnimatedVehicleMarker from "./animated-vehicle-marker"
import { Vehicle } from "@/types/vehicles"

// Fix for default markers in React-Leaflet
delete (L.Icon.Default.prototype as any)._getIconUrl
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
})

interface LiveMapFullProps {
  vehicles: Vehicle[]
  selectedVehicle: Vehicle | null
  onVehicleSelect: (vehicle: Vehicle | null) => void
  autoResizeMarkers?: boolean
}

// Custom hook to handle tile layer switching
function TileLayerUpdater({ isDark }: { isDark: boolean }) {
  const map = useMap()
  const [currentLayer, setCurrentLayer] = useState<string | null>(null)

  useEffect(() => {
    // Remove existing tile layer
    if (currentLayer) {
      map.eachLayer((layer) => {
        if (layer instanceof L.TileLayer) {
          map.removeLayer(layer)
        }
      })
    }

    // Add new tile layer based on theme
    const tileLayer = L.tileLayer(
      isDark 
        ? 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png'
        : 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
      {
        attribution: isDark 
          ? '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>'
          : '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
        subdomains: isDark ? 'abcd' : 'abc',
        maxZoom: 20,
      }
    )

    tileLayer.addTo(map)
    setCurrentLayer(isDark ? 'dark' : 'light')
  }, [isDark, map])

  return null
}

// Custom hook to handle map updates and render animated markers
function MapUpdater({ vehicles, selectedVehicle, onVehicleSelect, autoResizeMarkers = false }: LiveMapFullProps & { autoResizeMarkers?: boolean }) {
  const map = useMap()
  const [currentZoom, setCurrentZoom] = useState(map.getZoom())

  // Handle zoom changes for auto-resize
  useEffect(() => {
    if (!autoResizeMarkers) return

    const handleZoomEnd = () => {
      setCurrentZoom(map.getZoom())
    }

    map.on('zoomend', handleZoomEnd)
    
    return () => {
      map.off('zoomend', handleZoomEnd)
    }
  }, [map, autoResizeMarkers])

  // Center map on selected vehicle
  useEffect(() => {
    if (selectedVehicle) {
      map.setView([selectedVehicle.lat, selectedVehicle.lng], map.getZoom(), {
        animate: true,
        duration: 1
      })
    }
  }, [selectedVehicle, map])

  // Calculate icon size based on zoom level
  const getIconSize = (zoom: number) => {
    if (!autoResizeMarkers) return 32
    
    // Interpolate icon size based on zoom level
    const minSize = 20
    const maxSize = 50
    const minZoom = 1
    const maxZoom = 20
    
    const normalizedZoom = Math.max(0, Math.min(1, (zoom - minZoom) / (maxZoom - minZoom)))
    return Math.round(minSize + (maxSize - minSize) * normalizedZoom)
  }

  return (
    <>
      {vehicles.map((vehicle, index) => (
        <AnimatedVehicleMarker
          key={`${vehicle.id}-${index}`}
          vehicle={vehicle}
          size={getIconSize(currentZoom)}
        />
      ))}
    </>
  )
}

export default function LiveMapFull({ vehicles, selectedVehicle, onVehicleSelect, autoResizeMarkers = false }: LiveMapFullProps) {
  const [mounted, setMounted] = useState(false)
  const [mapError, setMapError] = useState(false)
  const { theme, resolvedTheme } = useTheme()
  
  const isDark = resolvedTheme === 'dark'

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return (
      <div className="h-[600px] bg-secondary/20 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-sm text-muted-foreground">Loading map...</p>
        </div>
      </div>
    )
  }

  if (mapError) {
    // Dispatch error event for parent component
    useEffect(() => {
      const event = new CustomEvent('map-error', { detail: { error: 'Map tiles failed to load' } })
      window.dispatchEvent(event)
    }, [mapError])

    return (
      <div className="relative h-[600px]">
        <div className="h-full bg-secondary/20 flex items-center justify-center">
          <div className="text-center">
            <div className="text-4xl mb-4">🗺️</div>
            <h3 className="text-lg font-semibold mb-2">Map Unavailable</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Unable to load map tiles. Please check your connection.
            </p>
            <button 
              onClick={() => setMapError(false)}
              className="px-4 py-2 bg-primary text-primary-foreground rounded-md text-sm hover:bg-primary/90"
            >
              Retry
            </button>
          </div>
        </div>
      </div>
    )
  }

  // Center of Chiang Mai, Thailand
  const center: [number, number] = [18.7883, 98.9853]
  const zoom = 13

  return (
    <div className="relative h-[600px]">
      {/* Live badge */}
      <div className="absolute top-4 right-4 z-[1000]">
        <div className="bg-red-500 text-white px-3 py-1 rounded-full text-xs font-medium flex items-center gap-2 shadow-lg">
          <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
          Live
        </div>
      </div>

      <MapContainer
        center={center}
        zoom={zoom}
        style={{ height: '100%', width: '100%' }}
        className="z-0"
        whenCreated={(map) => {
          // Handle map errors
          map.on('tileerror', () => {
            setMapError(true)
          })
        }}
      >
        <TileLayerUpdater isDark={isDark} />
        
        <MapUpdater
          vehicles={vehicles}
          selectedVehicle={selectedVehicle}
          onVehicleSelect={onVehicleSelect}
          autoResizeMarkers={autoResizeMarkers}
        />
      </MapContainer>
    </div>
  )
}