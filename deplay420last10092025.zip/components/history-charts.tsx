"use client"

import { useEffect, useState } from "react"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { TrendingUp, MapPin, Compass, BarChart3 } from "lucide-react"

// Haversine distance calculation (meters)
function haversine(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371e3 // Earth's radius in meters
  const toRad = (d: number) => d * Math.PI / 180
  const dLat = toRad(lat2 - lat1)
  const dLon = toRad(lon2 - lon1)
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) ** 2
  return 2 * R * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
}

// Simple chart component for speed over time
function SpeedChart({ records }: { records: any[] }) {
  const [chartData, setChartData] = useState<{ time: string; speed: number }[]>([])

  useEffect(() => {
    if (records.length === 0) return

    const data = records
      .filter(r => r.speed !== null && r.speed !== undefined)
      .slice(0, 100) // Limit to 100 points for performance
      .map(r => ({
        time: new Date(r.timestamp).toLocaleTimeString(),
        speed: r.speed
      }))

    setChartData(data)
  }, [records])

  if (chartData.length === 0) {
    return (
      <div className="h-64 flex items-center justify-center text-muted-foreground">
        ไม่มีข้อมูลความเร็ว
      </div>
    )
  }

  const maxSpeed = Math.max(...chartData.map(d => d.speed))
  const minSpeed = Math.min(...chartData.map(d => d.speed))

  return (
    <div className="h-64">
      <div className="flex items-center justify-between mb-4">
        <h4 className="font-semibold">ความเร็วตามเวลา</h4>
        <Badge variant="outline">
          {chartData.length} points
        </Badge>
      </div>
      <div className="relative h-48 bg-secondary/20 rounded-lg p-4">
        <div className="absolute inset-4">
          <div className="h-full flex items-end gap-1">
            {chartData.map((point, index) => {
              const height = ((point.speed - minSpeed) / (maxSpeed - minSpeed)) * 100
              return (
                <div
                  key={index}
                  className="flex-1 bg-blue-500 rounded-t"
                  style={{ height: `${Math.max(height, 2)}%` }}
                  title={`${point.time}: ${point.speed.toFixed(1)} km/h`}
                />
              )
            })}
          </div>
        </div>
        <div className="absolute bottom-0 left-4 right-4 flex justify-between text-xs text-muted-foreground">
          <span>{minSpeed.toFixed(1)} km/h</span>
          <span>{maxSpeed.toFixed(1)} km/h</span>
        </div>
      </div>
    </div>
  )
}

// Cumulative distance chart
function DistanceChart({ records }: { records: any[] }) {
  const [chartData, setChartData] = useState<{ time: string; distance: number }[]>([])

  useEffect(() => {
    if (records.length === 0) return

    const data = []
    let cumulativeDistance = 0

    for (let i = 1; i < records.length; i++) {
      const prev = records[i - 1]
      const curr = records[i]
      const distance = haversine(prev.lat, prev.lng, curr.lat, curr.lng) / 1000 // Convert to km
      cumulativeDistance += distance
      
      data.push({
        time: new Date(curr.timestamp).toLocaleTimeString(),
        distance: cumulativeDistance
      })
    }

    setChartData(data.slice(0, 100)) // Limit to 100 points
  }, [records])

  if (chartData.length === 0) {
    return (
      <div className="h-64 flex items-center justify-center text-muted-foreground">
        ไม่มีข้อมูลระยะทาง
      </div>
    )
  }

  const maxDistance = Math.max(...chartData.map(d => d.distance))

  return (
    <div className="h-64">
      <div className="flex items-center justify-between mb-4">
        <h4 className="font-semibold">ระยะทางสะสม</h4>
        <Badge variant="outline">
          {maxDistance.toFixed(1)} km total
        </Badge>
      </div>
      <div className="relative h-48 bg-secondary/20 rounded-lg p-4">
        <div className="absolute inset-4">
          <div className="h-full flex items-end gap-1">
            {chartData.map((point, index) => {
              const height = (point.distance / maxDistance) * 100
              return (
                <div
                  key={index}
                  className="flex-1 bg-green-500 rounded-t"
                  style={{ height: `${Math.max(height, 2)}%` }}
                  title={`${point.time}: ${point.distance.toFixed(1)} km`}
                />
              )
            })}
          </div>
        </div>
        <div className="absolute bottom-0 left-4 right-4 flex justify-between text-xs text-muted-foreground">
          <span>0 km</span>
          <span>{maxDistance.toFixed(1)} km</span>
        </div>
      </div>
    </div>
  )
}

// Bearing rose chart
function BearingChart({ bearingHistogram }: { bearingHistogram: any }) {
  if (!bearingHistogram) {
    return (
      <div className="h-64 flex items-center justify-center text-muted-foreground">
        ไม่มีข้อมูลทิศทาง
      </div>
    )
  }

  const directions = [
    { key: 'N', label: 'North', angle: 0 },
    { key: 'NE', label: 'Northeast', angle: 45 },
    { key: 'E', label: 'East', angle: 90 },
    { key: 'SE', label: 'Southeast', angle: 135 },
    { key: 'S', label: 'South', angle: 180 },
    { key: 'SW', label: 'Southwest', angle: 225 },
    { key: 'W', label: 'West', angle: 270 },
    { key: 'NW', label: 'Northwest', angle: 315 }
  ]

  const maxValue = Math.max(...Object.values(bearingHistogram))

  return (
    <div className="h-64">
      <div className="flex items-center justify-between mb-4">
        <h4 className="font-semibold">การกระจายทิศทาง</h4>
        <Badge variant="outline">
          {Object.values(bearingHistogram).reduce((a: number, b: number) => a + b, 0)} total
        </Badge>
      </div>
      <div className="relative h-48 bg-secondary/20 rounded-lg p-4">
        <div className="absolute inset-4">
          <div className="h-full flex items-end gap-2">
            {directions.map((dir) => {
              const value = bearingHistogram[dir.key] || 0
              const height = maxValue > 0 ? (value / maxValue) * 100 : 0
              return (
                <div key={dir.key} className="flex-1 flex flex-col items-center">
                  <div
                    className="w-full bg-purple-500 rounded-t"
                    style={{ height: `${Math.max(height, 2)}%` }}
                    title={`${dir.label}: ${value}`}
                  />
                  <div className="text-xs text-muted-foreground mt-1">{dir.key}</div>
                </div>
              )
            })}
          </div>
        </div>
      </div>
    </div>
  )
}

// Hotspots chart
function HotspotsChart({ hotspots }: { hotspots: any[] }) {
  if (!hotspots || hotspots.length === 0) {
    return (
      <div className="h-64 flex items-center justify-center text-muted-foreground">
        ไม่มีข้อมูลจุดร้อน
      </div>
    )
  }

  const topHotspots = hotspots
    .sort((a, b) => b.vehicles - a.vehicles)
    .slice(0, 10)

  const maxVehicles = Math.max(...topHotspots.map(h => h.vehicles))

  return (
    <div className="h-64">
      <div className="flex items-center justify-between mb-4">
        <h4 className="font-semibold">จุดร้อนยอดนิยม</h4>
        <Badge variant="outline">
          {hotspots.length} locations
        </Badge>
      </div>
      <div className="relative h-48 bg-secondary/20 rounded-lg p-4">
        <div className="absolute inset-4">
          <div className="h-full flex items-end gap-1">
            {topHotspots.map((hotspot, index) => {
              const height = (hotspot.vehicles / maxVehicles) * 100
              return (
                <div
                  key={index}
                  className="flex-1 bg-orange-500 rounded-t"
                  style={{ height: `${Math.max(height, 2)}%` }}
                  title={`${hotspot.vehicles} vehicles at ${hotspot.grid_lat.toFixed(3)}, ${hotspot.grid_lng.toFixed(3)}`}
                />
              )
            })}
          </div>
        </div>
        <div className="absolute bottom-0 left-4 right-4 flex justify-between text-xs text-muted-foreground">
          <span>0</span>
          <span>{maxVehicles}</span>
        </div>
      </div>
    </div>
  )
}

export default function HistoryCharts({ 
  history, 
  analytics, 
  heatmap, 
  trend 
}: { 
  history: any; 
  analytics: any; 
  heatmap: any;
  trend: any;
}) {
  // Support both records and data formats from API
  const records = history?.records ?? history?.data ?? []
  const bearingHistogram = analytics?.bearing_histogram
  const hotspots = analytics?.hotspots ?? []
  
  console.log("HistoryCharts - history:", history)
  console.log("HistoryCharts - records:", records)
  console.log("HistoryCharts - analytics:", analytics)
  console.log("HistoryCharts - analytics summary:", analytics?.summary)
  console.log("HistoryCharts - analytics record_count:", analytics?.summary?.record_count)

  return (
    <div className="grid md:grid-cols-2 gap-6">
      {/* Speed Chart */}
      <Card className="p-6">
        <div className="flex items-center gap-2 mb-4">
          <TrendingUp className="h-5 w-5" />
          <h3 className="font-semibold">ความเร็วตามเวลา</h3>
        </div>
        <SpeedChart records={records} />
      </Card>

      {/* Distance Chart */}
      <Card className="p-6">
        <div className="flex items-center gap-2 mb-4">
          <MapPin className="h-5 w-5" />
          <h3 className="font-semibold">ระยะทางสะสม</h3>
        </div>
        <DistanceChart records={records} />
      </Card>

      {/* Bearing Chart */}
      <Card className="p-6">
        <div className="flex items-center gap-2 mb-4">
          <Compass className="h-5 w-5" />
          <h3 className="font-semibold">การกระจายทิศทาง</h3>
        </div>
        <BearingChart bearingHistogram={bearingHistogram} />
      </Card>

      {/* Hotspots Chart */}
      <Card className="p-6">
        <div className="flex items-center gap-2 mb-4">
          <BarChart3 className="h-5 w-5" />
          <h3 className="font-semibold">จุดร้อนของรถ</h3>
        </div>
        <HotspotsChart hotspots={hotspots} />
      </Card>
    </div>
  )
}
