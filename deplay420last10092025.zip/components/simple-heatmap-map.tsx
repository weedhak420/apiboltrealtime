"use client"

import { useEffect, useRef, useState } from "react"
import { MapContainer, TileLayer, useMap, Marker, Popup } from "react-leaflet"
import { useTheme } from "next-themes"
import L from "leaflet"
import "leaflet/dist/leaflet.css"

interface HeatmapData {
  grid_lat: number
  grid_lng: number
  vehicles: number
}

interface SimpleHeatmapMapProps {
  hotspots: HeatmapData[]
  onHotspotSelect: (hotspot: HeatmapData | null) => void
}

// Fix for default markers in React Leaflet
delete (L.Icon.Default.prototype as any)._getIconUrl
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
})

// Simple tile layer component
function SimpleTileLayer({ isDark }: { isDark: boolean }) {
  const map = useMap()

  useEffect(() => {
    // Clear existing layers
    map.eachLayer((layer) => {
      if (layer instanceof L.TileLayer) {
        map.removeLayer(layer)
      }
    })

    // Add new tile layer
    const tileLayer = L.tileLayer(
      isDark 
        ? 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png'
        : 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
      {
        attribution: isDark 
          ? '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>'
          : '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
        subdomains: isDark ? 'abcd' : 'abc',
        maxZoom: 20,
      }
    )

    tileLayer.addTo(map)
  }, [isDark, map])

  return null
}

// Simple markers component
function SimpleMarkers({ hotspots, onHotspotSelect }: SimpleHeatmapMapProps) {
  const map = useMap()
  const [selectedHotspot, setSelectedHotspot] = useState<HeatmapData | null>(null)

  const getIntensityColor = (vehicles: number, maxVehicles: number) => {
    const intensity = vehicles / maxVehicles
    if (intensity > 0.8) return '#dc2626' // red
    if (intensity > 0.6) return '#ea580c' // orange
    if (intensity > 0.4) return '#d97706' // amber
    if (intensity > 0.2) return '#16a34a' // green
    return '#2563eb' // blue
  }

  const getIconSize = (vehicles: number, maxVehicles: number) => {
    const baseSize = 20
    const maxSize = 40
    const intensity = vehicles / maxVehicles
    return baseSize + (maxSize - baseSize) * intensity
  }

  const createCustomIcon = (vehicles: number, maxVehicles: number) => {
    const size = getIconSize(vehicles, maxVehicles)
    const color = getIntensityColor(vehicles, maxVehicles)
    const intensity = vehicles / maxVehicles
    
    let iconChar = '📍'
    if (intensity > 0.8) iconChar = '🔥'
    else if (intensity > 0.6) iconChar = '⚡'
    else if (intensity > 0.4) iconChar = '⭐'
    else if (intensity > 0.2) iconChar = '🚗'
    else iconChar = '📍'

    return L.divIcon({
      html: `
        <div style="
          width: ${size}px;
          height: ${size}px;
          background: ${color};
          border: 3px solid white;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: ${size * 0.5}px;
          box-shadow: 0 2px 8px rgba(0,0,0,0.3);
          cursor: pointer;
        ">
          ${iconChar}
        </div>
      `,
      className: 'custom-marker',
      iconSize: [size, size],
      iconAnchor: [size / 2, size / 2],
      popupAnchor: [0, -size / 2]
    })
  }

  useEffect(() => {
    if (!hotspots || hotspots.length === 0) return

    const maxVehicles = Math.max(...hotspots.map(h => h.vehicles || 0), 1)
    const markers: L.Marker[] = []

    // Create markers
    hotspots.forEach((hotspot, index) => {
      if (!hotspot || typeof hotspot.grid_lat !== 'number' || typeof hotspot.grid_lng !== 'number') {
        return
      }

      const icon = createCustomIcon(hotspot.vehicles || 0, maxVehicles)
      const marker = L.marker([hotspot.grid_lat, hotspot.grid_lng], { icon })

      // Add popup
      const popupColor = getIntensityColor(hotspot.vehicles || 0, maxVehicles)
      marker.bindPopup(`
        <div style="padding: 12px; min-width: 180px; background: white; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.15);">
          <div style="font-weight: bold; margin-bottom: 8px; color: #1f2937; font-size: 14px;">🔥 Hotspot Details</div>
          <div style="font-size: 12px; color: #374151; line-height: 1.5;">
            <div style="margin-bottom: 4px;"><strong style="color: #111827;">Vehicles:</strong> <span style="color: ${popupColor}; font-weight: bold;">${hotspot.vehicles || 0}</span></div>
            <div style="margin-bottom: 4px;"><strong style="color: #111827;">Lat:</strong> <span style="color: #374151;">${hotspot.grid_lat.toFixed(4)}</span></div>
            <div style="margin-bottom: 4px;"><strong style="color: #111827;">Lng:</strong> <span style="color: #374151;">${hotspot.grid_lng.toFixed(4)}</span></div>
            <div style="background: ${popupColor}20; padding: 4px 8px; border-radius: 4px; text-align: center; margin-top: 6px;">
              <strong style="color: ${popupColor};">Intensity: ${Math.round(((hotspot.vehicles || 0) / maxVehicles) * 100)}%</strong>
            </div>
          </div>
        </div>
      `)

      // Add click handler
      marker.on('click', () => {
        setSelectedHotspot(hotspot)
        onHotspotSelect(hotspot)
      })

      marker.addTo(map)
      markers.push(marker)
    })

    // Fit bounds to show all markers
    if (markers.length > 0) {
      const group = new L.FeatureGroup(markers)
      const bounds = group.getBounds()
      if (bounds && bounds.isValid()) {
        map.fitBounds(bounds.pad(0.1))
      }
    }

    // Cleanup function
    return () => {
      markers.forEach(marker => {
        map.removeLayer(marker)
      })
    }
  }, [hotspots, map, onHotspotSelect])

  return null
}

export default function SimpleHeatmapMap({ hotspots, onHotspotSelect }: SimpleHeatmapMapProps) {
  const [mounted, setMounted] = useState(false)
  const { theme, resolvedTheme } = useTheme()
  
  const isDark = resolvedTheme === 'dark'

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return (
      <div className="h-[500px] bg-gray-100 dark:bg-gray-800 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-sm font-semibold text-gray-800 dark:text-gray-200">Loading map...</p>
        </div>
      </div>
    )
  }

  if (!hotspots || hotspots.length === 0) {
    return (
      <div className="h-[500px] bg-gray-100 dark:bg-gray-800 flex items-center justify-center">
        <div className="text-center">
          <div className="text-4xl mb-4">🗺️</div>
          <h3 className="text-lg font-bold mb-2 text-gray-900 dark:text-white">No Data</h3>
          <p className="text-sm font-semibold text-gray-700 dark:text-gray-300">
            No heatmap data available
          </p>
        </div>
      </div>
    )
  }

  // Center of Chiang Mai, Thailand
  const center: [number, number] = [18.7883, 98.9853]
  const zoom = 12

  return (
    <div className="relative h-[500px]">
      {/* Legend */}
      <div className="absolute top-4 right-4 z-[1000] bg-white dark:bg-gray-800 p-3 rounded-lg shadow-lg border">
        <div className="text-sm font-bold mb-2 text-gray-900 dark:text-white">Heatmap Icons</div>
        <div className="space-y-1 text-xs">
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 rounded-full bg-red-600 flex items-center justify-center text-white text-xs">🔥</div>
            <span className="font-semibold text-gray-900 dark:text-white">High (80%+)</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 rounded-full bg-orange-600 flex items-center justify-center text-white text-xs">⚡</div>
            <span className="font-semibold text-gray-900 dark:text-white">Medium-High (60-80%)</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 rounded-full bg-amber-600 flex items-center justify-center text-white text-xs">⭐</div>
            <span className="font-semibold text-gray-900 dark:text-white">Medium (40-60%)</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 rounded-full bg-green-600 flex items-center justify-center text-white text-xs">🚗</div>
            <span className="font-semibold text-gray-900 dark:text-white">Low-Medium (20-40%)</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 rounded-full bg-blue-600 flex items-center justify-center text-white text-xs">📍</div>
            <span className="font-semibold text-gray-900 dark:text-white">Low (0-20%)</span>
          </div>
        </div>
      </div>

      <MapContainer
        center={center}
        zoom={zoom}
        style={{ height: '100%', width: '100%' }}
        className="z-0"
      >
        <SimpleTileLayer isDark={isDark} />
        <SimpleMarkers hotspots={hotspots} onHotspotSelect={onHotspotSelect} />
      </MapContainer>
    </div>
  )
}
