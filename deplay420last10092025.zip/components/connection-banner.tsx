"use client"

import { useEffect, useState } from "react"
import { AlertCircle, CheckCircle2 } from "lucide-react"

export function ConnectionBanner() {
  const [isConnected, setIsConnected] = useState<boolean | null>(null)

  useEffect(() => {
    const checkConnection = async () => {
      try {
        const response = await fetch("/api/vehicles/latest")
        const data = await response.json()
        setIsConnected(data.vehicles && data.vehicles.length >= 0)
      } catch {
        setIsConnected(false)
      }
    }

    checkConnection()
    const interval = setInterval(checkConnection, 10000)
    return () => clearInterval(interval)
  }, [])

  if (isConnected === null) return null
  if (isConnected) {
    return (
      <div className="bg-chart-4/10 border-l-4 border-chart-4 p-4 mb-6">
        <div className="flex items-center gap-3">
          <CheckCircle2 className="h-5 w-5 text-chart-4 flex-shrink-0" />
          <div>
            <p className="font-medium text-chart-4">เชื่อมต่อ Go API แล้ว</p>
            <p className="text-sm text-muted-foreground">ข้อมูลแบบเรียลไทม์กำลังไหล</p>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="bg-destructive/10 border-l-4 border-destructive p-4 mb-6">
      <div className="flex items-center gap-3">
        <AlertCircle className="h-5 w-5 text-destructive flex-shrink-0" />
        <div className="flex-1">
          <p className="font-medium text-destructive">Go API ไม่ได้เชื่อมต่อ</p>
          <p className="text-sm text-muted-foreground mt-1">กรุณาเริ่มเซิร์ฟเวอร์ Go API:</p>
          <code className="block mt-2 p-2 bg-secondary rounded text-xs font-mono">
            cd boltapilastver && go run *.go
          </code>
          <p className="text-xs text-muted-foreground mt-2">
            API ควรทำงานที่ <span className="font-mono">http://localhost:8000</span>
          </p>
        </div>
      </div>
    </div>
  )
}
