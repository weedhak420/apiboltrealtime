"use client"

import { useEffect, useState } from "react"
import { useTheme } from "next-themes"
import dynamic from "next/dynamic"
import { Vehicle } from "@/types/vehicles"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Settings } from "lucide-react"
import { Skeleton } from "@/components/ui/skeleton"

// Dynamically import the client-side map component to avoid SSR issues
const ClientOptimizedLiveMap = dynamic(() => import("./client-optimized-live-map"), {
  ssr: false,
  loading: () => (
    <div className="h-[600px] bg-secondary/20 flex items-center justify-center">
      <div className="text-center">
        <Skeleton className="h-8 w-48 mx-auto mb-4" />
        <Skeleton className="h-4 w-32 mx-auto" />
      </div>
    </div>
  ),
})

interface OptimizedLiveMapProps {
  vehicles: Vehicle[]
  selectedVehicle: Vehicle | null
  onVehicleSelect: (vehicle: Vehicle | null) => void
  maxVehicles?: number
  enableClustering?: boolean
  animationDuration?: number
}

export default function OptimizedLiveMap({
  vehicles,
  selectedVehicle,
  onVehicleSelect,
  maxVehicles = 500,
  enableClustering = true,
  animationDuration = 800
}: OptimizedLiveMapProps) {
  const [showSettings, setShowSettings] = useState(false)
  const [clusteringEnabled, setClusteringEnabled] = useState(enableClustering)
  const [darkMode, setDarkMode] = useState(false)
  const { resolvedTheme } = useTheme()
  
  const isDark = resolvedTheme === 'dark'

  useEffect(() => {
    setDarkMode(isDark)
  }, [isDark])

  return (
    <div className="space-y-4">
      {/* Performance Stats */}
      <Card className="p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4 text-sm">
            <div className="text-muted-foreground">
              Vehicles: {vehicles.length}
            </div>
            <div className="text-muted-foreground">
              Max: {maxVehicles}
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowSettings(!showSettings)}
            >
              <Settings className="h-4 w-4 mr-2" />
              Settings
            </Button>
          </div>
        </div>

        {/* Settings Panel */}
        {showSettings && (
          <div className="mt-4 p-4 bg-secondary/20 rounded-lg space-y-4">
            <div className="flex items-center justify-between">
              <Label htmlFor="clustering">Enable Clustering</Label>
              <Switch
                id="clustering"
                checked={clusteringEnabled}
                onCheckedChange={setClusteringEnabled}
              />
            </div>
            <div className="flex items-center justify-between">
              <Label htmlFor="dark-mode">Dark Mode</Label>
              <Switch
                id="dark-mode"
                checked={darkMode}
                onCheckedChange={setDarkMode}
              />
            </div>
            <div className="text-xs text-muted-foreground">
              Max Vehicles: {maxVehicles} • Animation: {animationDuration}ms
            </div>
          </div>
        )}
      </Card>

      {/* Optimized Map */}
      <ClientOptimizedLiveMap
        vehicles={vehicles}
        selectedVehicle={selectedVehicle}
        onVehicleSelect={onVehicleSelect}
        maxVehicles={maxVehicles}
        enableClustering={clusteringEnabled}
        animationDuration={animationDuration}
      />
    </div>
  )
}