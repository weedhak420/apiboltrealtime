"use client"

import { ReactQueryDevtools } from "@tanstack/react-query-devtools"

// Separate devtools component that can be conditionally imported
export function QueryDevtools() {
  // Only render in development
  if (process.env.NODE_ENV !== 'development') {
    return null
  }

  return <ReactQueryDevtools initialIsOpen={false} />
}
