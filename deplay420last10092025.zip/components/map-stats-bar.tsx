"use client"

import { useEffect, useState } from "react"
import { Skeleton } from "@/components/ui/skeleton"

interface Vehicle {
  id: string
  category_name: string
}

interface VehicleData {
  vehicles: Vehicle[]
  count: number
}

export function MapStatsBar() {
  const [data, setData] = useState<VehicleData | null>(null)
  const [lastUpdated, setLastUpdated] = useState<Date>(new Date())
  const [secondsAgo, setSecondsAgo] = useState(0)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch("/api/vehicles/latest", {
          cache: "no-store",
          signal: AbortSignal.timeout(10000) // 10 second timeout
        })
        
        if (!response.ok) {
          throw new Error(`HTTP ${response.status}`)
        }
        
        const result = await response.json()
        setData(result)
        setLastUpdated(new Date())
        setLoading(false)
      } catch (error) {
        console.error("[MapStatsBar] Failed to fetch vehicle data:", error)
        setLoading(false)
        // Don't clear existing data on error, just log it
      }
    }

    fetchData()
    // Increase interval to reduce API calls
    const interval = setInterval(fetchData, 10000) // 10 seconds instead of 5
    return () => clearInterval(interval)
  }, [])

  useEffect(() => {
    const interval = setInterval(() => {
      const seconds = Math.floor((Date.now() - lastUpdated.getTime()) / 1000)
      setSecondsAgo(seconds)
    }, 1000)
    return () => clearInterval(interval)
  }, [lastUpdated])

  const categoriesCount = data?.vehicles ? new Set(data.vehicles.map((v) => v.category_name)).size : 0

  if (loading) {
    return (
      <div className="border-t border-border bg-muted/30 px-6 py-3">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          <div className="flex flex-wrap items-center gap-4 lg:gap-6 text-sm">
            <div className="flex items-center gap-2">
              <span className="text-muted-foreground">รถทั้งหมด:</span>
              <Skeleton className="h-4 w-8" />
            </div>
            <div className="flex items-center gap-2">
              <span className="text-muted-foreground">หมวดหมู่:</span>
              <Skeleton className="h-4 w-8" />
            </div>
            <div className="flex items-center gap-2">
              <span className="text-muted-foreground">สถานะระบบ:</span>
              <Skeleton className="h-4 w-12" />
            </div>
          </div>
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <span>อัปเดตล่าสุด:</span>
            <Skeleton className="h-4 w-16" />
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="border-t border-border bg-muted/30 px-6 py-3">
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
        <div className="flex flex-wrap items-center gap-4 lg:gap-6 text-sm">
          <div className="flex items-center gap-2">
            <span className="text-muted-foreground">รถทั้งหมด:</span>
            <span className="font-medium">{data?.count || 0}</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-muted-foreground">หมวดหมู่:</span>
            <span className="font-medium">{categoriesCount}</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-muted-foreground">สถานะระบบ:</span>
            <span className={`font-medium ${data ? "text-green-500" : "text-red-500"}`}>
              {data ? "ออนไลน์" : "ออฟไลน์"}
            </span>
          </div>
        </div>
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <span>อัปเดตล่าสุด:</span>
          <span className="font-medium">{secondsAgo} วินาทีที่แล้ว</span>
        </div>
      </div>
    </div>
  )
}