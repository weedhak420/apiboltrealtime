"use client"

import { type ReactNode, useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { LayoutDashboard, Map, BarChart3, History, Activity, Menu, X, Car, TrendingUp, Heart, Zap, Shield } from "lucide-react"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { MapStatsBar } from "@/components/map-stats-bar"
import { ThemeToggle } from "@/components/theme-toggle"

const navigation = [
  { name: "Dashboard", name_th: "แดชบอร์ด", href: "/", icon: LayoutDashboard },
  { name: "Live Map", name_th: "แผนที่สด", href: "/map", icon: Map },
  { name: "Vehicles", name_th: "รถยนต์", href: "/vehicles", icon: Car },
  { name: "Vehicle History", name_th: "ประวัติรถ", href: "/vehicle-history", icon: History },
  { name: "Analytics", name_th: "การวิเคราะห์", href: "/analytics", icon: BarChart3 },
  { name: "Heatmap", name_th: "แผนที่ความร้อน", href: "/analytics/heatmap", icon: TrendingUp },
  { name: "Trends", name_th: "แนวโน้ม", href: "/analytics/trend", icon: BarChart3 },
  { name: "Analytics Summary", name_th: "สรุปการวิเคราะห์", href: "/analytics/summary", icon: TrendingUp },
  { name: "JWT Status", name_th: "สถานะ JWT", href: "/jwt-status", icon: Shield },
  { name: "System Status", name_th: "สถานะระบบ", href: "/system-status", icon: Activity },
  { name: "Health", name_th: "สุขภาพระบบ", href: "/health", icon: Heart },
  { name: "Performance", name_th: "ประสิทธิภาพ", href: "/performance", icon: Zap },
]

export function DashboardLayout({ children }: { children: ReactNode }) {
  const pathname = usePathname()
  const [sidebarOpen, setSidebarOpen] = useState(false)

  return (
    <div className="min-h-screen bg-background">
      {/* Mobile sidebar backdrop */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 z-40 bg-background/80 backdrop-blur-sm lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={cn(
          "fixed inset-y-0 left-0 z-50 w-64 bg-sidebar border-r border-sidebar-border transition-transform duration-300 lg:translate-x-0",
          sidebarOpen ? "translate-x-0" : "-translate-x-full",
        )}
      >
        <div className="flex h-full flex-col">
          {/* Logo */}
          <div className="flex h-16 items-center gap-3 border-b border-sidebar-border px-6">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary">
              <Map className="h-6 w-6 text-primary-foreground" />
            </div>
            <div className="flex flex-col">
              <span className="font-bold text-sidebar-foreground">ระบบติดตาม Bolt</span>
              <span className="text-xs text-muted-foreground">เชียงใหม่</span>
            </div>
          </div>

          {/* Navigation */}
          <nav className="flex-1 space-y-1 p-4">
            {navigation.map((item) => {
              const isActive = pathname === item.href
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  onClick={() => setSidebarOpen(false)}
                  className={cn(
                    "flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors",
                    isActive
                      ? "bg-sidebar-accent text-sidebar-accent-foreground"
                      : "text-muted-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground",
                  )}
                >
                  <item.icon className="h-5 w-5" />
                  <span>{item.name_th}</span>
                  <span className="text-xs opacity-60">({item.name})</span>
                </Link>
              )
            })}
          </nav>

          {/* Footer */}
          <div className="border-t border-sidebar-border p-4">
            <div className="rounded-lg bg-sidebar-accent p-3">
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <Activity className="h-4 w-4 text-chart-1" />
                <span>ระบบออนไลน์</span>
              </div>
              <div className="mt-1 text-xs text-muted-foreground">
                API: <span className="text-chart-1">เชื่อมต่อแล้ว</span>
              </div>
            </div>
          </div>
        </div>
      </aside>

      {/* Main content */}
      <div className="lg:pl-64">
        {/* Top bar */}
        <header className="sticky top-0 z-30 border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
          <div className="flex h-16 items-center gap-4 px-6">
            <Button variant="ghost" size="icon" className="lg:hidden" onClick={() => setSidebarOpen(!sidebarOpen)}>
              {sidebarOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>

            <div className="flex-1" />

            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <div className="h-2 w-2 rounded-full bg-chart-1 animate-pulse" />
                <span className="hidden sm:inline">อัปเดตแบบเรียลไทม์</span>
              </div>
              <ThemeToggle />
            </div>
          </div>
          
          {/* Top panel with stats - hidden on mobile */}
          <div className="hidden md:block">
            <MapStatsBar />
          </div>
        </header>

        {/* Page content */}
        <main className="p-6">{children}</main>
      </div>
    </div>
  )
}
