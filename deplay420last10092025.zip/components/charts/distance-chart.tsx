"use client"

import { useMemo } from "react"
import dynamic from "next/dynamic"

// Lazy load the chart library
const LineChart = dynamic(() => import("recharts").then(mod => ({ default: mod.LineChart })), {
  ssr: false,
  loading: () => <div className="h-[300px] flex items-center justify-center">Loading chart...</div>
})

const Line = dynamic(() => import("recharts").then(mod => ({ default: mod.Line })), { ssr: false })
const XAxis = dynamic(() => import("recharts").then(mod => ({ default: mod.XAxis })), { ssr: false })
const YAxis = dynamic(() => import("recharts").then(mod => ({ default: mod.YAxis })), { ssr: false })
const CartesianGrid = dynamic(() => import("recharts").then(mod => ({ default: mod.CartesianGrid })), { ssr: false })
const Tooltip = dynamic(() => import("recharts").then(mod => ({ default: mod.Tooltip })), { ssr: false })
const ResponsiveContainer = dynamic(() => import("recharts").then(mod => ({ default: mod.ResponsiveContainer })), { ssr: false })

interface DistanceDataPoint {
  time: number
  distance: number
}

interface DistanceChartProps {
  data: DistanceDataPoint[]
}

export default function DistanceChart({ data }: DistanceChartProps) {
  const chartData = useMemo(() => {
    if (!data || data.length === 0) return []
    
    // Group data by time intervals for better visualization
    const interval = Math.max(1, Math.floor(data.length / 50)) // Max 50 points
    return data
      .filter((_, index) => index % interval === 0)
      .map(point => ({
        time: new Date(point.time).toLocaleTimeString(),
        distance: Math.round(point.distance * 100) / 100 // Round to 2 decimal places
      }))
  }, [data])

  if (!chartData || chartData.length === 0) {
    return (
      <div className="h-[300px] flex items-center justify-center text-gray-500">
        No distance data available
      </div>
    )
  }

  return (
    <ResponsiveContainer width="100%" height={300}>
      <LineChart data={chartData}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis 
          dataKey="time" 
          tick={{ fontSize: 12 }}
          angle={-45}
          textAnchor="end"
          height={60}
        />
        <YAxis 
          label={{ value: 'Distance (km)', angle: -90, position: 'insideLeft' }}
          tick={{ fontSize: 12 }}
        />
        <Tooltip 
          formatter={(value: any, name: string) => [value, 'Distance (km)']}
          labelFormatter={(label) => `Time: ${label}`}
        />
        <Line 
          type="monotone" 
          dataKey="distance" 
          stroke="#82ca9d" 
          strokeWidth={2}
          dot={{ r: 3 }}
          activeDot={{ r: 6 }}
        />
      </LineChart>
    </ResponsiveContainer>
  )
}
