"use client"

import { useMemo } from "react"
import dynamic from "next/dynamic"

// Lazy load the chart library
const PieChart = dynamic(() => import("recharts").then(mod => ({ default: mod.PieChart })), {
  ssr: false,
  loading: () => <div className="h-[300px] flex items-center justify-center">Loading chart...</div>
})

const Pie = dynamic(() => import("recharts").then(mod => ({ default: mod.Pie })), { ssr: false })
const Cell = dynamic(() => import("recharts").then(mod => ({ default: mod.Cell })), { ssr: false })
const Tooltip = dynamic(() => import("recharts").then(mod => ({ default: mod.Tooltip })), { ssr: false })
const ResponsiveContainer = dynamic(() => import("recharts").then(mod => ({ default: mod.ResponsiveContainer })), { ssr: false })

interface BearingData {
  [direction: string]: number
}

interface BearingChartProps {
  data: BearingData
}

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8', '#82CA9D', '#FFC658', '#FF7C7C']

export default function BearingChart({ data }: BearingChartProps) {
  const chartData = useMemo(() => {
    if (!data || Object.keys(data).length === 0) return []
    
    return Object.entries(data)
      .map(([direction, count]) => ({
        direction,
        count,
        percentage: Math.round((count / Object.values(data).reduce((a, b) => a + b, 0)) * 100)
      }))
      .sort((a, b) => b.count - a.count)
  }, [data])

  if (!chartData || chartData.length === 0) {
    return (
      <div className="h-[300px] flex items-center justify-center text-gray-500">
        No bearing data available
      </div>
    )
  }

  return (
    <ResponsiveContainer width="100%" height={300}>
      <PieChart>
        <Pie
          data={chartData}
          cx="50%"
          cy="50%"
          labelLine={false}
          label={({ direction, percentage }) => `${direction}: ${percentage}%`}
          outerRadius={80}
          fill="#8884d8"
          dataKey="count"
        >
          {chartData.map((entry, index) => (
            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
          ))}
        </Pie>
        <Tooltip 
          formatter={(value: any, name: string) => [value, 'Count']}
          labelFormatter={(label) => `Direction: ${label}`}
        />
      </PieChart>
    </ResponsiveContainer>
  )
}
