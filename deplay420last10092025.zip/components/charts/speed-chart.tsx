"use client"

import { useMemo } from "react"
import dynamic from "next/dynamic"

// Lazy load the chart library
const LineChart = dynamic(() => import("recharts").then(mod => ({ default: mod.LineChart })), {
  ssr: false,
  loading: () => <div className="h-[300px] flex items-center justify-center">Loading chart...</div>
})

const Line = dynamic(() => import("recharts").then(mod => ({ default: mod.Line })), { ssr: false })
const XAxis = dynamic(() => import("recharts").then(mod => ({ default: mod.XAxis })), { ssr: false })
const YAxis = dynamic(() => import("recharts").then(mod => ({ default: mod.YAxis })), { ssr: false })
const CartesianGrid = dynamic(() => import("recharts").then(mod => ({ default: mod.CartesianGrid })), { ssr: false })
const Tooltip = dynamic(() => import("recharts").then(mod => ({ default: mod.Tooltip })), { ssr: false })
const ResponsiveContainer = dynamic(() => import("recharts").then(mod => ({ default: mod.ResponsiveContainer })), { ssr: false })

interface SpeedDataPoint {
  time: number
  speed: number
  vehicle: string
}

interface SpeedChartProps {
  data: SpeedDataPoint[]
}

export default function SpeedChart({ data }: SpeedChartProps) {
  const chartData = useMemo(() => {
    if (!data || data.length === 0) return []
    
    // Group data by time intervals for better visualization
    const interval = Math.max(1, Math.floor(data.length / 50)) // Max 50 points
    return data
      .filter((_, index) => index % interval === 0)
      .map(point => ({
        time: new Date(point.time).toLocaleTimeString(),
        speed: point.speed,
        vehicle: point.vehicle
      }))
  }, [data])

  if (!chartData || chartData.length === 0) {
    return (
      <div className="h-[300px] flex items-center justify-center text-gray-500">
        No speed data available
      </div>
    )
  }

  return (
    <ResponsiveContainer width="100%" height={300}>
      <LineChart data={chartData}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis 
          dataKey="time" 
          tick={{ fontSize: 12 }}
          angle={-45}
          textAnchor="end"
          height={60}
        />
        <YAxis 
          label={{ value: 'Speed (km/h)', angle: -90, position: 'insideLeft' }}
          tick={{ fontSize: 12 }}
        />
        <Tooltip 
          formatter={(value: any, name: string) => [value, 'Speed (km/h)']}
          labelFormatter={(label) => `Time: ${label}`}
        />
        <Line 
          type="monotone" 
          dataKey="speed" 
          stroke="#8884d8" 
          strokeWidth={2}
          dot={{ r: 3 }}
          activeDot={{ r: 6 }}
        />
      </LineChart>
    </ResponsiveContainer>
  )
}
