"use client"

import { useMemo } from "react"
import dynamic from "next/dynamic"

// Lazy load the chart library
const BarChart = dynamic(() => import("recharts").then(mod => ({ default: mod.BarChart })), {
  ssr: false,
  loading: () => <div className="h-[300px] flex items-center justify-center">Loading chart...</div>
})

const Bar = dynamic(() => import("recharts").then(mod => ({ default: mod.Bar })), { ssr: false })
const XAxis = dynamic(() => import("recharts").then(mod => ({ default: mod.XAxis })), { ssr: false })
const YAxis = dynamic(() => import("recharts").then(mod => ({ default: mod.YAxis })), { ssr: false })
const CartesianGrid = dynamic(() => import("recharts").then(mod => ({ default: mod.CartesianGrid })), { ssr: false })
const Tooltip = dynamic(() => import("recharts").then(mod => ({ default: mod.Tooltip })), { ssr: false })
const ResponsiveContainer = dynamic(() => import("recharts").then(mod => ({ default: mod.ResponsiveContainer })), { ssr: false })

interface Hotspot {
  grid_lat: number
  grid_lng: number
  vehicles: number
}

interface HotspotsChartProps {
  data: Hotspot[]
}

export default function HotspotsChart({ data }: HotspotsChartProps) {
  const chartData = useMemo(() => {
    if (!data || data.length === 0) return []
    
    return data
      .sort((a, b) => b.vehicles - a.vehicles)
      .slice(0, 10) // Show top 10 hotspots
      .map((hotspot, index) => ({
        location: `Grid ${index + 1}`,
        vehicles: hotspot.vehicles,
        coordinates: `${hotspot.grid_lat.toFixed(4)}, ${hotspot.grid_lng.toFixed(4)}`
      }))
  }, [data])

  if (!chartData || chartData.length === 0) {
    return (
      <div className="h-[300px] flex items-center justify-center text-gray-500">
        No hotspot data available
      </div>
    )
  }

  return (
    <ResponsiveContainer width="100%" height={300}>
      <BarChart data={chartData} layout="horizontal">
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis 
          type="number"
          label={{ value: 'Number of Vehicles', position: 'insideBottom', offset: -5 }}
          tick={{ fontSize: 12 }}
        />
        <YAxis 
          type="category"
          dataKey="location"
          tick={{ fontSize: 12 }}
          width={80}
        />
        <Tooltip 
          formatter={(value: any, name: string) => [value, 'Vehicles']}
          labelFormatter={(label, payload) => {
            const data = payload?.[0]?.payload
            return data ? `Location: ${data.coordinates}` : label
          }}
        />
        <Bar 
          dataKey="vehicles" 
          fill="#8884d8"
          radius={[0, 4, 4, 0]}
        />
      </BarChart>
    </ResponsiveContainer>
  )
}
