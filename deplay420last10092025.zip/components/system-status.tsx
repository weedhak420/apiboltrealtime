"use client"

import { useEffect, useState } from "react"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Activity, Database, Zap, Clock, CheckCircle2, XCircle } from "lucide-react"

interface HealthStatus {
  status: string
  timestamp: string
  components?: {
    database?: { status: string }
    redis?: { status: string }
    api?: { status: string }
  }
}

interface PerformanceStats {
  goroutine_count: number
  cache_size: number
  timestamp: string
}

export function SystemStatus() {
  const [health, setHealth] = useState<HealthStatus | null>(null)
  const [performance, setPerformance] = useState<PerformanceStats | null>(null)

  useEffect(() => {
    const fetchStatus = async () => {
      try {
        const [healthRes, perfRes] = await Promise.all([fetch("/api/health"), fetch("/api/performance")])

        const healthData = await healthRes.json()
        const perfData = await perfRes.json()

        setHealth(healthData)
        setPerformance(perfData)
      } catch (error) {
        console.error("[v0] Failed to fetch system status:", error)
      }
    }

    fetchStatus()
    const interval = setInterval(fetchStatus, 10000)
    return () => clearInterval(interval)
  }, [])

  const getStatusColor = (status?: string) => {
    if (!status) return "text-muted-foreground"
    return status === "healthy" || status === "running" ? "text-chart-4" : "text-destructive"
  }

  const getStatusIcon = (status?: string) => {
    if (!status) return XCircle
    return status === "healthy" || status === "running" ? CheckCircle2 : XCircle
  }

  return (
    <div className="grid gap-6 lg:grid-cols-2">
      {/* Health Status */}
      <Card className="p-6">
        <div className="flex items-center gap-2 mb-6">
          <Activity className="h-5 w-5 text-chart-1" />
          <h2 className="text-lg font-semibold">สถานะสุขภาพ</h2>
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 rounded-lg bg-secondary/50">
            <div className="flex items-center gap-3">
              <Activity className={getStatusColor(health?.status)} />
              <div>
                <p className="font-medium">สถานะโดยรวม</p>
                <p className="text-sm text-muted-foreground">สุขภาพระบบ</p>
              </div>
            </div>
            <Badge variant={health?.status === "healthy" ? "default" : "destructive"}>
              {health?.status || "Unknown"}
            </Badge>
          </div>

          {health?.components && (
            <>
              <div className="flex items-center justify-between p-4 rounded-lg bg-secondary/50">
                <div className="flex items-center gap-3">
                  <Database className={getStatusColor(health.components.database?.status)} />
                  <div>
                    <p className="font-medium">ฐานข้อมูล</p>
                    <p className="text-sm text-muted-foreground">การเชื่อมต่อ MySQL</p>
                  </div>
                </div>
                <Badge variant={health.components.database?.status === "healthy" ? "default" : "destructive"}>
                  {health.components.database?.status || "Unknown"}
                </Badge>
              </div>

              <div className="flex items-center justify-between p-4 rounded-lg bg-secondary/50">
                <div className="flex items-center gap-3">
                  <Zap className={getStatusColor(health.components.redis?.status)} />
                  <div>
                    <p className="font-medium">Redis Cache</p>
                    <p className="text-sm text-muted-foreground">ชั้นแคช</p>
                  </div>
                </div>
                <Badge variant={health.components.redis?.status === "healthy" ? "default" : "destructive"}>
                  {health.components.redis?.status || "Unknown"}
                </Badge>
              </div>

              <div className="flex items-center justify-between p-4 rounded-lg bg-secondary/50">
                <div className="flex items-center gap-3">
                  <Activity className={getStatusColor(health.components.api?.status)} />
                  <div>
                    <p className="font-medium">Bolt API</p>
                    <p className="text-sm text-muted-foreground">API ภายนอก</p>
                  </div>
                </div>
                <Badge variant={health.components.api?.status === "healthy" ? "default" : "destructive"}>
                  {health.components.api?.status || "Unknown"}
                </Badge>
              </div>
            </>
          )}
        </div>
      </Card>

      {/* Performance Metrics */}
      <Card className="p-6">
        <div className="flex items-center gap-2 mb-6">
          <Zap className="h-5 w-5 text-chart-2" />
          <h2 className="text-lg font-semibold">เมตริกประสิทธิภาพ</h2>
        </div>

        <div className="space-y-6">
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-muted-foreground">Goroutines</span>
              <span className="text-2xl font-bold">{performance?.goroutine_count || 0}</span>
            </div>
            <div className="h-2 rounded-full bg-secondary overflow-hidden">
              <div
                className="h-full bg-chart-1 transition-all"
                style={{ width: `${Math.min(((performance?.goroutine_count || 0) / 100) * 100, 100)}%` }}
              />
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-muted-foreground">ขนาดแคช</span>
              <span className="text-2xl font-bold">{performance?.cache_size || 0}</span>
            </div>
            <div className="h-2 rounded-full bg-secondary overflow-hidden">
              <div
                className="h-full bg-chart-2 transition-all"
                style={{ width: `${Math.min(((performance?.cache_size || 0) / 500) * 100, 100)}%` }}
              />
            </div>
          </div>

          <div className="pt-4 border-t border-border">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Clock className="h-4 w-4" />
              <span>
                อัปเดตล่าสุด:{" "}
                {performance?.timestamp ? new Date(performance.timestamp).toLocaleTimeString("th-TH") : "N/A"}
              </span>
            </div>
          </div>
        </div>
      </Card>

      {/* System Info */}
      <Card className="p-6 lg:col-span-2">
        <div className="flex items-center gap-2 mb-6">
          <Activity className="h-5 w-5 text-chart-3" />
          <h2 className="text-lg font-semibold">ข้อมูลระบบ</h2>
        </div>

        <div className="grid gap-4 md:grid-cols-3">
          <div className="p-4 rounded-lg bg-secondary/50">
            <p className="text-sm text-muted-foreground mb-1">API Endpoint</p>
            <p className="font-mono text-sm">localhost:8000</p>
          </div>
          <div className="p-4 rounded-lg bg-secondary/50">
            <p className="text-sm text-muted-foreground mb-1">ช่วงเวลาอัปเดต</p>
            <p className="font-semibold">5 วินาที</p>
          </div>
          <div className="p-4 rounded-lg bg-secondary/50">
            <p className="text-sm text-muted-foreground mb-1">จำนวน Worker สูงสุด</p>
            <p className="font-semibold">3 workers</p>
          </div>
        </div>
      </Card>
    </div>
  )
}
