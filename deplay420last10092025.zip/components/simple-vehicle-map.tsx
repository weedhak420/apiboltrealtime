"use client"

import { useState, useEffect } from "react"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { MapPin, Navigation, Car, RefreshCw } from "lucide-react"
import { Vehicle } from "@/types/vehicles"

interface SimpleVehicleMapProps {
  vehicles: Vehicle[]
  selectedVehicle: Vehicle | null
  onVehicleSelect: (vehicle: Vehicle | null) => void
}

export default function SimpleVehicleMap({ vehicles, selectedVehicle, onVehicleSelect }: SimpleVehicleMapProps) {
  const [mapError, setMapError] = useState(false)
  const [retryCount, setRetryCount] = useState(0)

  // Try to load Leaflet map, fallback to simple grid view
  useEffect(() => {
    const loadMap = async () => {
      try {
        // Check if Leaflet is available
        if (typeof window !== 'undefined' && !window.L) {
          // Try to load Leaflet dynamically
          await import('leaflet')
          await import('react-leaflet')
        }
        setMapError(false)
      } catch (error) {
        console.warn('Leaflet not available, using fallback view:', error)
        setMapError(true)
      }
    }

    loadMap()
  }, [retryCount])

  const handleRetry = () => {
    setRetryCount(prev => prev + 1)
    setMapError(false)
  }

  // Fallback grid view when map is not available
  if (mapError) {
    return (
      <div className="h-[600px] bg-secondary/20 rounded-lg border-2 border-dashed border-border">
        <div className="h-full flex flex-col">
          {/* Header */}
          <div className="p-4 border-b border-border bg-card">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-semibold">Vehicle Locations</h3>
                <p className="text-sm text-muted-foreground">
                  {vehicles.length} vehicles tracked
                </p>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant="outline" className="border-yellow-500 text-yellow-500">
                  <div className="w-2 h-2 bg-yellow-500 rounded-full mr-2" />
                  Grid View
                </Badge>
                <Button variant="outline" size="sm" onClick={handleRetry}>
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Retry Map
                </Button>
              </div>
            </div>
          </div>

          {/* Grid Content */}
          <div className="flex-1 p-4 overflow-y-auto">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {vehicles.map((vehicle, index) => (
                <Card 
                  key={`${vehicle.id}-${index}`}
                  className={`p-4 cursor-pointer transition-all hover:shadow-md ${
                    selectedVehicle?.id === vehicle.id 
                      ? 'ring-2 ring-primary bg-primary/5' 
                      : 'hover:bg-secondary/50'
                  }`}
                  onClick={() => onVehicleSelect(vehicle)}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-primary/10 rounded-lg">
                        <Car className="h-4 w-4 text-primary" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="font-medium text-sm truncate">
                          {vehicle.id.slice(0, 12)}...
                        </div>
                        <div className="text-xs text-muted-foreground truncate">
                          {vehicle.source_location || 'Unknown'}
                        </div>
                      </div>
                    </div>
                    <Badge 
                      variant="outline" 
                      className="text-xs"
                    >
                      {vehicle.category_name || 'Unknown'}
                    </Badge>
                  </div>
                  
                  <div className="mt-3 space-y-2">
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <MapPin className="h-3 w-3" />
                      <span className="font-mono">
                        {vehicle.lat.toFixed(4)}, {vehicle.lng.toFixed(4)}
                      </span>
                    </div>
                    
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <Navigation 
                        className="h-3 w-3" 
                        style={{ transform: `rotate(${vehicle.bearing || 0}deg)` }}
                      />
                      <span>
                        {Math.round(vehicle.bearing || 0)}° {getBearingDirection(vehicle.bearing || 0)}
                      </span>
                    </div>
                    
                    {vehicle.distance && (
                      <div className="text-xs text-muted-foreground">
                        Distance: {vehicle.distance.toFixed(1)}m
                      </div>
                    )}
                  </div>
                </Card>
              ))}
            </div>
            
            {vehicles.length === 0 && (
              <div className="text-center py-12">
                <Car className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <p className="text-muted-foreground">No vehicles found</p>
              </div>
            )}
          </div>
        </div>
      </div>
    )
  }

  // Try to render Leaflet map
  try {
    const { MapContainer, TileLayer, Marker, Popup } = require('react-leaflet')
    const L = require('leaflet')
    
    // Fix for default markers
    delete (L.Icon.Default.prototype as any)._getIconUrl
    L.Icon.Default.mergeOptions({
      iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
      iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
      shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
    })

    return (
      <div className="h-[600px] relative">
        <MapContainer
          center={[18.7883, 98.9853]} // Chiang Mai center
          zoom={13}
          style={{ height: '100%', width: '100%' }}
          className="z-0"
        >
          <TileLayer
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          />
          
          {vehicles.map((vehicle, index) => (
            <Marker
              key={`${vehicle.id}-${index}`}
              position={[vehicle.lat, vehicle.lng]}
              eventHandlers={{
                click: () => onVehicleSelect(vehicle),
              }}
            >
              <Popup>
                <div className="space-y-1">
                  <div><b>ID:</b> {vehicle.id}</div>
                  <div><b>Category:</b> {vehicle.category_name || 'Unknown'}</div>
                  <div><b>Location:</b> {vehicle.source_location || 'Unknown'}</div>
                  <div><b>Bearing:</b> {Math.round(vehicle.bearing || 0)}°</div>
                  <div><b>Coordinates:</b> {vehicle.lat.toFixed(4)}, {vehicle.lng.toFixed(4)}</div>
                </div>
              </Popup>
            </Marker>
          ))}
        </MapContainer>
        
        {/* Live badge */}
        <div className="absolute top-4 right-4 z-[1000]">
          <div className="bg-red-500 text-white px-3 py-1 rounded-full text-xs font-medium flex items-center gap-2 shadow-lg">
            <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
            Live
          </div>
        </div>
      </div>
    )
  } catch (error) {
    console.warn('Leaflet map failed to render:', error)
    setMapError(true)
    return null
  }
}

// Helper function for bearing direction
function getBearingDirection(bearing: number): string {
  const directions = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW']
  const index = Math.round(bearing / 45) % 8
  return directions[index]
}
