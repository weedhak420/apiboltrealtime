"use client"

import { useEffect, useState, useRef, useCallback, memo } from "react"
import { MapContainer, TileLayer, useMap, Marker } from "react-leaflet"
import L from "leaflet"
import "leaflet/dist/leaflet.css"
import { Vehicle } from "@/types/vehicles"
import { io, Socket } from "socket.io-client"

// Fix for default markers in React-Leaflet
delete (L.Icon.Default.prototype as any)._getIconUrl
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
})

interface ClientOptimizedLiveMapProps {
  vehicles: Vehicle[]
  selectedVehicle: Vehicle | null
  onVehicleSelect: (vehicle: Vehicle | null) => void
  maxVehicles?: number
  enableClustering?: boolean
  animationDuration?: number
}

// Create vehicle-specific icons using real icon_url from Bolt API
const createVehicleIcon = (vehicle: Vehicle, isSelected: boolean = false) => {
  const size = isSelected ? 32 : 24
  const borderColor = isSelected ? '#ef4444' : '#3b82f6'
  const borderWidth = isSelected ? 3 : 2

  // Use the actual icon_url from Bolt API if available
  if (vehicle.icon_url) {
    return L.divIcon({
      html: `
        <div style="
          width: ${size}px;
          height: ${size}px;
          border: ${borderWidth}px solid ${borderColor};
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          box-shadow: 0 2px 8px rgba(0,0,0,0.3);
          cursor: pointer;
          transition: all 0.3s ease;
          background: white;
          overflow: hidden;
        ">
          <img 
            src="${vehicle.icon_url}" 
            alt="${vehicle.category_name || 'Vehicle'}"
            style="
              width: ${size - 8}px;
              height: ${size - 8}px;
              object-fit: contain;
            "
            onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';"
          />
          <div style="
            display: none;
            width: ${size - 8}px;
            height: ${size - 8}px;
            background: #3b82f6;
            border-radius: 50%;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: ${(size - 8) * 0.6}px;
          ">🚗</div>
        </div>
      `,
      className: 'custom-vehicle-marker',
      iconSize: [size, size],
      iconAnchor: [size / 2, size / 2]
    })
  }

  // Fallback to category-based icons if no icon_url
  const getIconColor = (category: string) => {
    switch (category?.toLowerCase()) {
      case 'basic':
        return '#3b82f6' // Blue
      case 'comfort':
        return '#22c55e' // Green
      case 'premium':
        return '#f59e0b' // Yellow
      case 'xl':
        return '#8b5cf6' // Purple
      default:
        return '#6b7280' // Gray
    }
  }

  const getIconSymbol = (category: string) => {
    switch (category?.toLowerCase()) {
      case 'basic':
        return '🚕'
      case 'comfort':
        return '🚖'
      case 'premium':
        return '🚗'
      case 'xl':
        return '🚙'
      default:
        return '🚗'
    }
  }

  const color = getIconColor(vehicle.category_name)
  const symbol = getIconSymbol(vehicle.category_name)

  return L.divIcon({
    html: `
      <div style="
        width: ${size}px;
        height: ${size}px;
        background: ${isSelected ? '#ef4444' : color};
        border: ${borderWidth}px solid white;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: ${size * 0.6}px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.3);
        cursor: pointer;
        transition: all 0.3s ease;
      ">
        ${symbol}
      </div>
    `,
    className: 'custom-vehicle-marker',
    iconSize: [size, size],
    iconAnchor: [size / 2, size / 2]
  })
}

// Debounced vehicle update hook
function useDebouncedVehicles(vehicles: Vehicle[], delay: number = 200) {
  const [debouncedVehicles, setDebouncedVehicles] = useState<Vehicle[]>(vehicles)
  const timeoutRef = useRef<NodeJS.Timeout>()

  useEffect(() => {
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current)
    }

    timeoutRef.current = setTimeout(() => {
      setDebouncedVehicles(vehicles)
    }, delay)

    return () => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current)
      }
    }
  }, [vehicles, delay])

  return debouncedVehicles
}

// WebSocket hook for real-time updates
function useWebSocket() {
  const [socket, setSocket] = useState<Socket | null>(null)
  const [connectionStatus, setConnectionStatus] = useState<'connecting' | 'connected' | 'disconnected'>('disconnected')
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null)
  const [latency, setLatency] = useState<number>(0)

  useEffect(() => {
    let mounted = true
    let pingInterval: NodeJS.Timeout

    const connectWebSocket = () => {
      try {
        const WS_URL = process.env.NEXT_PUBLIC_WS_URL ?? "ws://localhost:8000"
        const newSocket = io(WS_URL, {
          transports: ["websocket"],
          timeout: 5000,
          forceNew: true,
          autoConnect: true
        })

        newSocket.on("connect", () => {
          if (!mounted) return
          console.log("WebSocket connected to:", WS_URL)
          setConnectionStatus('connected')
        })

        newSocket.on("vehicles_update", (payload: any) => {
          if (!mounted) return
          const startTime = performance.now()
          setLastUpdate(new Date())
          setLatency(performance.now() - startTime)
        })

        newSocket.on("disconnect", (reason: string) => {
          if (!mounted) return
          console.log("WebSocket disconnected:", reason)
          setConnectionStatus('disconnected')
        })

        newSocket.on("connect_error", (error: any) => {
          if (!mounted) return
          console.log("WebSocket connection error:", error.message)
          setConnectionStatus('disconnected')
        })

        setSocket(newSocket)

        // Ping for latency measurement
        pingInterval = setInterval(() => {
          if (newSocket.connected) {
            const start = performance.now()
            newSocket.emit('ping', () => {
              setLatency(performance.now() - start)
            })
          }
        }, 5000)

      } catch (error) {
        console.error("WebSocket setup failed:", error)
        setConnectionStatus('disconnected')
      }
    }

    connectWebSocket()

    return () => {
      mounted = false
      if (pingInterval) clearInterval(pingInterval)
      if (socket) {
        socket.close()
      }
    }
  }, [])

  return { socket, connectionStatus, lastUpdate, latency }
}

// Map updater component with vehicle-specific markers
function MapUpdater({ 
  vehicles, 
  selectedVehicle, 
  onVehicleSelect, 
  maxVehicles 
}: {
  vehicles: Vehicle[]
  selectedVehicle: Vehicle | null
  onVehicleSelect: (vehicle: Vehicle | null) => void
  maxVehicles: number
}) {
  const map = useMap()
  const markersRef = useRef<Map<string, L.Marker>>(new Map())

  // Update markers
  useEffect(() => {
    // Clear existing markers
    markersRef.current.forEach(marker => {
      map.removeLayer(marker)
    })
    markersRef.current.clear()

    // Add new markers (limited by maxVehicles)
    const vehiclesToShow = vehicles.slice(0, maxVehicles)
    
    vehiclesToShow.forEach((vehicle) => {
      const isSelected = selectedVehicle?.id === vehicle.id
      const marker = L.marker([vehicle.lat, vehicle.lng], {
        icon: createVehicleIcon(vehicle, isSelected)
      })

      marker.on('click', () => {
        onVehicleSelect(vehicle)
      })

      marker.addTo(map)
      markersRef.current.set(vehicle.id, marker)
    })
  }, [vehicles, selectedVehicle, onVehicleSelect, maxVehicles, map])

  // Center on selected vehicle
  useEffect(() => {
    if (selectedVehicle) {
      map.setView([selectedVehicle.lat, selectedVehicle.lng], Math.max(map.getZoom(), 15), {
        animate: true,
        duration: 1
      })
    }
  }, [selectedVehicle, map])

  return null
}

// Tile layer updater for theme switching
function TileLayerUpdater({ isDark }: { isDark: boolean }) {
  const map = useMap()
  const [currentLayer, setCurrentLayer] = useState<string | null>(null)

  useEffect(() => {
    // Remove existing tile layer
    if (currentLayer) {
      map.eachLayer((layer) => {
        if (layer instanceof L.TileLayer) {
          map.removeLayer(layer)
        }
      })
    }

    // Add new tile layer based on theme
    const tileLayer = L.tileLayer(
      isDark 
        ? 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png'
        : 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
      {
        attribution: isDark 
          ? '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>'
          : '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
        subdomains: isDark ? 'abcd' : 'abc',
        maxZoom: 20,
      }
    )

    tileLayer.addTo(map)
    setCurrentLayer(isDark ? 'dark' : 'light')
  }, [isDark, map])

  return null
}

export default function ClientOptimizedLiveMap({
  vehicles,
  selectedVehicle,
  onVehicleSelect,
  maxVehicles = 500,
  enableClustering = true,
  animationDuration = 800
}: ClientOptimizedLiveMapProps) {
  const [mounted, setMounted] = useState(false)
  const [mapError, setMapError] = useState(false)
  const [darkMode, setDarkMode] = useState(false)
  
  const debouncedVehicles = useDebouncedVehicles(vehicles, 200)
  const { connectionStatus, lastUpdate, latency } = useWebSocket()

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return (
      <div className="h-[600px] bg-secondary/20 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-sm text-muted-foreground">Loading optimized map...</p>
        </div>
      </div>
    )
  }

  if (mapError) {
    return (
      <div className="relative h-[600px]">
        <div className="h-full bg-secondary/20 flex items-center justify-center">
          <div className="text-center">
            <div className="text-4xl mb-4">🗺️</div>
            <h3 className="text-lg font-semibold mb-2">Map Unavailable</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Unable to load map tiles. Please check your connection.
            </p>
            <button 
              onClick={() => setMapError(false)}
              className="px-4 py-2 bg-primary text-primary-foreground rounded-md text-sm hover:bg-primary/90"
            >
              Retry
            </button>
          </div>
        </div>
      </div>
    )
  }

  // Center of Chiang Mai, Thailand
  const center: [number, number] = [18.7883, 98.9853]
  const zoom = 13

  return (
    <div className="relative h-[600px]">
      {/* Live badge */}
      <div className="absolute top-4 right-4 z-[1000]">
        <div className="bg-red-500 text-white px-3 py-1 rounded-full text-xs font-medium flex items-center gap-2 shadow-lg">
          <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
          Live
        </div>
      </div>

      {/* Connection Status */}
      <div className="absolute top-4 left-4 z-[1000]">
        <div className={`px-3 py-1 rounded-full text-xs font-medium flex items-center gap-2 shadow-lg ${
          connectionStatus === 'connected' 
            ? 'bg-green-500 text-white' 
            : connectionStatus === 'connecting'
            ? 'bg-yellow-500 text-white'
            : 'bg-red-500 text-white'
        }`}>
          <div className={`w-2 h-2 rounded-full ${
            connectionStatus === 'connected' ? 'bg-white animate-pulse' : 'bg-white'
          }`}></div>
          {connectionStatus === 'connected' ? 'WebSocket' : 
           connectionStatus === 'connecting' ? 'Connecting' : 'Disconnected'}
        </div>
      </div>

      <MapContainer
        center={center}
        zoom={zoom}
        style={{ height: '100%', width: '100%' }}
        className="z-0"
        whenCreated={(map) => {
          map.on('tileerror', () => {
            setMapError(true)
          })
        }}
      >
        <TileLayerUpdater isDark={darkMode} />
        
        <MapUpdater
          vehicles={debouncedVehicles}
          selectedVehicle={selectedVehicle}
          onVehicleSelect={onVehicleSelect}
          maxVehicles={maxVehicles}
        />
      </MapContainer>
    </div>
  )
}
