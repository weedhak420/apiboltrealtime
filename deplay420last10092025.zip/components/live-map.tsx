"use client"

import { useEffect, useState, useRef } from "react"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Skeleton } from "@/components/ui/skeleton"
import { Navigation, MapPin } from "lucide-react"
import { MapSettings } from "@/components/map-settings"
import { fetchLatestVehicles } from "@/lib/api"
import { Vehicle } from "@/types/vehicles"
import dynamic from "next/dynamic"

// Dynamically import the map component to avoid SSR issues
const LiveMapFull = dynamic(() => import("./live-map-full"), {
  ssr: false,
  loading: () => (
    <div className="h-[600px] bg-secondary/20 flex items-center justify-center">
      <div className="text-center">
        <Skeleton className="h-8 w-48 mx-auto mb-4" />
        <Skeleton className="h-4 w-32 mx-auto" />
      </div>
    </div>
  ),
})

export function LiveMap() {
  const [vehicles, setVehicles] = useState<Vehicle[]>([])
  const [selectedVehicle, setSelectedVehicle] = useState<Vehicle | null>(null)
  const [loading, setLoading] = useState(true)
  const [autoResizeMarkers, setAutoResizeMarkers] = useState(false)
  const [lastUpdate, setLastUpdate] = useState<string>("")
  const [connectionStatus, setConnectionStatus] = useState<"websocket" | "polling" | "disconnected">("disconnected")

  useEffect(() => {
    let stop = false
    let socket: any = null
    let pollInterval: NodeJS.Timeout | null = null

    // WebSocket connection with fallback to polling
    const connectWebSocket = () => {
      try {
        // Try to import socket.io-client dynamically
        import('socket.io-client').then(({ default: io }) => {
          if (stop) return
          
          const WS_URL = process.env.NEXT_PUBLIC_WS_URL ?? "ws://localhost:8000"
          socket = io(WS_URL, { 
            transports: ["websocket"],
            timeout: 5000,
            forceNew: true,
            autoConnect: true
          })

          socket.on("connect", () => {
            if (stop) return
            console.log("WebSocket connected to:", WS_URL)
            setConnectionStatus("websocket")
          })

          socket.on("vehicles_update", (payload: any) => {
            if (stop) return
            console.log("Received vehicles_update:", payload)
            setVehicles(payload.vehicles ?? [])
            setLastUpdate(payload.timestamp ?? new Date().toISOString())
            setLoading(false)
          })

          socket.on("disconnect", (reason: string) => {
            if (stop) return
            console.log("WebSocket disconnected:", reason)
            setConnectionStatus("disconnected")
          })

          socket.on("connect_error", (error: any) => {
            if (stop) return
            console.log("WebSocket connection error:", error.message)
            setConnectionStatus("disconnected")
          })

          // Handle connection timeout
          setTimeout(() => {
            if (socket && !socket.connected) {
              console.log("WebSocket connection timeout, falling back to polling")
              setConnectionStatus("disconnected")
            }
          }, 10000)
        }).catch((error) => {
          console.log("Socket.io not available, falling back to polling:", error.message)
          setConnectionStatus("disconnected")
        })
      } catch (error) {
        console.log("WebSocket setup failed, falling back to polling:", error)
        setConnectionStatus("disconnected")
      }
    }

    // Fallback polling function
    const pollVehicles = async () => {
      if (socket && socket.connected) return
      
      try {
        const data = await fetchLatestVehicles()
        if (!stop) {
          setVehicles(data.vehicles ?? [])
          setLastUpdate(data.timestamp ?? new Date().toISOString())
          setLoading(false)
          setConnectionStatus("polling")
        }
      } catch (error) {
        console.error("Failed to fetch vehicles:", error)
        if (!stop) {
          setLoading(false)
          setConnectionStatus("disconnected")
        }
      }
    }

    // Initial fetch
    pollVehicles()

    // Try WebSocket connection
    connectWebSocket()

    // Fallback polling every 5 seconds
    pollInterval = setInterval(pollVehicles, 5000)

    return () => {
      stop = true
      if (pollInterval) clearInterval(pollInterval)
      if (socket) {
        socket.close()
      }
    }
  }, [])

  if (loading) {
    return (
      <Card className="overflow-hidden">
        <div className="border-b border-border bg-card p-4">
          <div className="flex items-center justify-between">
            <div>
              <Skeleton className="h-6 w-32 mb-2" />
              <Skeleton className="h-4 w-24" />
            </div>
            <Skeleton className="h-6 w-16" />
          </div>
        </div>
        <div className="h-[600px] bg-secondary/20 flex items-center justify-center">
          <div className="text-center">
            <Skeleton className="h-8 w-48 mx-auto mb-4" />
            <Skeleton className="h-4 w-32 mx-auto" />
          </div>
        </div>
      </Card>
    )
  }

  return (
    <Card className="overflow-hidden">
      <div className="border-b border-border bg-card p-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-semibold">Live Vehicle Map</h2>
            <p className="text-sm text-muted-foreground">
              {vehicles.length} vehicles tracked
              {lastUpdate && (
                <span className="ml-2 text-xs">
                  • Last update: {new Date(lastUpdate).toLocaleTimeString()}
                </span>
              )}
            </p>
          </div>
          <div className="flex items-center gap-2">
            <MapSettings 
              autoResizeMarkers={autoResizeMarkers}
              onAutoResizeChange={setAutoResizeMarkers}
            />
            <Badge 
              variant="outline" 
              className={`gap-1.5 ${
                connectionStatus === "websocket" 
                  ? "border-green-500 text-green-500" 
                  : connectionStatus === "polling"
                  ? "border-yellow-500 text-yellow-500"
                  : "border-red-500 text-red-500"
              }`}
            >
              <div className={`h-2 w-2 rounded-full ${
                connectionStatus === "websocket" 
                  ? "bg-green-500 animate-pulse" 
                  : connectionStatus === "polling"
                  ? "bg-yellow-500 animate-pulse"
                  : "bg-red-500"
              }`} />
              {connectionStatus === "websocket" ? "WebSocket" : 
               connectionStatus === "polling" ? "Polling" : "Disconnected"}
            </Badge>
          </div>
        </div>
      </div>

      <LiveMapFull
        vehicles={vehicles}
        selectedVehicle={selectedVehicle}
        onVehicleSelect={setSelectedVehicle}
        autoResizeMarkers={autoResizeMarkers}
      />

      {/* Vehicle info panel - responsive */}
      {selectedVehicle && (
        <div className="absolute bottom-4 left-4 right-4 md:right-auto md:w-80 z-[1000]">
          <Card className="p-4 backdrop-blur-sm bg-card/95">
            <div className="flex items-start justify-between">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <Navigation className="h-4 w-4 text-chart-1 flex-shrink-0" />
                  <h3 className="font-semibold truncate">Vehicle {selectedVehicle.id.slice(0, 8)}</h3>
                </div>
                <div className="mt-3 space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Category:</span>
                    <span className="font-medium truncate ml-2">{selectedVehicle.category_name}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Location:</span>
                    <span className="font-medium truncate ml-2 text-right">{selectedVehicle.source_location}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Bearing:</span>
                    <span className="font-medium">{Math.round(selectedVehicle.bearing)}°</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Coordinates:</span>
                    <span className="font-mono text-xs">
                      {selectedVehicle.lat.toFixed(4)}, {selectedVehicle.lng.toFixed(4)}
                    </span>
                  </div>
                </div>
              </div>
              <button
                onClick={() => setSelectedVehicle(null)}
                className="text-muted-foreground hover:text-foreground flex-shrink-0 ml-2"
              >
                ×
              </button>
            </div>
          </Card>
        </div>
      )}

      {/* Vehicle list - responsive */}
      <div className="border-t border-border p-4">
        <h3 className="text-sm font-medium mb-3">Recent Vehicles</h3>
        <div className="grid gap-2 max-h-40 overflow-y-auto">
          {vehicles.slice(0, 5).map((vehicle, index) => (
            <button
              key={`${vehicle.id}-${index}`}
              onClick={() => setSelectedVehicle(vehicle)}
              className="flex items-center gap-3 rounded-lg border border-border bg-secondary/50 p-2 text-left text-sm hover:bg-secondary transition-colors"
            >
              <MapPin className="h-4 w-4 text-chart-1 flex-shrink-0" />
              <div className="flex-1 min-w-0">
                <div className="font-medium truncate">{vehicle.id.slice(0, 12)}...</div>
                <div className="text-xs text-muted-foreground truncate">{vehicle.source_location}</div>
              </div>
              <Badge variant="outline" className="text-xs hidden sm:inline-flex">
                {vehicle.category_name}
              </Badge>
            </button>
          ))}
        </div>
      </div>
    </Card>
  )
}
