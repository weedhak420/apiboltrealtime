"use client"

import { useEffect, useState, useCallback } from "react"
import OptimizedLiveMap from "./optimized-live-map"
import { Vehicle } from "@/types/vehicles"
import { useQuery } from "@tanstack/react-query"

interface OptimizedLiveMapWithDataProps {
  maxVehicles?: number
  enableClustering?: boolean
  animationDuration?: number
  refreshInterval?: number
}

export default function OptimizedLiveMapWithData({
  maxVehicles = 500,
  enableClustering = true,
  animationDuration = 800,
  refreshInterval = 5000 // 5 seconds
}: OptimizedLiveMapWithDataProps) {
  const [selectedVehicle, setSelectedVehicle] = useState<Vehicle | null>(null)
  const [performanceStats, setPerformanceStats] = useState({
    lastUpdate: new Date(),
    vehicleCount: 0,
    renderTime: 0,
    cacheHit: false
  })

  // Fetch vehicles with React Query for caching and performance
  const { data: vehicles = [], isLoading, error, isFetching } = useQuery({
    queryKey: ['vehicles', 'optimized'],
    queryFn: async () => {
      const startTime = performance.now()
      
      try {
        const response = await fetch('/api/vehicles/latest', {
          cache: 'no-store',
          headers: {
            'Cache-Control': 'no-cache',
          }
        })
        
        if (!response.ok) {
          throw new Error(`HTTP ${response.status}`)
        }
        
        const data = await response.json()
        const endTime = performance.now()
        
        setPerformanceStats(prev => ({
          ...prev,
          lastUpdate: new Date(),
          vehicleCount: data.vehicles?.length || 0,
          renderTime: endTime - startTime,
          cacheHit: data.source === 'cache' || data.source === 'Redis'
        }))
        
        return data.vehicles || []
      } catch (err) {
        console.error('Failed to fetch vehicles:', err)
        return []
      }
    },
    refetchInterval: refreshInterval,
    refetchIntervalInBackground: true,
    staleTime: 2000, // 2 seconds
    gcTime: 10000, // 10 seconds
    retry: 3,
    retryDelay: (attemptIndex) => Math.min(1000 * 2 ** attemptIndex, 30000),
  })

  // Handle vehicle selection with smooth updates
  const handleVehicleSelect = useCallback((vehicle: Vehicle | null) => {
    setSelectedVehicle(vehicle)
  }, [])

  // Performance monitoring
  useEffect(() => {
    if (vehicles.length > 0) {
      console.log(`🚀 Optimized Map Performance:`, {
        vehicles: vehicles.length,
        renderTime: performanceStats.renderTime,
        cacheHit: performanceStats.cacheHit,
        lastUpdate: performanceStats.lastUpdate.toLocaleTimeString()
      })
    }
  }, [vehicles.length, performanceStats])

  // Error handling
  if (error) {
    return (
      <div className="h-[600px] bg-secondary/20 flex items-center justify-center">
        <div className="text-center">
          <div className="text-4xl mb-4">⚠️</div>
          <h3 className="text-lg font-semibold mb-2">ข้อผิดพลาดการเชื่อมต่อ</h3>
          <p className="text-sm text-muted-foreground mb-4">
            ไม่สามารถโหลดข้อมูลรถได้ กรุณาตรวจสอบการเชื่อมต่อ
          </p>
          <button 
            onClick={() => window.location.reload()}
            className="px-4 py-2 bg-primary text-primary-foreground rounded-md text-sm hover:bg-primary/90"
          >
            ลองใหม่
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {/* Performance Stats */}
      <div className="flex items-center justify-between p-4 bg-secondary/20 rounded-lg">
        <div className="flex items-center gap-4 text-sm">
          <div className="flex items-center gap-2">
            <div className={`w-2 h-2 rounded-full ${isFetching ? 'bg-yellow-500 animate-pulse' : 'bg-green-500'}`}></div>
            <span className="font-medium">
              {isLoading ? 'กำลังโหลด...' : `${vehicles.length} คัน`}
            </span>
          </div>
          <div className="text-muted-foreground">
            อัปเดตล่าสุด: {performanceStats.lastUpdate.toLocaleTimeString()}
          </div>
          <div className="text-muted-foreground">
            Render: {Math.round(performanceStats.renderTime)}ms
          </div>
          {performanceStats.cacheHit && (
            <div className="text-green-600 font-medium">
              ⚡ แคช
            </div>
          )}
        </div>
        
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <span>การจัดกลุ่ม: {enableClustering ? 'เปิด' : 'ปิด'}</span>
          <span>•</span>
          <span>Max: {maxVehicles}</span>
          <span>•</span>
          <span>Animation: {animationDuration}ms</span>
        </div>
      </div>

      {/* Optimized Map */}
      <OptimizedLiveMap
        vehicles={vehicles}
        selectedVehicle={selectedVehicle}
        onVehicleSelect={handleVehicleSelect}
        maxVehicles={maxVehicles}
        enableClustering={enableClustering}
        animationDuration={animationDuration}
      />

      {/* Selected Vehicle Info */}
      {selectedVehicle && (
        <div className="p-4 bg-secondary/20 rounded-lg">
          <h3 className="font-semibold mb-2">รถที่เลือก</h3>
          <div className="grid grid-cols-2 gap-2 text-sm">
            <div><b>ID:</b> {selectedVehicle.id}</div>
            <div><b>หมวดหมู่:</b> {selectedVehicle.category_name || '-'}</div>
            <div><b>แหล่งที่มา:</b> {selectedVehicle.source_location || '-'}</div>
            <div><b>ทิศทาง:</b> {Math.round(selectedVehicle.bearing || 0)}°</div>
            <div><b>ตำแหน่ง:</b> {selectedVehicle.lat.toFixed(6)}, {selectedVehicle.lng.toFixed(6)}</div>
            <div><b>อัปเดต:</b> {selectedVehicle.timestamp || '-'}</div>
          </div>
        </div>
      )}
    </div>
  )
}
