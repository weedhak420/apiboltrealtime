"use client"

import { useState } from "react"
import { Settings, ZoomIn, ZoomOut } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover"

interface MapSettingsProps {
  autoResizeMarkers: boolean
  onAutoResizeChange: (enabled: boolean) => void
}

export function MapSettings({ autoResizeMarkers, onAutoResizeChange }: MapSettingsProps) {
  const [open, setOpen] = useState(false)

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          size="icon"
          className="h-9 w-9"
        >
          <Settings className="h-4 w-4" />
          <span className="sr-only">Map Settings</span>
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-80" align="end">
        <div className="space-y-4">
          <div className="space-y-2">
            <h4 className="font-medium leading-none">Map Settings</h4>
            <p className="text-sm text-muted-foreground">
              Configure marker display options
            </p>
          </div>
          
          <div className="flex items-center justify-between space-x-2">
            <div className="space-y-1">
              <Label htmlFor="auto-resize" className="text-sm font-medium">
                Auto Resize Markers
              </Label>
              <p className="text-xs text-muted-foreground">
                Automatically adjust marker size based on zoom level
              </p>
            </div>
            <Switch
              id="auto-resize"
              checked={autoResizeMarkers}
              onCheckedChange={onAutoResizeChange}
            />
          </div>
          
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <ZoomOut className="h-3 w-3" />
            <span>Small markers at low zoom</span>
            <div className="flex-1 h-px bg-border" />
            <span>Large markers at high zoom</span>
            <ZoomIn className="h-3 w-3" />
          </div>
        </div>
      </PopoverContent>
    </Popover>
  )
}
