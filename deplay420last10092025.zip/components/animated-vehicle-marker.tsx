"use client"

import { useEffect, useRef } from "react"
import { Marker, Popup, useMap } from "react-leaflet"
import L, { DivIcon, LatLngExpression, Marker as LeafletMarker } from "leaflet"
import { Vehicle } from "@/types/vehicles"

type Props = {
  vehicle: Vehicle
  size?: number // px
}

const clamp = (v: number, min: number, max: number) => Math.max(min, Math.min(max, v))

// Haversine distance calculation (meters)
function haversine(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371000 // Earth's radius in meters
  const toRad = (d: number) => d * Math.PI / 180
  const dLat = toRad(lat2 - lat1)
  const dLon = toRad(lon2 - lon1)
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) ** 2
  return 2 * R * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
}

export default function AnimatedVehicleMarker({ vehicle, size = 32 }: Props) {
  const markerRef = useRef<LeafletMarker | null>(null)
  const prevPosRef = useRef<{ lat: number; lng: number } | null>(null)
  const prevTsRef = useRef<number | null>(null)
  const animRef = useRef<number | null>(null)

  const map = useMap()

  // Prebuild a DivIcon whose inner wrapper can rotate independently
  const icon: DivIcon = new L.DivIcon({
    className: "vehicle-divicon",
    html: `
      <div class="vehicle-marker" style="width:${size}px;height:${size}px;">
        <img class="vehicle-icon" src="${vehicle.icon_url ?? "/car.svg"}" alt="v" />
      </div>
    `,
    iconSize: [size, size],
    iconAnchor: [size / 2, size / 2],
  })

  // Initialize previous state
  useEffect(() => {
    if (!prevPosRef.current) {
      prevPosRef.current = { lat: vehicle.lat, lng: vehicle.lng }
    }
    if (!prevTsRef.current) {
      const t = vehicle.timestamp ? Date.parse(vehicle.timestamp) : Date.now()
      prevTsRef.current = isNaN(t) ? Date.now() : t
    }
    // Set initial bearing var
    const el = markerRef.current?.getElement() as HTMLElement | undefined
    if (el) {
      const wrap = el.querySelector(".vehicle-marker") as HTMLElement | null
      if (wrap) wrap.style.setProperty("--bearing", `${vehicle.bearing ?? 0}deg`)
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  useEffect(() => {
    const marker = markerRef.current
    if (!marker) return

    // Cancel previous animation frame
    if (animRef.current) {
      cancelAnimationFrame(animRef.current)
      animRef.current = null
    }

    const prev = prevPosRef.current ?? { lat: vehicle.lat, lng: vehicle.lng }
    const prevTs = prevTsRef.current ?? Date.now()
    const next = { lat: vehicle.lat, lng: vehicle.lng }
    const nextTs = vehicle.timestamp ? Date.parse(vehicle.timestamp) : Date.now()

    const nowTs = isNaN(nextTs) ? Date.now() : nextTs
    const dtMsRaw = Math.max(0, nowTs - prevTs)
    // Dynamic duration: 80% of dt, clamped between 250–1500ms
    const duration = clamp(Math.floor(dtMsRaw * 0.8), 250, 1500)

    // Jump guard: if too far for the interval, snap instead of animate
    const dist = haversine(prev.lat, prev.lng, next.lat, next.lng) // meters
    const maxReasonable = Math.max(30, (dtMsRaw / 1000) * 40) // ~40 m/s cap
    const animate = dist <= maxReasonable

    // Update bearing CSS var
    const el = marker.getElement() as HTMLElement | undefined
    if (el) {
      const wrap = el.querySelector(".vehicle-marker") as HTMLElement | null
      if (wrap) {
        wrap.style.setProperty("--bearing", `${vehicle.bearing ?? 0}deg`)
        if (animate) {
          wrap.classList.add("rotating")
        } else {
          wrap.classList.add("jumping")
        }
      }
    }

    if (!animate) {
      marker.setLatLng([next.lat, next.lng] as LatLngExpression)
      prevPosRef.current = next
      prevTsRef.current = nowTs
      return
    }

    // EMA smoothing target (small)
    const alpha = 0.25
    const target = {
      lat: prev.lat + (next.lat - prev.lat) * (1 - Math.pow(1 - alpha, 2)),
      lng: prev.lng + (next.lng - prev.lng) * (1 - Math.pow(1 - alpha, 2)),
    }

    const start = performance.now()
    const startLat = prev.lat
    const startLng = prev.lng

    const easeOutCubic = (t: number) => 1 - Math.pow(1 - t, 3)

    const step = (ts: number) => {
      const p = clamp((ts - start) / duration, 0, 1)
      const e = easeOutCubic(p)
      const lat = startLat + (target.lat - startLat) * e
      const lng = startLng + (target.lng - startLng) * e
      marker.setLatLng([lat, lng] as LatLngExpression)
      if (p < 1) {
        animRef.current = requestAnimationFrame(step)
      } else {
        prevPosRef.current = next
        prevTsRef.current = nowTs
        animRef.current = null
        // Remove animation classes
        const el = marker.getElement() as HTMLElement | undefined
        if (el) {
          const wrap = el.querySelector(".vehicle-marker") as HTMLElement | null
          if (wrap) {
            wrap.classList.remove("rotating", "jumping")
          }
        }
      }
    }
    animRef.current = requestAnimationFrame(step)

    return () => {
      if (animRef.current) cancelAnimationFrame(animRef.current)
      animRef.current = null
    }
  }, [vehicle.lat, vehicle.lng, vehicle.bearing, vehicle.timestamp])

  return (
    <Marker
      ref={markerRef}
      position={[vehicle.lat, vehicle.lng]}
      icon={icon}
      zIndexOffset={1000}
    >
      <Popup>
        <div className="space-y-1">
          <div><b>ID:</b> {vehicle.id}</div>
          <div><b>Cat:</b> {vehicle.category_name ?? "-"}</div>
          <div><b>Src:</b> {vehicle.source_location ?? "-"}</div>
          <div><b>Time:</b> {vehicle.timestamp ?? "-"}</div>
          <div><b>Bearing:</b> {Math.round(vehicle.bearing ?? 0)}°</div>
        </div>
      </Popup>
    </Marker>
  )
}
