"use client"

import { useEffect, useState } from "react"
import dynamic from "next/dynamic"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { MapPin, Clock, Navigation } from "lucide-react"
import { useTheme } from "next-themes"
import "leaflet/dist/leaflet.css"

// useMap hook - import directly since it's a hook
import { useMap } from 'react-leaflet'

// Dynamic import to avoid SSR issues
const MapContainer = dynamic(() => import('react-leaflet').then(mod => mod.MapContainer), { ssr: false })
const TileLayer = dynamic(() => import('react-leaflet').then(mod => mod.TileLayer), { ssr: false })
const Polyline = dynamic(() => import('react-leaflet').then(mod => mod.Polyline), { ssr: false })
const Marker = dynamic(() => import('react-leaflet').then(mod => mod.Marker), { ssr: false })
const Popup = dynamic(() => import('react-leaflet').then(mod => mod.Popup), { ssr: false })

// Fix for default markers in React-Leaflet - only run on client side
if (typeof window !== 'undefined') {
  import('leaflet').then(L => {
    delete (L.Icon.Default.prototype as any)._getIconUrl
    L.Icon.Default.mergeOptions({
      iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
      iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
      shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
    })
  })
}

// Custom hook to handle map bounds
function MapBoundsUpdater({ records }: { records: any[] }) {
  const map = useMap()

  useEffect(() => {
    if (records.length === 0) return

    const bounds = L.latLngBounds(
      records.map(record => [record.lat, record.lng] as [number, number])
    )
    
    map.fitBounds(bounds, { padding: [20, 20] })
  }, [map, records])

  return null
}

// Custom hook to handle tile layer switching
function TileLayerUpdater({ isDark }: { isDark: boolean }) {
  const map = useMap()
  const [currentLayer, setCurrentLayer] = useState<string | null>(null)

  useEffect(() => {
    // Remove existing tile layer
    if (currentLayer) {
      map.eachLayer((layer) => {
        if (layer instanceof L.TileLayer) {
          map.removeLayer(layer)
        }
      })
    }

    // Add new tile layer based on theme
    const tileLayer = L.tileLayer(
      isDark 
        ? 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png'
        : 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
      {
        attribution: isDark 
          ? '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>'
          : '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
        subdomains: isDark ? 'abcd' : 'abc',
        maxZoom: 20,
      }
    )

    tileLayer.addTo(map)
    setCurrentLayer(isDark ? 'dark' : 'light')
  }, [isDark, map])

  return null
}

export default function HistoryMap({ history, analytics }: { history: any; analytics: any }) {
  const [mounted, setMounted] = useState(false)
  const { theme, resolvedTheme } = useTheme()
  
  const isDark = resolvedTheme === 'dark'
  // Support both records and data formats from API
  const records = history?.records ?? history?.data ?? []
  const hotspots = analytics?.hotspots ?? []
  const vehicles = analytics?.vehicles ?? []
  
  console.log("HistoryMap - history:", history)
  console.log("HistoryMap - records:", records)
  console.log("HistoryMap - records length:", records.length)
  console.log("HistoryMap - analytics:", analytics)
  console.log("HistoryMap - analytics summary:", analytics?.summary)
  console.log("HistoryMap - analytics record_count:", analytics?.summary?.record_count)

  useEffect(() => {
    // Add a small delay to ensure smooth loading
    const timer = setTimeout(() => {
      setMounted(true)
    }, 100)
    
    return () => clearTimeout(timer)
  }, [])

  if (!mounted) {
    return (
      <div className="h-[60vh] bg-gradient-to-br from-secondary/20 to-secondary/40 flex items-center justify-center rounded-xl overflow-hidden">
        <div className="text-center">
          <div className="relative">
            <div className="animate-spin rounded-full h-12 w-12 border-4 border-primary/20 border-t-primary mx-auto mb-4"></div>
            <div className="absolute inset-0 animate-pulse rounded-full h-12 w-12 border-4 border-primary/10 mx-auto"></div>
          </div>
          <p className="text-sm text-muted-foreground animate-pulse">Loading map...</p>
          <div className="mt-2 text-xs text-muted-foreground/60">
            Optimizing for smooth performance
          </div>
        </div>
      </div>
    )
  }

  // Check if we have data from either history or analytics
  const hasData = records.length > 0 || (analytics && analytics.summary && analytics.summary.record_count > 0)
  
  if (!hasData) {
    return (
      <div className="h-[60vh] bg-secondary/20 flex items-center justify-center">
        <div className="text-center">
          <div className="text-4xl mb-4">🗺️</div>
          <h3 className="text-lg font-semibold mb-2">No Route Data</h3>
          <p className="text-sm text-muted-foreground">
            No vehicle history found for the selected criteria.
          </p>
        </div>
      </div>
    )
  }

  // Convert records to polyline points
  const routePoints = records.length > 0 ? records.map(r => [r.lat, r.lng] as [number, number]) : []
  const center = routePoints[0] ?? [18.7883, 98.9853] // Chiang Mai center

  // Create route polyline with different colors for different vehicles
  const routeColors = ['#3b82f6', '#ef4444', '#10b981', '#f59e0b', '#8b5cf6']
  const vehicleRoutes = new Map()
  
  if (records.length > 0) {
    records.forEach(record => {
      if (!vehicleRoutes.has(record.vehicle_id)) {
        vehicleRoutes.set(record.vehicle_id, [])
      }
      vehicleRoutes.get(record.vehicle_id).push([record.lat, record.lng])
    })
  }

  return (
    <div className="h-[60vh] rounded-xl overflow-hidden relative">
      <MapContainer 
        center={center} 
        zoom={13} 
        style={{ height: "100%", width: "100%" }}
        className="z-0 transition-all duration-300 ease-in-out"
        preferCanvas={true}
        zoomAnimation={true}
        fadeAnimation={true}
        markerZoomAnimation={true}
        zoomSnap={0.5}
        zoomDelta={0.5}
        wheelPxPerZoomLevel={120}
        maxZoom={18}
        minZoom={8}
        zoomControl={true}
        scrollWheelZoom={true}
        doubleClickZoom={true}
        dragging={true}
        touchZoom={true}
        attributionControl={false}
        zoomControl={true}
        style={{ 
          height: "100%", 
          width: "100%",
          transition: "all 0.3s ease-in-out"
        }}
      >
        <TileLayerUpdater isDark={isDark} />
        <MapBoundsUpdater records={records} />
        
        {/* Route polylines for each vehicle */}
        {Array.from(vehicleRoutes.entries()).map(([vehicleId, points], index) => (
          <Polyline
            key={`${vehicleId}-${index}`}
            positions={points}
            color={routeColors[index % routeColors.length]}
            weight={3}
            opacity={0.8}
            smoothFactor={1.2}
            className="transition-all duration-300 ease-in-out"
            pathOptions={{
              smoothFactor: 1.2,
              noClip: false,
              interactive: true
            }}
          />
        ))}

        {/* Start marker */}
        {records.length > 0 && (
          <Marker 
            position={[records[0].lat, records[0].lng]}
            className="animate-pulse"
          >
            <Popup>
              <div className="p-2">
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
                  <span className="font-semibold">Start Point</span>
                </div>
                <div className="text-sm space-y-1">
                  <div><b>Vehicle:</b> {records[0].vehicle_id}</div>
                  <div><b>Time:</b> {new Date(records[0].timestamp).toLocaleString()}</div>
                  <div><b>Bearing:</b> {records[0].bearing}°</div>
                </div>
              </div>
            </Popup>
          </Marker>
        )}

        {/* End marker */}
        {records.length > 1 && (
          <Marker position={[records[records.length - 1].lat, records[records.length - 1].lng]}>
            <Popup>
              <div className="p-2">
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                  <span className="font-semibold">End Point</span>
                </div>
                <div className="text-sm space-y-1">
                  <div><b>Vehicle:</b> {records[records.length - 1].vehicle_id}</div>
                  <div><b>Time:</b> {new Date(records[records.length - 1].timestamp).toLocaleString()}</div>
                  <div><b>Bearing:</b> {records[records.length - 1].bearing}°</div>
                </div>
              </div>
            </Popup>
          </Marker>
        )}

        {/* Hotspots */}
        {hotspots && hotspots.length > 0 && hotspots.slice(0, 20).map((hotspot: any, index: number) => (
          <Marker 
            key={`hotspot-${index}`} 
            position={[hotspot.grid_lat, hotspot.grid_lng]}
            className="transition-all duration-300 ease-in-out hover:scale-110"
          >
            <Popup>
              <div className="p-2">
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-3 h-3 bg-orange-500 rounded-full animate-pulse"></div>
                  <span className="font-semibold">Hotspot</span>
                </div>
                <div className="text-sm space-y-1">
                  <div><b>Vehicles:</b> {hotspot.vehicles}</div>
                  <div><b>Location:</b> {hotspot.grid_lat.toFixed(4)}, {hotspot.grid_lng.toFixed(4)}</div>
                </div>
              </div>
            </Popup>
          </Marker>
        ))}
      </MapContainer>

      {/* Map Legend */}
      <div className="absolute bottom-4 left-4 z-[1000]">
        <Card className="p-3 bg-card/95 backdrop-blur-sm">
          <div className="space-y-2 text-sm">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-green-500 rounded-full"></div>
              <span>Start Point</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-red-500 rounded-full"></div>
              <span>End Point</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-orange-500 rounded-full"></div>
              <span>Hotspots</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-1 bg-blue-500"></div>
              <span>Route</span>
            </div>
          </div>
        </Card>
      </div>

      {/* Route Stats */}
      {analytics && (
        <div className="absolute top-4 right-4 z-[1000]">
          <Card className="p-3 bg-card/95 backdrop-blur-sm">
            <div className="space-y-2 text-sm">
              <div className="flex items-center gap-2">
                <Navigation className="h-4 w-4" />
                <span className="font-semibold">Route Stats</span>
              </div>
              <div><b>Distance:</b> {analytics.summary?.total_distance_km?.toFixed(1) || 0} km</div>
              <div><b>Duration:</b> {analytics.summary?.record_count || 0} points</div>
              <div><b>Avg Speed:</b> {analytics.summary?.avg_speed_kmh?.toFixed(1) || 0} km/h</div>
              <div><b>Stops:</b> {analytics.summary?.stop_count || 0}</div>
            </div>
          </Card>
        </div>
      )}
    </div>
  )
}
