"use client"

import { useEffect, useRef } from "react"

interface VehicleMarkerIconProps {
  iconUrl: string
  size?: number
  bearing?: number
  onError?: () => void
}

export function VehicleMarkerIcon({ 
  iconUrl, 
  size = 40, 
  bearing = 0, 
  onError 
}: VehicleMarkerIconProps) {
  const imgRef = useRef<HTMLImageElement>(null)

  useEffect(() => {
    const img = imgRef.current
    if (img) {
      img.onerror = () => {
        // Create fallback placeholder icon
        const canvas = document.createElement('canvas')
        canvas.width = size
        canvas.height = size
        const ctx = canvas.getContext('2d')
        
        if (ctx) {
          // Draw a simple vehicle icon as fallback
          ctx.fillStyle = '#3b82f6'
          ctx.fillRect(0, 0, size, size)
          ctx.fillStyle = 'white'
          ctx.font = `${size * 0.3}px Arial`
          ctx.textAlign = 'center'
          ctx.textBaseline = 'middle'
          ctx.fillText('🚗', size / 2, size / 2)
          
          img.src = canvas.toDataURL()
        }
        
        onError?.()
      }
    }
  }, [iconUrl, size, onError])

  return (
    <img
      ref={imgRef}
      src={iconUrl}
      alt="Vehicle"
      className="vehicle-marker-icon"
      style={{
        width: `${size}px`,
        height: `${size}px`,
        transform: `rotate(${bearing}deg)`,
        transition: 'transform 0.5s ease',
        objectFit: 'contain',
        imageRendering: 'crisp-edges',
      }}
    />
  )
}
