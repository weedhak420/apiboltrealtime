"use client"

import { useEffect, useState, useCallback, useRef } from "react"
import { Card } from "@/components/ui/card"
import { BarChart3, TrendingUp, MapPin, AlertCircle } from "lucide-react"

interface Hotspot {
  grid_lat: number
  grid_lng: number
  vehicles: number
}

interface TrendPoint {
  time: string
  vehicles: number
}

export default function OptimizedAnalyticsCharts() {
  const [hotspots, setHotspots] = useState<Hotspot[]>([])
  const [trends, setTrends] = useState<TrendPoint[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [lastFetch, setLastFetch] = useState<Date | null>(null)
  
  // Use ref to track if component is mounted
  const isMountedRef = useRef(true)
  
  // Debounced fetch function
  const fetchAnalytics = useCallback(async () => {
    if (!isMountedRef.current) return
    
    try {
      setError(null)
      const startTime = Date.now()
      
      const [heatmapRes, trendRes] = await Promise.all([
        fetch("/api/analytics/heatmap?limit=10", {
          cache: "no-store",
          signal: AbortSignal.timeout(15000) // 15 second timeout
        }),
        fetch("/api/analytics/trend?interval=hour", {
          cache: "no-store", 
          signal: AbortSignal.timeout(15) // 15 second timeout
        }),
      ])

      if (!heatmapRes.ok || !trendRes.ok) {
        throw new Error(`HTTP ${heatmapRes.status} / ${trendRes.status}`)
      }

      const heatmapData = await heatmapRes.json()
      const trendData = await trendRes.json()

      if (!isMountedRef.current) return

      setHotspots(heatmapData.hotspots || [])
      setTrends(trendData.trends || [])
      setLastFetch(new Date())
      setLoading(false)
      
      console.log(`[OptimizedAnalyticsCharts] Fetched in ${Date.now() - startTime}ms`)
    } catch (error) {
      if (!isMountedRef.current) return
      
      console.error("[OptimizedAnalyticsCharts] Failed to fetch analytics:", error)
      setError(error instanceof Error ? error.message : 'Unknown error')
      setLoading(false)
      // Don't clear existing data on error
    }
  }, [])

  useEffect(() => {
    isMountedRef.current = true
    
    // Initial fetch
    fetchAnalytics()
    
    // Set up interval with longer delay to reduce API calls
    const interval = setInterval(fetchAnalytics, 120000) // 2 minutes instead of 30 seconds
    
    return () => {
      isMountedRef.current = false
      clearInterval(interval)
    }
  }, [fetchAnalytics])

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      isMountedRef.current = false
    }
  }, [])

  return (
    <div className="grid gap-6 lg:grid-cols-2">
      {/* Error Display */}
      {error && (
        <div className="lg:col-span-2">
          <Card className="p-4 border-red-200 bg-red-50">
            <div className="flex items-center gap-2 text-red-800">
              <AlertCircle className="h-4 w-4" />
              <span className="font-medium">Error loading analytics data</span>
            </div>
            <p className="text-red-600 text-sm mt-1">{error}</p>
          </Card>
        </div>
      )}

      {/* Heatmap Hotspots */}
      <Card className="p-6">
        <div className="flex items-center gap-2 mb-6">
          <MapPin className="h-5 w-5 text-chart-2" />
          <h2 className="text-lg font-semibold">จุดร้อนยอดนิยม</h2>
          {lastFetch && (
            <span className="text-xs text-muted-foreground ml-auto">
              อัปเดต: {lastFetch.toLocaleTimeString()}
            </span>
          )}
        </div>

        <div className="space-y-4">
          {loading && hotspots.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              กำลังโหลดข้อมูล...
            </div>
          ) : hotspots.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              ไม่มีข้อมูลจุดร้อน
            </div>
          ) : (
            hotspots.slice(0, 8).map((hotspot, index) => {
              const maxVehicles = Math.max(...hotspots.map((h) => h.vehicles))
              const percentage = maxVehicles > 0 ? (hotspot.vehicles / maxVehicles) * 100 : 0

              return (
                <div key={index} className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">
                      {hotspot.grid_lat.toFixed(4)}, {hotspot.grid_lng.toFixed(4)}
                    </span>
                    <span className="font-semibold">{hotspot.vehicles} คัน</span>
                  </div>
                  <div className="h-2 rounded-full bg-secondary overflow-hidden">
                    <div className="h-full bg-chart-2 transition-all duration-500" style={{ width: `${percentage}%` }} />
                  </div>
                </div>
              )
            })
          )}
        </div>
      </Card>

      {/* Trend Chart */}
      <Card className="p-6">
        <div className="flex items-center gap-2 mb-6">
          <TrendingUp className="h-5 w-5 text-chart-1" />
          <h2 className="text-lg font-semibold">แนวโน้มรถ</h2>
          {lastFetch && (
            <span className="text-xs text-muted-foreground ml-auto">
              อัปเดต: {lastFetch.toLocaleTimeString()}
            </span>
          )}
        </div>

        <div className="space-y-4">
          {loading && trends.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              กำลังโหลดข้อมูล...
            </div>
          ) : trends.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              ไม่มีข้อมูลแนวโน้ม
            </div>
          ) : (
            trends.slice(0, 8).map((point, index) => {
              const maxVehicles = Math.max(...trends.map((t) => t.vehicles))
              const percentage = maxVehicles > 0 ? (point.vehicles / maxVehicles) * 100 : 0

              return (
                <div key={index} className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">
                      {new Date(point.time).toLocaleTimeString("th-TH", {
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </span>
                    <span className="font-semibold">{point.vehicles} คัน</span>
                  </div>
                  <div className="h-2 rounded-full bg-secondary overflow-hidden">
                    <div className="h-full bg-chart-1 transition-all duration-500" style={{ width: `${percentage}%` }} />
                  </div>
                </div>
              )
            })
          )}
        </div>
      </Card>

      {/* Summary Stats */}
      <Card className="p-6 lg:col-span-2">
        <div className="flex items-center gap-2 mb-6">
          <BarChart3 className="h-5 w-5 text-chart-3" />
          <h2 className="text-lg font-semibold">สถิติสรุป</h2>
          {lastFetch && (
            <span className="text-xs text-muted-foreground ml-auto">
              อัปเดต: {lastFetch.toLocaleTimeString()}
            </span>
          )}
        </div>

        <div className="grid gap-6 md:grid-cols-3">
          <div className="space-y-2">
            <p className="text-sm text-muted-foreground">จุดร้อนทั้งหมด</p>
            <p className="text-3xl font-bold">{hotspots.length}</p>
          </div>
          <div className="space-y-2">
            <p className="text-sm text-muted-foreground">รถสูงสุด</p>
            <p className="text-3xl font-bold">
              {trends.length > 0 ? Math.max(...trends.map((t) => t.vehicles)) : 0}
            </p>
          </div>
          <div className="space-y-2">
            <p className="text-sm text-muted-foreground">รถเฉลี่ย</p>
            <p className="text-3xl font-bold">
              {trends.length > 0 ? Math.round(trends.reduce((sum, t) => sum + t.vehicles, 0) / trends.length) : 0}
            </p>
          </div>
        </div>
      </Card>
    </div>
  )
}