export type Vehicle = {
  id: string
  lat: number
  lng: number
  bearing?: number
  icon_url?: string
  category_name?: string
  source_location?: string
  timestamp?: string
  speed?: number
}

export type VehicleHistoryRecord = {
  history_id: number
  vehicle_id: string
  lat: number
  lng: number
  bearing: number
  category_name: string
  timestamp: string
  created_at: string
}

export type AnalyticsSummary = {
  start: string
  end: string
  record_count: number
  vehicle_count: number
  total_distance_km: number
  avg_speed_kmh: number
  stop_count: number
}

export type BearingHistogram = {
  N: number
  NE: number
  E: number
  SE: number
  S: number
  SW: number
  W: number
  NW: number
}

export type Hotspot = {
  grid_lat: number
  grid_lng: number
  vehicles: number
}

export type VehicleAnalytics = {
  vehicle_id: string
  points: number
  distance_km: number
  avg_speed_kmh: number
  stops: number
}

export type AnalyticsHistory = {
  summary: AnalyticsSummary
  bearing_histogram: BearingHistogram
  hotspots: Hotspot[]
  vehicles: VehicleAnalytics[]
  timestamp: string
}

export type TrendData = {
  time: string
  vehicles: number
  smoothed: number
}

export type TrendResponse = {
  trends: TrendData[]
  count: number
  interval: string
  smoothing: string
  timestamp: string
}

export type HeatmapResponse = {
  hotspots: Hotspot[]
  count: number
  limit: number
  timestamp: string
}

export type VehicleHistoryResponse = {
  records?: VehicleHistoryRecord[]
  data?: VehicleHistoryRecord[]  // Alternative format from API
  count: number
  limit?: number
  vehicle_id?: string
  timestamp?: string
  status?: string
}

export type LatestVehiclesResponse = {
  vehicles: Vehicle[]
  count: number
  timestamp: string
  source: string
}
