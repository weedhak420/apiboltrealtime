# เอกสาร API Bolt Taxi Tracker (ภาษาไทย)

## ภาพรวม

ระบบ Bolt Taxi Tracker เป็นบริการ Go backend ที่ให้การติดตามและวิเคราะห์ข้อมูลรถแท็กซี่ Bolt แบบเรียลไทม์ในจังหวัดเชียงใหม่ ประเทศไทย ระบบมีคุณสมบัติการจัดการ JWT token ที่ทันสมัยพร้อมการรีเฟรชอัตโนมัติ เพื่อให้การเข้าถึง API ของ Bolt เป็นไปอย่างราบรื่น

### คุณสมบัติหลัก
- **การติดตามรถแบบเรียลไทม์** พร้อม WebSocket support
- **การรีเฟรช JWT token อัตโนมัติ** จาก Bolt API
- **การวิเคราะห์ที่ครอบคลุม** พร้อม heatmap, trends และข้อมูลประวัติ
- **การตรวจสอบประสิทธิภาพ** พร้อม circuit breakers และ rate limiting
- **การแคชฐานข้อมูล** พร้อม MySQL และ Redis support

## ระบบจัดการ JWT Token

### ภาพรวม
JWTManager จัดการวงจรชีวิตของ JWT tokens ที่ใช้สำหรับการยืนยันตัวตนกับ Bolt API โดยจะรีเฟรช token อัตโนมัติก่อนหมดอายุ เพื่อให้บริการไม่ขาดตอน

### กระบวนการรีเฟรช Token
ระบบจะรีเฟรช JWT tokens อัตโนมัติโดยเรียก Bolt API:

**Endpoint:** `POST https://node.bolt.eu/user-auth/profile/auth/getAccessToken`

**Headers:**
```
Authorization: Bearer <current_token>
User-Agent: okhttp/4.12.0
```

**Query Parameters:**
| Parameter | Value | คำอธิบาย |
|-----------|-------|-------------|
| `version` | `CA.180.0` | เวอร์ชัน API |
| `deviceId` | `1363e778-8d4a-4fd3-9ebf-d35aea4fb533` | ตัวระบุอุปกรณ์ |
| `device_name` | `samsungSM-X910N` | ชื่ออุปกรณ์ |
| `device_os_version` | `9` | เวอร์ชัน Android |
| `channel` | `googleplay` | ช่องทางการจำหน่าย |
| `brand` | `bolt` | แบรนด์แอป |
| `deviceType` | `android` | ประเภทอุปกรณ์ |
| `signup_session_id` | `` | Session ID |
| `country` | `th` | รหัสประเทศ |
| `is_local_authentication_available` | `false` | แฟล็กการยืนยันตัวตนท้องถิ่น |
| `language` | `th` | รหัสภาษา |
| `gps_lat` | `13.727949` | ละติจูด GPS |
| `gps_lng` | `100.446442` | ลองจิจูด GPS |
| `gps_accuracy_m` | `0.02` | ความแม่นยำ GPS |
| `gps_age` | `1` | อายุ GPS |
| `user_id` | `284215753` | User ID |
| `session_id` | `284215753u1759766688900` | Session ID |
| `distinct_id` | `client-284215753` | Distinct ID |
| `rh_session_id` | `284215753u1759767820` | RH Session ID |

### กระบวนการต่ออายุอัตโนมัติ
1. **กระบวนการพื้นหลัง**: `StartAutoRenewal()` ทำงานทุก 5 นาที
2. **การตรวจสอบการหมดอายุ**: หาก token หมดอายุใน <10 นาที จะเริ่มรีเฟรช
3. **การเรียก API**: เรียก Bolt API เพื่อรับ token ใหม่พร้อม rate limiting และ retry logic
4. **การอัปเดต Token**: เก็บ token ใหม่พร้อมเวลาหมดอายุ/ออกให้
5. **การสำรอง**: หากการรีเฟรชล้มเหลว จะใช้ token ที่มีอยู่ (อาจทำให้เกิด 401 retry)

### การจัดการข้อผิดพลาดและ Rate Limiting ที่ปรับปรุงแล้ว

#### Rate Limiting
- **คำขอพร้อมกัน**: สูงสุด 5 คำขอ API พร้อมกัน
- **อัตราการขอ**: จำกัดที่ 5 คำขอต่อวินาที
- **การจัดการคิว**: คิว FIFO สำหรับคำขอที่เกินขีดจำกัด
- **การจำกัดอัตโนมัติ**: ป้องกันการใช้ API มากเกินไปและลดข้อผิดพลาด 1005

#### การจัดการรหัสข้อผิดพลาด
- **ข้อผิดพลาด 1005 (TOO_MANY_REQUESTS)**: ลองใหม่อัตโนมัติพร้อม exponential backoff (500ms → 1s → 2s)
- **ข้อผิดพลาด 210 (REFRESH_TOKEN_INVALID)**: เริ่มการสร้าง token ใหม่พร้อม fallback
- **HTTP 429**: จัดการด้วย retry logic และ backoff
- **ข้อผิดพลาดเครือข่าย**: ลองใหม่อัตโนมัติพร้อม exponential backoff
- **การลองใหม่สูงสุด**: 3 ครั้งต่อคำขอพร้อมการหน่วงเวลาที่เพิ่มขึ้น

#### Retry Logic
```go
// Exponential backoff สำหรับการลองใหม่
backoff := []time.Duration{500 * time.Millisecond, 1 * time.Second, 2 * time.Second}

// Rate limiting middleware
jm.rateLimiter.Acquire()
defer jm.rateLimiter.Release()
```

### รูปแบบการตอบสนอง API
```json
{
  "code": 0,
  "message": "OK",
  "data": {
    "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "expires_timestamp": 1759774202,
    "expires_in_seconds": 3600,
    "next_update_in_seconds": 3540,
    "next_update_give_up_timestamp": 1759774182
  }
}
```

## API Endpoints

### การยืนยันตัวตนและสถานะ

#### `GET /api/jwt/status`
ส่งคืนข้อมูล JWT token ปัจจุบันและสถานะพร้อมรายละเอียดการจัดการข้อผิดพลาด

**การตอบสนอง:**
```json
{
  "status": "active",
  "token_info": {
    "expires_at": "2025-01-01T12:00:00Z",
    "issued_at": "2025-01-01T11:00:00Z",
    "user_id": 284215753,
    "login_id": 605369720,
    "is_valid": true,
    "time_until_expiry": "45m30s"
  }
}
```

**การตอบสนองข้อผิดพลาด:**
```json
{
  "status": "no_token",
  "message": "No JWT token available"
}
```

#### `GET /api/status`
ส่งคืนสถานะ API ทั่วไปและการกำหนดค่า

**การตอบสนอง:**
```json
{
  "status": "running",
  "timestamp": "2025-01-01T12:00:00Z",
  "interval": "5s",
  "workers": 3
}
```

### การจัดการ External Token

#### `POST /api/external-token/update`
อัปเดต external token ที่ใช้สำหรับการเรียก API

**Request Body:**
```json
{
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user_id": 283617495,
  "login_id": 605354782
}
```

**Response:**
```json
{
  "success": true,
  "message": "External token updated successfully",
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}
```

#### `GET /api/external-token/status`
ส่งคืนสถานะ external token ปัจจุบันและข้อมูล

**Response:**
```json
{
  "external_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "is_expired": false,
  "expiry_time": "2024-01-15T10:30:00Z",
  "current_token": {
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "expires_at": "2024-01-15T10:30:00Z",
    "issued_at": "2024-01-15T09:30:00Z",
    "user_id": 283617495,
    "login_id": 605354782
  }
}
```

#### `POST /api/external-token/force-renewal`
บังคับการต่ออายุ token ทันที

**Response:**
```json
{
  "success": true,
  "message": "Token renewal forced successfully"
}
```

#### `GET /api/external-token/get`
ส่งคืน JWT token ที่ถูกต้อง โดยต่ออายุหากจำเป็น

**Response:**
```json
{
  "success": true,
  "message": "Token retrieved successfully",
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}
```

### ข้อมูลรถ

#### `GET /api/vehicles/latest`
ส่งคืนข้อมูลรถที่แคชล่าสุดพร้อม fallback logic

**การตอบสนอง:**
```json
{
  "vehicles": [
    {
      "id": "4289043010",
      "lat": 18.7883,
      "lng": 98.9853,
      "bearing": 45.5,
      "icon_url": "https://images.bolt.eu/store/...",
      "category_name": "Bolt_Taxi",
      "category_id": "taxi",
      "source_location": "city_center",
      "timestamp": "2025-01-01T12:00:00Z",
      "distance": 150.5
    }
  ],
  "count": 1,
  "timestamp": "2025-01-01T12:00:00Z",
  "source": "Redis"
}
```

#### `GET /api/vehicles`
นามแฝงสำหรับ `/api/vehicles/latest`

#### `GET /api/vehicles/history`
ส่งคืนบันทึกประวัติรถพร้อมตัวกรองทางเลือก

**Query Parameters:**
| Parameter | Type | Default | คำอธิบาย |
|-----------|------|---------|-------------|
| `limit` | int | 100 | จำนวนสูงสุดของบันทึกที่จะส่งคืน (สูงสุด 1000) |
| `vehicle_id` | string | - | กรองตาม ID รถเฉพาะ |

**การตอบสนอง:**
```json
{
  "records": [
    {
      "history_id": 12345,
      "vehicle_id": "4289043010",
      "lat": 18.7883,
      "lng": 98.9853,
      "bearing": 45,
      "category_name": "Bolt_Taxi",
      "timestamp": "2025-01-01 12:00:00",
      "created_at": "2025-01-01 12:00:05"
    }
  ],
  "count": 1,
  "limit": 100,
  "vehicle_id": "",
  "timestamp": "2025-01-01T12:00:00Z"
}
```

### การวิเคราะห์

#### `GET /api/analytics/heatmap`
ส่งคืนข้อมูล heatmap แสดงจุดร้อนของการรวมตัวของรถ

**Query Parameters:**
| Parameter | Type | Default | คำอธิบาย |
|-----------|------|---------|-------------|
| `limit` | int | 50 | จำนวนจุดร้อนสูงสุดที่จะส่งคืน (สูงสุด 500) |

**การตอบสนอง:**
```json
{
  "hotspots": [
    {
      "grid_lat": 18.790,
      "grid_lng": 98.985,
      "vehicles": 42
    }
  ],
  "count": 1,
  "limit": 50,
  "timestamp": "2025-01-01T12:00:00Z"
}
```

#### `GET /api/analytics/trend`
ส่งคืนข้อมูลเทรนด์แสดงกิจกรรมรถตามเวลา

**Query Parameters:**
| Parameter | Type | Default | คำอธิบาย |
|-----------|------|---------|-------------|
| `interval` | string | hour | ช่วงเวลา: `hour` หรือ `day` |

**การตอบสนอง:**
```json
{
  "trends": [
    {
      "time": "2025-01-01 12:00:00",
      "vehicles": 25,
      "smoothed": 24.5
    }
  ],
  "count": 1,
  "interval": "hour",
  "smoothing": "ema_0.3",
  "timestamp": "2025-01-01T12:00:00Z"
}
```

#### `GET /api/analytics/history`
ส่งคืนการวิเคราะห์ที่ครอบคลุมจากข้อมูลประวัติรถ

**Query Parameters:**
| Parameter | Type | Default | คำอธิบาย |
|-----------|------|---------|-------------|
| `start` | string | 24h ago | เวลาเริ่มต้น (RFC3339) |
| `end` | string | now | เวลาสิ้นสุด (RFC3339) |
| `vehicle_id` | string | - | กรองตาม ID รถ |
| `bbox` | string | - | Bounding box "minLat,minLng,maxLat,maxLng" |
| `limit` | int | 1000 | บันทึกสูงสุด (สูงสุด 5000) |
| `offset` | int | 0 | Pagination offset |
| `grid` | float | 0.001 | ขนาดกริดสำหรับจุดร้อน |
| `stop_min_sec` | int | 120 | เวลาหยุดขั้นต่ำสำหรับการหยุด |
| `stop_max_move_m` | float | 10.0 | การเคลื่อนไหวสูงสุดสำหรับการหยุด |

**การตอบสนอง:**
```json
{
  "summary": {
    "start": "2025-01-01T00:00:00Z",
    "end": "2025-01-01T23:59:59Z",
    "record_count": 1234,
    "vehicle_count": 106,
    "total_distance_km": 87.52,
    "avg_speed_kmh": 26.4,
    "stop_count": 312
  },
  "bearing_histogram": {
    "N": 120, "NE": 98, "E": 140, "SE": 90,
    "S": 110, "SW": 80, "W": 100, "NW": 75
  },
  "hotspots": [
    {
      "grid_lat": 18.790,
      "grid_lng": 98.985,
      "vehicles": 42
    }
  ],
  "vehicles": [
    {
      "vehicle_id": "4289043010",
      "points": 124,
      "distance_km": 6.31,
      "avg_speed_kmh": 19.2,
      "stops": 5
    }
  ],
  "timestamp": "2025-01-01T12:00:00Z"
}
```

### Fast Analytics Endpoints

#### `GET /api/analytics/heatmap/fast`
ส่งคืนข้อมูล heatmap ที่เร็วขึ้นด้วยการแคชที่ก้าวร้าว

**Query Parameters:**
| Parameter | Type | Default | คำอธิบาย |
|-----------|------|---------|-------------|
| `limit` | int | 50 | จำนวนจุดร้อนสูงสุดที่จะส่งคืน |

**การตอบสนอง:**
```json
{
  "hotspots": [
    {
      "grid_lat": 18.790,
      "grid_lng": 98.985,
      "vehicles": 42
    }
  ],
  "count": 1,
  "limit": 50,
  "timestamp": "2025-01-01T12:00:00Z",
  "cache_status": "HIT",
  "response_time_ms": 45
}
```

#### `GET /api/analytics/trend/fast`
ส่งคืนข้อมูลเทรนด์ที่เร็วขึ้นด้วยการแคชที่ก้าวร้าว

**Query Parameters:**
| Parameter | Type | Default | คำอธิบาย |
|-----------|------|---------|-------------|
| `interval` | string | hour | ช่วงเวลา: `hour` หรือ `day` |

**การตอบสนอง:**
```json
{
  "trends": [
    {
      "time": "2025-01-01 12:00:00",
      "vehicles": 25,
      "smoothed": 24.5
    }
  ],
  "count": 1,
  "interval": "hour",
  "smoothing": "ema_0.3",
  "timestamp": "2025-01-01T12:00:00Z",
  "cache_status": "HIT",
  "response_time_ms": 32
}
```

### การตรวจสอบระบบ

#### `GET /api/health`
ส่งคืนสถานะการตรวจสอบสุขภาพ

**การตอบสนอง:**
```json
{
  "status": "healthy",
  "database": "connected",
  "redis": "connected",
  "api": "operational",
  "timestamp": "2025-01-01T12:00:00Z"
}
```

#### `GET /api/performance`
ส่งคืนสถิติประสิทธิภาพ

**การตอบสนอง:**
```json
{
  "goroutine_count": 15,
  "cache_size": 25,
  "rate_limit_size": 0,
  "enhanced_rate_limiter": {
    "requests_per_minute": 60,
    "current_requests": 5
  },
  "worker_pool": {
    "active_workers": 3,
    "queued_tasks": 0
  },
  "timestamp": "2025-01-01T12:00:00Z"
}
```

#### `GET /api/analytics`
ส่งคืนข้อมูลการวิเคราะห์พื้นฐาน

**การตอบสนอง:**
```json
{
  "total_vehicles": 25,
  "locations": 7,
  "timestamp": "2025-01-01T12:00:00Z"
}
```

### Cache Management

#### `GET /api/cache/status`
ส่งคืนสถานะการแคชและสถิติ

**การตอบสนอง:**
```json
{
  "redis_status": "connected",
  "cache_hits": 1250,
  "cache_misses": 45,
  "hit_rate": 96.5,
  "memory_usage": "45.2MB",
  "keys_count": 125,
  "timestamp": "2025-01-01T12:00:00Z"
}
```

### Health Check Endpoints

#### `GET /healthz`
การตรวจสอบสุขภาพพื้นฐาน

**การตอบสนอง:**
```json
{
  "status": "healthy",
  "timestamp": "2025-01-01T12:00:00Z"
}
```

#### `GET /readyz`
การตรวจสอบความพร้อม

**การตอบสนอง:**
```json
{
  "status": "ready",
  "database": "connected",
  "redis": "connected",
  "timestamp": "2025-01-01T12:00:00Z"
}
```

#### `GET /livez`
การตรวจสอบการมีชีวิต

**การตอบสนอง:**
```json
{
  "status": "alive",
  "uptime": "2h30m15s",
  "timestamp": "2025-01-01T12:00:00Z"
}
```

#### `GET /metrics`
เมตริก Prometheus

**การตอบสนอง:**
```
# HELP http_requests_total Total number of HTTP requests
# TYPE http_requests_total counter
http_requests_total{method="GET",endpoint="/api/vehicles/latest"} 1250

# HELP http_request_duration_seconds HTTP request duration in seconds
# TYPE http_request_duration_seconds histogram
http_request_duration_seconds_bucket{le="0.1"} 1200
http_request_duration_seconds_bucket{le="0.5"} 1250
```

## การจัดการข้อผิดพลาด

### การจัดการข้อผิดพลาด JWT Token ที่ปรับปรุงแล้ว

#### ข้อผิดพลาด 1005 (TOO_MANY_REQUESTS)
- **การลองใหม่อัตโนมัติ**: ระบบลองใหม่พร้อม exponential backoff (500ms → 1s → 2s)
- **Rate Limiting**: ป้องกันข้อผิดพลาด 1005 ในอนาคตโดยจำกัดคำขอพร้อมกัน
- **ความพยายามสูงสุด**: 3 ครั้งก่อนยอมแพ้
- **การบันทึก**: บันทึกรายละเอียดสำหรับการตรวจสอบและแก้ไขข้อบกพร่อง

#### ข้อผิดพลาด 210 (REFRESH_TOKEN_INVALID)
- **การสร้าง Token ใหม่**: เริ่มการสร้าง refresh token ใหม่อัตโนมัติ
- **Token สำรอง**: ใช้ token สำรองหากการสร้างใหม่ล้มเหลว
- **การกู้คืนที่ราบรื่น**: ระบบดำเนินการต่อด้วย token ใหม่
- **การบันทึก**: บ่งชี้ที่ชัดเจนของกระบวนการสร้าง token ใหม่

#### HTTP 429 (Too Many Requests)
- **การลองใหม่อัตโนมัติ**: จัดการด้วย retry logic เดียวกับข้อผิดพลาด 1005
- **Rate Limiting**: ป้องกันข้อผิดพลาด 429 ในอนาคตผ่านการจำกัดคำขอ
- **กลยุทธ์ Backoff**: Exponential backoff พร้อมความพยายามสูงสุด 3 ครั้ง

#### ข้อผิดพลาดเครือข่าย
- **Connection Timeouts**: ลองใหม่อัตโนมัติพร้อม backoff
- **DNS Resolution**: ลองใหม่พร้อม exponential backoff
- **Request Failures**: การจัดการข้อผิดพลาดและการบันทึกที่ครอบคลุม

### ข้อผิดพลาด JWT Token (แบบเดิม)
- **401 Unauthorized**: Token หมดอายุหรือไม่ถูกต้อง
  - ระบบพยายามรีเฟรชอัตโนมัติพร้อม retry logic
  - ใช้ token ที่แคชหากการรีเฟรชล้มเหลว
- **Token Refresh Failure**: ข้อผิดพลาดเครือข่ายหรือ API
  - Retry logic ที่ปรับปรุงแล้วพร้อม exponential backoff
  - การบันทึกข้อผิดพลาดและการตรวจสอบที่ครอบคลุม

### การตอบสนองข้อผิดพลาด API
endpoint ทั้งหมดส่งคืนรูปแบบข้อผิดพลาดที่สอดคล้องกัน:
```json
{
  "error": "คำอธิบายข้อผิดพลาด",
  "code": 500
}
```

### HTTP Status Codes ทั่วไป
- `200`: สำเร็จ
- `400`: Bad Request (พารามิเตอร์ไม่ถูกต้อง)
- `401`: Unauthorized (ปัญหา JWT token)
- `500`: Internal Server Error

## WebSocket Support

### การอัปเดตแบบเรียลไทม์
ระบบให้ WebSocket endpoints สำหรับการอัปเดตรถแบบเรียลไทม์:

**การเชื่อมต่อ:** `ws://localhost:8000/socket.io/`

**Events:**
- `vehicles_update`: ส่งข้อมูลรถล่าสุด
- `connect`: การเชื่อมต่อไคลเอนต์สำเร็จ
- `disconnect`: ไคลเอนต์ตัดการเชื่อมต่อ

**รูปแบบข้อมูล WebSocket:**
```json
{
  "vehicles": [...],
  "count": 25,
  "timestamp": "2025-01-01T12:00:00Z",
  "fetch_time": 1735732800,
  "api_status": "success"
}
```

## การกำหนดค่า

### Environment Variables
- `DB_HOST`: โฮสต์ฐานข้อมูล (default: localhost)
- `DB_PORT`: พอร์ตฐานข้อมูล (default: 3306)
- `DB_USER`: ชื่อผู้ใช้ฐานข้อมูล (default: root)
- `DB_PASSWORD`: รหัสผ่านฐานข้อมูล
- `DB_NAME`: ชื่อฐานข้อมูล (default: bolt_tracker)
- `REDIS_HOST`: โฮสต์ Redis (default: localhost)
- `REDIS_PORT`: พอร์ต Redis (default: 6379)
- `REDIS_PASSWORD`: รหัสผ่าน Redis
- `GIN_MODE`: โหมด Gin (development/release)

### การกำหนดค่าเซิร์ฟเวอร์
- **Port**: 8000
- **Workers**: 3 concurrent API workers
- **Fetch Interval**: 5 วินาที
- **Rate Limiting**: 60 คำขอ/นาที ต่อตำแหน่ง
- **Cache TTL**: 5 นาทีสำหรับข้อมูลรถ

### การกำหนดค่าฐานข้อมูล
```json
{
  "database": {
    "host": "localhost",
    "port": "3306",
    "user": "root",
    "password": "",
    "name": "bolt_tracker",
    "max_connections": 25,
    "max_idle_connections": 5,
    "connection_lifetime": "5m",
    "retry_attempts": 3,
    "retry_delay": "1s"
  }
}
```

### การกำหนดค่า Redis
```json
{
  "redis": {
    "host": "localhost",
    "port": "6379",
    "password": "",
    "db": 0,
    "pool_size": 10,
    "min_idle_connections": 5,
    "dial_timeout": "5s",
    "read_timeout": "3s",
    "write_timeout": "3s",
    "max_retries": 3,
    "retry_backoff": "1s",
    "namespace": "bolt_tracker",
    "circuit_breaker": true
  }
}
```

## การพัฒนาและการทดสอบ

### การรันเซิร์ฟเวอร์

#### Enhanced Version (แนะนำ)
```bash
cd backend
go run main_enhanced.go
```

#### Legacy Version
```bash
cd backend
go run run.go
```

### การทดสอบ API

#### การทดสอบสถานะ JWT
```bash
curl http://localhost:8000/api/jwt/status
```

#### การทดสอบข้อมูลรถ
```bash
curl http://localhost:8000/api/vehicles/latest
```

#### การทดสอบ External Token
```bash
# ตรวจสอบสถานะ
curl http://localhost:8000/api/external-token/status

# อัปเดต token
curl -X POST http://localhost:8000/api/external-token/update \
  -H "Content-Type: application/json" \
  -d '{"token": "your_token_here", "user_id": 123, "login_id": 456}'

# บังคับต่ออายุ
curl -X POST http://localhost:8000/api/external-token/force-renewal

# รับ token
curl http://localhost:8000/api/external-token/get
```

#### การทดสอบ Analytics
```bash
# Heatmap
curl "http://localhost:8000/api/analytics/heatmap?limit=100"

# Fast Heatmap
curl "http://localhost:8000/api/analytics/heatmap/fast?limit=50"

# Trend
curl "http://localhost:8000/api/analytics/trend?interval=hour"

# Fast Trend
curl "http://localhost:8000/api/analytics/trend/fast?interval=hour"

# History
curl "http://localhost:8000/api/analytics/history?start=2025-01-01T00:00:00Z&end=2025-01-01T23:59:59Z"
```

#### การทดสอบ Health Check
```bash
# Basic health
curl http://localhost:8000/api/health

# Kubernetes health checks
curl http://localhost:8000/healthz
curl http://localhost:8000/readyz
curl http://localhost:8000/livez

# Performance stats
curl http://localhost:8000/api/performance

# Cache status
curl http://localhost:8000/api/cache/status

# Prometheus metrics
curl http://localhost:8000/metrics
```

### การตรวจสอบและการรีเฟรชอัตโนมัติที่ปรับปรุงแล้ว
ดู server logs สำหรับกิจกรรมการรีเฟรช JWT พร้อมการจัดการข้อผิดพลาดที่ปรับปรุงแล้ว:
```
🔄 JWT Auto-renewal started (checking every 5 minutes)
⏰ JWT token still valid for 45m (no renewal needed)
🔄 Auto-renewing JWT token...
✅ Successfully refreshed JWT token (expires: 2025-01-01T12:00:00Z)
```

#### การตรวจสอบข้อผิดพลาดที่ปรับปรุงแล้ว
```
⚠️ TOO_MANY_REQUESTS (code 1005) → retry with backoff (attempt 1)
⚠️ HTTP 429 TOO_MANY_REQUESTS → retry with backoff (attempt 2)
⚠️ REFRESH_TOKEN_INVALID (code 210) → regenerate token
🔄 Regenerating refresh token due to error 210...
✅ Using regenerated fallback JWT token (expires: 2025-01-01T12:00:00Z)
```

#### การตรวจสอบ Rate Limiting
```
🔒 Rate limiter acquired (current: 3/5 concurrent requests)
🔒 Rate limiter released (current: 2/5 concurrent requests)
⏱️ Request throttled: 200ms delay applied
```

## การพิจารณาด้านความปลอดภัย

- JWT tokens จะรีเฟรชอัตโนมัติเพื่อป้องกันการหมดอายุ
- Rate limiting ป้องกันการละเมิด API
- Circuit breakers ป้องกันความล้มเหลวของ API
- การเชื่อมต่อฐานข้อมูลใช้ connection pooling
- Redis caching ลดโหลด API
- ข้อมูลที่ละเอียดอ่อนทั้งหมดจะถูกบันทึกด้วยระดับที่เหมาะสม

## คุณสมบัติประสิทธิภาพ

### Rate Limiting และ Throttling ที่ปรับปรุงแล้ว
- **การจำกัดคำขอพร้อมกัน**: สูงสุด 5 คำขอ API พร้อมกัน
- **การจำกัดอัตราการขอ**: จำกัดที่ 5 คำขอต่อวินาที
- **การจัดการคิว**: คิว FIFO สำหรับคำขอที่เกินขีดจำกัด
- **การ Backoff อัตโนมัติ**: ป้องกันการใช้ API มากเกินไปและลดอัตราข้อผิดพลาด
- **Token Bucket Algorithm**: การใช้งาน rate limiting ที่มีประสิทธิภาพ

### การจัดการ JWT Token
- **การต่ออายุอัตโนมัติ**: การรีเฟรช token พื้นหลังทุก 5 นาที
- **การกู้คืนข้อผิดพลาด**: Retry logic ที่ครอบคลุมสำหรับข้อผิดพลาดทุกประเภท
- **Token สำรอง**: กลยุทธ์สำรองหลายแบบสำหรับความล้มเหลวของ token
- **คำขอที่จำกัดอัตรา**: การเรียก API ทั้งหมดเคารพขีดจำกัดอัตรา
- **Exponential Backoff**: กลยุทธ์การลองใหม่ที่ชาญฉลาดสำหรับคำขอที่ล้มเหลว

### ประสิทธิภาพระบบ
- **Connection Pooling**: การเชื่อมต่อฐานข้อมูลที่ปรับปรุงแล้ว
- **Memory Pools**: object pools ที่ใช้ซ้ำได้เพื่อประสิทธิภาพที่ดีขึ้น
- **Circuit Breakers**: การตรวจจับความล้มเหลวและการกู้คืนอัตโนมัติ
- **Caching**: การแคชหลายชั้น (Redis + Database + Memory)
- **Background Processing**: การดำเนินการที่ไม่บล็อก
- **Graceful Shutdown**: การยุติบริการที่สะอาด

### การตรวจสอบและการบันทึก
- **การบันทึกข้อผิดพลาดที่ละเอียด**: บันทึกที่ครอบคลุมสำหรับข้อผิดพลาดทุกประเภท
- **เมตริกประสิทธิภาพ**: เวลาการขอและอัตราความสำเร็จ
- **การตรวจสอบ Rate Limit**: ติดตามการใช้ API และการจำกัด
- **การติดตามสถานะ Token**: ตรวจสอบวงจรชีวิต JWT token
- **การบันทึกความพยายามลองใหม่**: ติดตามความพยายามลองใหม่และผลลัพธ์

## การติดตั้งและการรัน

### ข้อกำหนดระบบ
- Go 1.19 หรือใหม่กว่า
- MySQL 5.7 หรือใหม่กว่า
- Redis 6.0 หรือใหม่กว่า

### การติดตั้ง
```bash
# Clone repository
git clone <repository-url>
cd boltapilastver004

# Install dependencies
go mod download

# Setup database
mysql -u root -p < bolt_tracker.sql

# Setup Redis
redis-server

# Run application (Enhanced Version)
cd backend
go run main_enhanced.go

# หรือ Run Legacy Version
go run run.go
```

### การกำหนดค่าสภาพแวดล้อม
```bash
export DB_HOST=localhost
export DB_PORT=3306
export DB_USER=root
export DB_PASSWORD=your_password
export DB_NAME=bolt_tracker
export REDIS_HOST=localhost
export REDIS_PORT=6379
export REDIS_PASSWORD=your_redis_password
export GIN_MODE=release
```

## การแก้ไขปัญหาทั่วไป

### ข้อผิดพลาด 1005 (TOO_MANY_REQUESTS)
- ระบบจะลองใหม่อัตโนมัติพร้อม exponential backoff
- ตรวจสอบ rate limiting settings
- ตรวจสอบ logs สำหรับการจัดการข้อผิดพลาด

### ข้อผิดพลาด 401 (Unauthorized)
- ตรวจสอบสถานะ JWT token
- ระบบจะพยายามรีเฟรช token อัตโนมัติ
- ตรวจสอบการกำหนดค่า authentication

### ข้อผิดพลาด 429 (Too Many Requests)
- ระบบจะจัดการด้วย retry logic
- ตรวจสอบ rate limiting configuration
- ตรวจสอบ concurrent request limits

### ปัญหาการเชื่อมต่อฐานข้อมูล
- ตรวจสอบการกำหนดค่าฐานข้อมูล
- ตรวจสอบ connection pool settings
- ตรวจสอบ network connectivity

### ปัญหา Redis
- ตรวจสอบการเชื่อมต่อ Redis
- ตรวจสอบการกำหนดค่า Redis
- ตรวจสอบ memory usage

## สรุป

ระบบ Bolt Taxi Tracker API ให้การติดตามและวิเคราะห์รถแท็กซี่ Bolt แบบเรียลไทม์ในจังหวัดเชียงใหม่ พร้อมระบบจัดการ JWT token ที่ทันสมัย การวิเคราะห์ที่ครอบคลุม และการตรวจสอบประสิทธิภาพที่ปรับปรุงแล้ว ระบบได้รับการออกแบบให้มีความน่าเชื่อถือสูง มีประสิทธิภาพ และง่ายต่อการใช้งาน

### Endpoints ที่มีทั้งหมด:
- **JWT Management**: `/api/jwt/status`
- **External Token Management**: `/api/external-token/*`
- **Vehicle Data**: `/api/vehicles/*`
- **Analytics**: `/api/analytics/*`
- **Fast Analytics**: `/api/analytics/*/fast`
- **Health Checks**: `/healthz`, `/readyz`, `/livez`
- **System Monitoring**: `/api/health`, `/api/performance`, `/api/cache/status`
- **Metrics**: `/metrics`
