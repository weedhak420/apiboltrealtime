# การแก้ไขปัญหาการเชื่อมต่อฐานข้อมูล

## 🚨 **ปัญหาที่พบ**

### **สาเหตุหลัก:**
Go application ใช้ **hardcoded database configuration** แทนที่จะใช้ค่าจาก `config.json`

### **ปัญหาที่เกิดขึ้น:**
1. **Hardcoded values** ใน `database.go`:
   ```go
   const (
       DBHost     = "localhost"  // ← ใช้ localhost
       DBPort     = "3306"
       DBUser     = "root"
       DBPassword = ""          // ← ไม่มีรหัสผ่าน
       DBName     = "bolt_tracker"
   )
   ```

2. **Config.json มีข้อมูลถูกต้อง**:
   ```json
   {
     "database": {
       "host": "57.158.24.174",     // ← เซิร์ฟเวอร์จริง
       "port": "3306",
       "user": "root",
       "password": "0830159499@Tnp", // ← รหัสผ่านจริง
       "name": "bolt_tracker"
     }
   }
   ```

## ✅ **การแก้ไขที่ทำ**

### 1. **แก้ไข `database.go`**
- เปลี่ยนจาก `const` เป็น `var` เพื่อให้สามารถแก้ไขค่าได้
- เพิ่มฟังก์ชัน `loadDatabaseConfig()` เพื่อโหลดค่าจาก `config.json`
- เพิ่มการเรียกใช้ `loadDatabaseConfig()` ใน `initDatabase()`

### 2. **สร้างสคริปต์ทดสอบ**
- `test_database_connection.py` - ทดสอบด้วย Python
- `test_db_connection.go` - ทดสอบด้วย Go

## 🧪 **การทดสอบ**

### **ทดสอบด้วย Python:**
```bash
cd backend
python test_database_connection.py
```

### **ทดสอบด้วย Go:**
```bash
cd backend
go run test_db_connection.go
```

### **ทดสอบ Application:**
```bash
cd backend
go run main_enhanced.go
```

## 📋 **การเปลี่ยนแปลงในโค้ด**

### **ไฟล์ที่แก้ไข: `backend/database.go`**

#### **ก่อนแก้ไข:**
```go
// Database configuration
const (
    DBHost     = "localhost"
    DBPort     = "3306"
    DBUser     = "root"
    DBPassword = ""
    DBName     = "bolt_tracker"
)
```

#### **หลังแก้ไข:**
```go
// Database configuration - will be loaded from config.json
var (
    DBHost     = "localhost"
    DBPort     = "3306"
    DBUser     = "root"
    DBPassword = ""
    DBName     = "bolt_tracker"
)

// Config structure for loading from config.json
type Config struct {
    Database struct {
        Host     string `json:"host"`
        Port     string `json:"port"`
        User     string `json:"user"`
        Password string `json:"password"`
        Name     string `json:"name"`
    } `json:"database"`
}

// loadDatabaseConfig loads database configuration from config.json
func loadDatabaseConfig() error {
    configData, err := ioutil.ReadFile("config.json")
    if err != nil {
        log.Printf("⚠️ Warning: Could not read config.json, using default values: %v", err)
        return nil // Use default values
    }

    var config Config
    if err := json.Unmarshal(configData, &config); err != nil {
        log.Printf("⚠️ Warning: Could not parse config.json, using default values: %v", err)
        return nil // Use default values
    }

    // Update database configuration from config.json
    DBHost = config.Database.Host
    DBPort = config.Database.Port
    DBUser = config.Database.User
    DBPassword = config.Database.Password
    DBName = config.Database.Name

    log.Printf("📋 Database config loaded from config.json:")
    log.Printf("   Host: %s", DBHost)
    log.Printf("   Port: %s", DBPort)
    log.Printf("   User: %s", DBUser)
    log.Printf("   Database: %s", DBName)

    return nil
}
```

#### **การเรียกใช้ใน `initDatabase()`:**
```go
// Initialize database
func initDatabase() error {
    var err error

    // Load database configuration from config.json
    if err := loadDatabaseConfig(); err != nil {
        log.Printf("⚠️ Warning: Could not load database config: %v", err)
    }

    // Build DSN dynamically using configuration constants
    dsn := fmt.Sprintf("%s:%s@tcp(%s:%s)/%s?charset=utf8mb4&parseTime=True&loc=Local",
        DBUser, DBPassword, DBHost, DBPort, DBName)
    
    // ... rest of the function
}
```

## 🔍 **การตรวจสอบ**

### **1. ตรวจสอบ Logs**
เมื่อรัน application จะเห็น logs แบบนี้:
```
📋 Database config loaded from config.json:
   Host: 57.158.24.174
   Port: 3306
   User: root
   Database: bolt_tracker
🔗 Connecting to MySQL: root@57.158.24.174:3306/bolt_tracker
✅ Successfully connected to MySQL database
```

### **2. ตรวจสอบการเชื่อมต่อ**
```bash
# ทดสอบด้วย Python
python test_database_connection.py

# ทดสอบด้วย Go
go run test_db_connection.go

# ทดสอบ Application
go run main_enhanced.go
```

## 🚀 **การรัน Application**

### **Enhanced Version (แนะนำ):**
```bash
cd backend
go run main_enhanced.go
```

### **Legacy Version:**
```bash
cd backend
go run run.go
```

## 📊 **ผลลัพธ์ที่คาดหวัง**

### **ก่อนแก้ไข:**
```
❌ Failed to ping MySQL server: dial tcp 127.0.0.1:3306: connect: connection refused
💡 Make sure MySQL is running and credentials are correct
```

### **หลังแก้ไข:**
```
📋 Database config loaded from config.json:
   Host: 57.158.24.174
   Port: 3306
   User: root
   Database: bolt_tracker
🔗 Connecting to MySQL: root@57.158.24.174:3306/bolt_tracker
✅ Successfully connected to MySQL database
✅ Database 'bolt_tracker' created/verified
```

## 🔧 **การแก้ไขเพิ่มเติม (หากจำเป็น)**

### **หากยังมีปัญหา:**

1. **ตรวจสอบ Firewall:**
   ```bash
   # ตรวจสอบว่า port 3306 เปิดอยู่
   telnet 57.158.24.174 3306
   ```

2. **ตรวจสอบ MySQL User Permissions:**
   ```sql
   -- ตรวจสอบ user permissions
   SELECT User, Host FROM mysql.user WHERE User = 'root';
   
   -- ตรวจสอบ database access
   SHOW GRANTS FOR 'root'@'%';
   ```

3. **ตรวจสอบ MySQL Configuration:**
   ```sql
   -- ตรวจสอบ bind-address
   SHOW VARIABLES LIKE 'bind_address';
   
   -- ตรวจสอบ port
   SHOW VARIABLES LIKE 'port';
   ```

## 📝 **สรุป**

การแก้ไขนี้จะทำให้ Go application ใช้ค่าการกำหนดค่าจาก `config.json` แทนที่จะใช้ hardcoded values ทำให้สามารถเชื่อมต่อกับเซิร์ฟเวอร์ฐานข้อมูลจริงได้

### **ไฟล์ที่แก้ไข:**
- ✅ `backend/database.go` - แก้ไขการโหลด config
- ✅ `backend/test_database_connection.py` - สคริปต์ทดสอบ Python
- ✅ `backend/test_db_connection.go` - สคริปต์ทดสอบ Go
- ✅ `backend/DATABASE_CONNECTION_FIX.md` - เอกสารการแก้ไข

ตอนนี้ application ควรจะเชื่อมต่อกับฐานข้อมูลได้แล้วครับ! 🎉
