# ฟีเจอร์ Auto-Restart เมื่อ Token หมดอายุ

## 🎯 **วัตถุประสงค์**

เพิ่มฟีเจอร์ให้โปรแกรมปิดตัวและรันใหม่เมื่อ JWT token หมดอายุ เพื่อให้สามารถรีเฟรช token ใหม่ได้

## 🚨 **ปัญหาที่พบ**

จาก log ที่ได้รับ:
```
2025/10/09 03:09:05 ⚠️ Failed to refresh token from API: failed to decode response body: failed to create gzip reader: context canceled
2025/10/09 03:09:05 🔍 JWT Token Analysis:
2025/10/09 03:09:05    User ID: 284589006
2025/10/09 03:09:05    Login ID: 606331081
2025/10/09 03:09:05    Issued At: 2025-10-08T03:49:41+07:00
2025/10/09 03:09:05    Expires At: 2025-10-08T04:49:41+07:00
2025/10/09 03:09:05    Current Time: 2025-10-09T03:09:05+07:00
2025/10/09 03:09:05    Status: ❌ Expired
```

## ✅ **การแก้ไขที่ทำ**

### **1. เพิ่มฟังก์ชัน `restartApplication()`**

```go
// restartApplication restarts the application when token regeneration fails
func (jm *JWTManager) restartApplication() {
    log.Println("🔄 Restarting application due to token regeneration failure...")
    
    // Get current executable path
    execPath, err := os.Executable()
    if err != nil {
        log.Printf("❌ Failed to get executable path: %v", err)
        return
    }
    
    // Get current working directory
    workDir, err := os.Getwd()
    if err != nil {
        log.Printf("❌ Failed to get working directory: %v", err)
        return
    }
    
    log.Printf("📁 Executable: %s", execPath)
    log.Printf("📁 Working Directory: %s", workDir)
    
    // Prepare restart command
    var cmd *exec.Cmd
    if runtime.GOOS == "windows" {
        // Windows: use cmd.exe to restart
        cmd = exec.Command("cmd", "/c", "start", "cmd", "/c", "cd", "/d", workDir, "&&", execPath)
    } else {
        // Unix-like: use shell to restart
        cmd = exec.Command("sh", "-c", fmt.Sprintf("cd %s && %s", workDir, execPath))
    }
    
    // Set working directory
    cmd.Dir = workDir
    
    // Start the new process
    if err := cmd.Start(); err != nil {
        log.Printf("❌ Failed to restart application: %v", err)
        return
    }
    
    log.Println("✅ Application restart initiated successfully")
    log.Println("🔄 Current process will exit in 3 seconds...")
    
    // Give some time for the new process to start
    time.Sleep(3 * time.Second)
    
    // Exit current process
    log.Println("👋 Exiting current process...")
    os.Exit(0)
}
```

### **2. แก้ไข `forceTokenRegeneration()`**

```go
// forceTokenRegeneration forces complete token regeneration when expired
func (jm *JWTManager) forceTokenRegeneration() {
    log.Println("🔄 Forcing complete token regeneration due to expiration...")

    // Clear current token
    jm.mutex.Lock()
    jm.currentToken = nil
    jm.mutex.Unlock()

    // Request external token regeneration
    jm.requestExternalTokenRegeneration()

    // Generate new token
    if _, err := jm.generateNewToken(); err != nil {
        log.Printf("⚠️ Failed to generate new token after expiration: %v", err)
        log.Println("🔄 Token regeneration failed - restarting application...")
        jm.restartApplication()
    } else {
        log.Println("✅ Successfully regenerated token after expiration")
    }
}
```

### **3. แก้ไข `renewToken()`**

```go
// renewToken renews the current token
func (jm *JWTManager) renewToken() error {
    jm.mutex.Lock()
    defer jm.mutex.Unlock()

    // Try to refresh token from API
    _, err := jm.refreshToken()
    if err != nil {
        log.Printf("⚠️ Failed to renew JWT token: %v", err)
        // Keep the old token if refresh fails
        return err
    }

    log.Printf("🔄 JWT token renewed successfully")
    return nil
}
```

### **4. แก้ไข Auto-renewal Loop**

```go
if isExpired {
    log.Println("⚠️ JWT token has expired - forcing immediate renewal...")
    go jm.forceTokenRegeneration()
} else if needsRenewal {
    log.Println("🔄 Auto-renewing JWT token...")
    if err := jm.renewToken(); err != nil {
        log.Printf("⚠️ Failed to renew token: %v", err)
        log.Println("🔄 Token renewal failed - restarting application...")
        go jm.restartApplication()
    }
} else {
    // ... existing code ...
}
```

### **5. แก้ไข `refreshToken()`**

```go
// Check status code
if resp.StatusCode != 200 {
    log.Printf("⚠️ API returned status %d (attempt %d): %s", resp.StatusCode, i+1, string(body))
    
    // Handle 401 Unauthorized - token expired
    if resp.StatusCode == 401 {
        log.Println("⚠️ HTTP 401 Unauthorized - token expired, restarting application...")
        go jm.restartApplication()
        return "", fmt.Errorf("token expired - application restarting")
    }
    
    if i < len(backoff)-1 {
        time.Sleep(backoff[i])
        continue
    }
    return "", fmt.Errorf("API returned status %d: %s", resp.StatusCode, string(body))
}
```

### **6. แก้ไข `generateNewToken()`**

```go
// Try to refresh token from API
newToken, err := jm.refreshToken()
if err != nil {
    log.Printf("⚠️ Failed to refresh token from API: %v", err)
    
    // Check if error is due to token expiration
    if strings.Contains(err.Error(), "token expired") || strings.Contains(err.Error(), "application restarting") {
        log.Println("🔄 Token expired - application restarting...")
        return "", err
    }
    
    // ... existing fallback code ...
}
```

## 🔧 **การทำงาน**

### **1. Token Expiration Detection**
- ตรวจสอบ token expiration ใน auto-renewal loop ทุก 5 นาที
- ตรวจสอบ HTTP 401 response จาก API
- ตรวจสอบ error messages ที่เกี่ยวข้องกับ token expiration

### **2. Restart Process**
- เมื่อตรวจพบ token expiration หรือ regeneration failure
- เริ่มต้น process ใหม่ด้วย executable เดิม
- รอ 3 วินาทีให้ process ใหม่เริ่มต้น
- ปิด process เดิม

### **3. Cross-Platform Support**
- **Windows**: ใช้ `cmd.exe` เพื่อ restart
- **Unix-like**: ใช้ `sh` เพื่อ restart

## 📊 **ผลลัพธ์ที่คาดหวัง**

### **เมื่อ Token หมดอายุ:**
```
⚠️ JWT token has expired - forcing immediate renewal...
🔄 Forcing complete token regeneration due to expiration...
⚠️ Failed to generate new token after expiration: [error details]
🔄 Token regeneration failed - restarting application...
🔄 Restarting application due to token regeneration failure...
📁 Executable: /path/to/bolt-tracker-optimized-420
📁 Working Directory: /path/to/backend
✅ Application restart initiated successfully
🔄 Current process will exit in 3 seconds...
👋 Exiting current process...
```

### **เมื่อ HTTP 401 เกิดขึ้น:**
```
⚠️ HTTP 401 Unauthorized - token expired, restarting application...
🔄 Restarting application due to token regeneration failure...
📁 Executable: /path/to/bolt-tracker-optimized-420
📁 Working Directory: /path/to/backend
✅ Application restart initiated successfully
🔄 Current process will exit in 3 seconds...
👋 Exiting current process...
```

## 🚀 **การใช้งาน**

### **รัน Application:**
```bash
cd backend
go run main_enhanced.go
```

### **Build Binary:**
```bash
cd backend
go build -o bolt-tracker-optimized-420 .
./bolt-tracker-optimized-420
```

## 📝 **สรุป**

การเพิ่มฟีเจอร์นี้จะทำให้:
- ✅ ตรวจสอบ token expiration อัตโนมัติ
- ✅ รีสตาร์ท application เมื่อ token หมดอายุ
- ✅ รองรับ cross-platform (Windows/Unix)
- ✅ มี logging ที่ชัดเจน
- ✅ รอให้ process ใหม่เริ่มต้นก่อนปิด process เดิม

ตอนนี้ application จะสามารถจัดการกับ token expiration ได้อย่างอัตโนมัติแล้วครับ! 🎉

## 🔍 **การตรวจสอบ**

### **1. ตรวจสอบ Logs:**
- ดู logs เพื่อตรวจสอบการทำงานของ auto-restart
- ตรวจสอบว่า process ใหม่เริ่มต้นได้หรือไม่

### **2. ตรวจสอบ Process:**
```bash
# Windows
tasklist | findstr bolt-tracker

# Unix-like
ps aux | grep bolt-tracker
```

### **3. ตรวจสอบ API Endpoints:**
```bash
curl http://localhost:8000/api/jwt/status
curl http://localhost:8000/api/external-token/status
```

ตอนนี้ application พร้อมใช้งานแล้วครับ! 🚀
