package main

import (
	"encoding/json"
	"fmt"
	"log"
	"net/http"
)

// ExternalTokenAPI handles external token management endpoints
type ExternalTokenAPI struct {
	jwtManager *JWTManager
}

// NewExternalTokenAPI creates a new external token API handler
func NewExternalTokenAPI(jwtManager *JWTManager) *ExternalTokenAPI {
	return &ExternalTokenAPI{
		jwtManager: jwtManager,
	}
}

// UpdateTokenHandler handles POST /api/external-token/update
func (eta *ExternalTokenAPI) UpdateTokenHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	var req ExternalTokenRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		log.Printf("⚠️ Failed to decode external token request: %v", err)
		http.Error(w, "Invalid JSON", http.StatusBadRequest)
		return
	}

	if req.Token == "" {
		http.Error(w, "Token is required", http.StatusBadRequest)
		return
	}

	// Handle external token update
	if err := eta.jwtManager.HandleExternalTokenUpdate(req.Token, req.UserID, req.LoginID); err != nil {
		log.Printf("⚠️ Failed to handle external token update: %v", err)
		http.Error(w, fmt.Sprintf("Failed to update token: %v", err), http.StatusInternalServerError)
		return
	}

	response := ExternalTokenResponse{
		Success: true,
		Message: "External token updated successfully",
		Token:   req.Token,
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(response)

	log.Printf("✅ External token updated successfully for user %d, login %d", req.UserID, req.LoginID)
}

// GetTokenStatusHandler handles GET /api/external-token/status
func (eta *ExternalTokenAPI) GetTokenStatusHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	// Get current token info
	tokenInfo := eta.jwtManager.GetTokenInfo()
	externalToken := eta.jwtManager.GetExternalToken()
	isExpired := eta.jwtManager.IsTokenExpired()
	expiryTime := eta.jwtManager.GetTokenExpiryTime()

	status := map[string]interface{}{
		"external_token": externalToken,
		"is_expired":     isExpired,
		"expiry_time":    expiryTime,
		"current_token":  nil,
	}

	if tokenInfo != nil {
		status["current_token"] = map[string]interface{}{
			"token":      tokenInfo.Token,
			"expires_at": tokenInfo.ExpiresAt,
			"issued_at":  tokenInfo.IssuedAt,
			"user_id":    tokenInfo.UserID,
			"login_id":   tokenInfo.LoginID,
		}
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(status)
}

// ForceRenewalHandler handles POST /api/external-token/force-renewal
func (eta *ExternalTokenAPI) ForceRenewalHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	// Force token renewal
	if err := eta.jwtManager.ForceRenewal(); err != nil {
		log.Printf("⚠️ Failed to force token renewal: %v", err)
		http.Error(w, fmt.Sprintf("Failed to force renewal: %v", err), http.StatusInternalServerError)
		return
	}

	response := ExternalTokenResponse{
		Success: true,
		Message: "Token renewal forced successfully",
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(response)

	log.Printf("✅ Token renewal forced successfully")
}

// GetTokenHandler handles GET /api/external-token/get
func (eta *ExternalTokenAPI) GetTokenHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	// Get valid token
	token, err := eta.jwtManager.GetValidToken()
	if err != nil {
		log.Printf("⚠️ Failed to get valid token: %v", err)
		http.Error(w, fmt.Sprintf("Failed to get token: %v", err), http.StatusInternalServerError)
		return
	}

	response := ExternalTokenResponse{
		Success: true,
		Message: "Token retrieved successfully",
		Token:   token,
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(response)
}

// RegisterExternalTokenRoutes registers all external token API routes
func RegisterExternalTokenRoutes(mux *http.ServeMux, jwtManager *JWTManager) {
	api := NewExternalTokenAPI(jwtManager)

	// External token management routes
	mux.HandleFunc("/api/external-token/update", api.UpdateTokenHandler)
	mux.HandleFunc("/api/external-token/status", api.GetTokenStatusHandler)
	mux.HandleFunc("/api/external-token/force-renewal", api.ForceRenewalHandler)
	mux.HandleFunc("/api/external-token/get", api.GetTokenHandler)

	log.Println("✅ External token API routes registered")
}

// WebhookHandler handles incoming webhooks for token updates
func (eta *ExternalTokenAPI) WebhookHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	// Parse webhook payload
	var webhookPayload map[string]interface{}
	if err := json.NewDecoder(r.Body).Decode(&webhookPayload); err != nil {
		log.Printf("⚠️ Failed to decode webhook payload: %v", err)
		http.Error(w, "Invalid JSON", http.StatusBadRequest)
		return
	}

	// Extract token and user info from webhook
	token, ok := webhookPayload["token"].(string)
	if !ok || token == "" {
		http.Error(w, "Token not found in webhook payload", http.StatusBadRequest)
		return
	}

	var userID, loginID int64
	if uid, ok := webhookPayload["user_id"].(float64); ok {
		userID = int64(uid)
	}
	if lid, ok := webhookPayload["login_id"].(float64); ok {
		loginID = int64(lid)
	}

	// Handle external token update
	if err := eta.jwtManager.HandleExternalTokenUpdate(token, userID, loginID); err != nil {
		log.Printf("⚠️ Failed to handle webhook token update: %v", err)
		http.Error(w, fmt.Sprintf("Failed to update token: %v", err), http.StatusInternalServerError)
		return
	}

	response := ExternalTokenResponse{
		Success: true,
		Message: "Webhook token update processed successfully",
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(response)

	log.Printf("✅ Webhook token update processed successfully for user %d, login %d", userID, loginID)
}

// RegisterWebhookRoutes registers webhook routes for external token updates
func RegisterWebhookRoutes(mux *http.ServeMux, jwtManager *JWTManager) {
	api := NewExternalTokenAPI(jwtManager)

	// Webhook routes
	mux.HandleFunc("/webhook/token-update", api.WebhookHandler)

	log.Println("✅ Webhook routes registered")
}
