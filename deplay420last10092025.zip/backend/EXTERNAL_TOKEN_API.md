# External Token Management API

This document describes the external token management functionality that allows external systems to update JWT tokens and handle token regeneration.

## Features

- **External Token Updates**: Accept new tokens from external sources
- **Automatic Token Regeneration**: Handle error 1005 by requesting new tokens
- **Token Expiration Handling**: Automatically regenerate tokens when they expire
- **Webhook Support**: Receive token updates via webhooks
- **Status Monitoring**: Check token status and expiry

## API Endpoints

### 1. Update External Token
**POST** `/api/external-token/update`

Updates the external token used for API calls.

**Request Body:**
```json
{
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user_id": 283617495,
  "login_id": 605354782
}
```

**Response:**
```json
{
  "success": true,
  "message": "External token updated successfully",
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}
```

### 2. Get Token Status
**GET** `/api/external-token/status`

Returns the current token status and information.

**Response:**
```json
{
  "external_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "is_expired": false,
  "expiry_time": "2024-01-15T10:30:00Z",
  "current_token": {
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "expires_at": "2024-01-15T10:30:00Z",
    "issued_at": "2024-01-15T09:30:00Z",
    "user_id": 283617495,
    "login_id": 605354782
  }
}
```

### 3. Force Token Renewal
**POST** `/api/external-token/force-renewal`

Forces immediate token renewal.

**Response:**
```json
{
  "success": true,
  "message": "Token renewal forced successfully"
}
```

### 4. Get Valid Token
**GET** `/api/external-token/get`

Returns a valid JWT token, renewing if necessary.

**Response:**
```json
{
  "success": true,
  "message": "Token retrieved successfully",
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}
```

### 5. Webhook for Token Updates
**POST** `/webhook/token-update`

Webhook endpoint for receiving token updates from external systems.

**Request Body:**
```json
{
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user_id": 283617495,
  "login_id": 605354782
}
```

**Response:**
```json
{
  "success": true,
  "message": "Webhook token update processed successfully"
}
```

## Error Handling

### Error Code 1005 (Too Many Requests)
When the API returns error code 1005, the system will:
1. Log the error
2. Trigger external token regeneration request
3. Retry with exponential backoff
4. Use fallback token if all retries fail

### Token Expiration
When a token expires, the system will:
1. Detect expiration during auto-renewal checks
2. Clear the current token
3. Request external token regeneration
4. Generate a new token using the updated external token

## Configuration

The external token management is configured in the JWT manager with the following settings:

- **Renewal Time**: 10 minutes before expiry
- **Auto-renewal Check**: Every 5 minutes
- **Rate Limiting**: 5 concurrent requests, 5 requests per second
- **Retry Logic**: Exponential backoff with 3 attempts

## Usage Examples

### Update Token via API
```bash
curl -X POST http://localhost:8000/api/external-token/update \
  -H "Content-Type: application/json" \
  -d '{
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "user_id": 283617495,
    "login_id": 605354782
  }'
```

### Check Token Status
```bash
curl http://localhost:8000/api/external-token/status
```

### Force Token Renewal
```bash
curl -X POST http://localhost:8000/api/external-token/force-renewal
```

### Send Webhook Update
```bash
curl -X POST http://localhost:8000/webhook/token-update \
  -H "Content-Type: application/json" \
  -d '{
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "user_id": 283617495,
    "login_id": 605354782
  }'
```

## Implementation Details

### JWT Manager Updates
- Added `externalToken` field to store external token
- Added `externalMutex` for thread-safe external token operations
- Modified `refreshToken()` to use external token for authorization
- Enhanced error handling for code 1005 to trigger regeneration

### Auto-renewal Enhancements
- Added expiration detection in auto-renewal loop
- Implemented `forceTokenRegeneration()` for expired tokens
- Enhanced logging for better debugging

### API Integration
- Added external token management routes
- Implemented webhook support for external updates
- Added comprehensive status monitoring

## Security Considerations

- External tokens are validated for JWT format
- Thread-safe operations with proper mutex usage
- Rate limiting to prevent abuse
- Comprehensive error handling and logging

## Monitoring

The system provides detailed logging for:
- Token updates and renewals
- Error conditions and retries
- External token regeneration requests
- Auto-renewal activities

Monitor the logs for patterns like:
- `✅ External token updated successfully`
- `⚠️ TOO_MANY_REQUESTS (code 1005) → triggering token regeneration`
- `🔄 Forcing complete token regeneration due to expiration`
