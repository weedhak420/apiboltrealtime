// Performance monitoring utilities
interface PerformanceMetric {
  name: string
  value: number
  timestamp: number
  type: 'timing' | 'counter' | 'gauge'
}

interface PerformanceStats {
  apiResponseTime: number[]
  cacheHitRate: number
  errorRate: number
  memoryUsage: number
  activeConnections: number
}

class PerformanceMonitor {
  private metrics: PerformanceMetric[] = []
  private maxMetrics = 1000 // Keep last 1000 metrics
  private cacheHits = 0
  private cacheMisses = 0
  private apiErrors = 0
  private apiRequests = 0

  // Record API response time
  recordApiResponseTime(endpoint: string, duration: number) {
    this.apiRequests++
    this.metrics.push({
      name: `api.${endpoint}.response_time`,
      value: duration,
      timestamp: Date.now(),
      type: 'timing'
    })
    
    this.cleanupMetrics()
  }

  // Record cache hit/miss
  recordCacheHit() {
    this.cacheHits++
    this.metrics.push({
      name: 'cache.hit',
      value: 1,
      timestamp: Date.now(),
      type: 'counter'
    })
  }

  recordCacheMiss() {
    this.cacheMisses++
    this.metrics.push({
      name: 'cache.miss',
      value: 1,
      timestamp: Date.now(),
      type: 'counter'
    })
  }

  // Record API error
  recordApiError(endpoint: string) {
    this.apiErrors++
    this.metrics.push({
      name: `api.${endpoint}.error`,
      value: 1,
      timestamp: Date.now(),
      type: 'counter'
    })
  }

  // Record memory usage
  recordMemoryUsage() {
    if (typeof process !== 'undefined' && process.memoryUsage) {
      const memUsage = process.memoryUsage()
      this.metrics.push({
        name: 'memory.heap_used',
        value: memUsage.heapUsed,
        timestamp: Date.now(),
        type: 'gauge'
      })
      
      this.metrics.push({
        name: 'memory.heap_total',
        value: memUsage.heapTotal,
        timestamp: Date.now(),
        type: 'gauge'
      })
    }
  }

  // Get performance statistics
  getStats(): PerformanceStats {
    const now = Date.now()
    const last5Minutes = now - (5 * 60 * 1000)
    
    // Filter metrics from last 5 minutes
    const recentMetrics = this.metrics.filter(m => m.timestamp > last5Minutes)
    
    // Calculate API response times
    const apiResponseTimes = recentMetrics
      .filter(m => m.name.includes('response_time'))
      .map(m => m.value)
    
    // Calculate cache hit rate
    const totalCacheRequests = this.cacheHits + this.cacheMisses
    const cacheHitRate = totalCacheRequests > 0 ? (this.cacheHits / totalCacheRequests) * 100 : 0
    
    // Calculate error rate
    const errorRate = this.apiRequests > 0 ? (this.apiErrors / this.apiRequests) * 100 : 0
    
    // Get memory usage
    const memoryUsage = typeof process !== 'undefined' && process.memoryUsage 
      ? process.memoryUsage().heapUsed 
      : 0

    return {
      apiResponseTime: apiResponseTimes,
      cacheHitRate,
      errorRate,
      memoryUsage,
      activeConnections: 0 // Would need to track this separately
    }
  }

  // Get metrics for specific time range
  getMetrics(timeRange: number = 300000): PerformanceMetric[] { // 5 minutes default
    const now = Date.now()
    const startTime = now - timeRange
    
    return this.metrics.filter(m => m.timestamp > startTime)
  }

  // Get average response time for endpoint
  getAverageResponseTime(endpoint: string): number {
    const endpointMetrics = this.metrics.filter(
      m => m.name === `api.${endpoint}.response_time`
    )
    
    if (endpointMetrics.length === 0) return 0
    
    const total = endpointMetrics.reduce((sum, m) => sum + m.value, 0)
    return total / endpointMetrics.length
  }

  // Get cache statistics
  getCacheStats() {
    const total = this.cacheHits + this.cacheMisses
    return {
      hits: this.cacheHits,
      misses: this.cacheMisses,
      total,
      hitRate: total > 0 ? (this.cacheHits / total) * 100 : 0
    }
  }

  // Clean up old metrics
  private cleanupMetrics() {
    if (this.metrics.length > this.maxMetrics) {
      // Keep only the most recent metrics
      this.metrics = this.metrics
        .sort((a, b) => b.timestamp - a.timestamp)
        .slice(0, this.maxMetrics)
    }
  }

  // Reset all metrics
  reset() {
    this.metrics = []
    this.cacheHits = 0
    this.cacheMisses = 0
    this.apiErrors = 0
    this.apiRequests = 0
  }

  // Export metrics in Prometheus format
  exportPrometheusMetrics(): string {
    const stats = this.getStats()
    const cacheStats = this.getCacheStats()
    
    let metrics = ''
    
    // API response time
    if (stats.apiResponseTime.length > 0) {
      const avgResponseTime = stats.apiResponseTime.reduce((a, b) => a + b, 0) / stats.apiResponseTime.length
      metrics += `# HELP api_response_time_seconds Average API response time\n`
      metrics += `# TYPE api_response_time_seconds gauge\n`
      metrics += `api_response_time_seconds ${avgResponseTime / 1000}\n`
    }
    
    // Cache hit rate
    metrics += `# HELP cache_hit_rate_percent Cache hit rate percentage\n`
    metrics += `# TYPE cache_hit_rate_percent gauge\n`
    metrics += `cache_hit_rate_percent ${stats.cacheHitRate}\n`
    
    // Error rate
    metrics += `# HELP api_error_rate_percent API error rate percentage\n`
    metrics += `# TYPE api_error_rate_percent gauge\n`
    metrics += `api_error_rate_percent ${stats.errorRate}\n`
    
    // Memory usage
    metrics += `# HELP memory_usage_bytes Memory usage in bytes\n`
    metrics += `# TYPE memory_usage_bytes gauge\n`
    metrics += `memory_usage_bytes ${stats.memoryUsage}\n`
    
    // Cache statistics
    metrics += `# HELP cache_hits_total Total cache hits\n`
    metrics += `# TYPE cache_hits_total counter\n`
    metrics += `cache_hits_total ${cacheStats.hits}\n`
    
    metrics += `# HELP cache_misses_total Total cache misses\n`
    metrics += `# TYPE cache_misses_total counter\n`
    metrics += `cache_misses_total ${cacheStats.misses}\n`
    
    return metrics
  }
}

// Create singleton instance
const performanceMonitor = new PerformanceMonitor()

// Record memory usage every 30 seconds
setInterval(() => {
  performanceMonitor.recordMemoryUsage()
}, 30000)

export default performanceMonitor
export { PerformanceMonitor }
