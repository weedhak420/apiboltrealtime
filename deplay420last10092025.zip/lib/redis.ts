import Redis from "ioredis"

// Redis connection configuration
const REDIS_URL = process.env.REDIS_URL ?? "redis://57.158.24.174:6379/0"

console.log('🔗 Attempting Redis connection to:', REDIS_URL)

// Create Redis client with better error handling
const redis = new Redis(REDIS_URL, {
  retryDelayOnFailover: 100,
  enableReadyCheck: false,
  maxRetriesPerRequest: 3, // Allow more retries for remote server
  lazyConnect: true,
  connectTimeout: 5000, // 5 seconds for remote server
  commandTimeout: 3000,  // 3 seconds for remote server
  retryDelayOnClusterDown: 300,
  retryDelayOnFailover: 100,
  retryOnFailover: true, // Enable retry for remote server
  enableOfflineQueue: true, // Enable queue to handle temporary disconnections
  family: 4, // Force IPv4
  keepAlive: 30000, // Keep connection alive
})

// Track connection status
let isConnected = false
let connectionAttempts = 0
const maxConnectionAttempts = 3 // Allow more attempts for remote server

// Handle Redis connection events
redis.on('error', (err) => {
  connectionAttempts++
  console.warn(`⚠️ Redis connection error (attempt ${connectionAttempts}):`, err.message)
  
  if (connectionAttempts >= maxConnectionAttempts) {
    console.warn('⚠️ Redis connection failed. Continuing without Redis cache.')
    isConnected = false
  }
})

redis.on('connect', () => {
  console.log('✅ Redis connected successfully to:', REDIS_URL)
  isConnected = true
  connectionAttempts = 0
})

redis.on('ready', () => {
  console.log('✅ Redis ready for operations')
  isConnected = true
})

redis.on('close', () => {
  console.log('🔌 Redis connection closed')
  isConnected = false
})

redis.on('reconnecting', () => {
  console.log('🔄 Redis reconnecting...')
  isConnected = false
})

// Test connection on startup with appropriate timeout for remote server
const testConnection = async () => {
  try {
    const result = await Promise.race([
      redis.ping(),
      new Promise((_, reject) => 
        setTimeout(() => reject(new Error('Connection timeout')), 5000)
      )
    ])
    console.log('✅ Redis ping successful:', result)
    isConnected = true
  } catch (err) {
    console.warn('⚠️ Redis ping failed:', err.message)
    console.log('🔄 Continuing without Redis cache - using fallback data only')
    isConnected = false
  }
}

// Test connection after a short delay
setTimeout(testConnection, 500)

// Graceful shutdown
process.on('SIGINT', () => {
  console.log('🛑 Shutting down Redis connection...')
  redis.disconnect()
})

process.on('SIGTERM', () => {
  console.log('🛑 Shutting down Redis connection...')
  redis.disconnect()
})

// Export Redis client with connection status
export default redis
export { isConnected }
