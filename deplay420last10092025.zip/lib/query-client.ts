import { QueryClient } from "@tanstack/react-query"

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 5 * 1000, // 5 seconds
      cacheTime: 30 * 1000, // 30 seconds
      retry: 3,
      retryDelay: (attemptIndex) => Math.min(1000 * 2 ** attemptIndex, 30000),
      refetchOnWindowFocus: false,
      refetchOnReconnect: true,
    },
    mutations: {
      retry: 1,
    },
  },
})

// Query keys for consistent caching
export const QUERY_KEYS = {
  VEHICLES: {
    LATEST: ["vehicles", "latest"] as const,
    HISTORY: (params: any) => ["vehicles", "history", params] as const,
  },
  ANALYTICS: {
    HEATMAP: (params: any) => ["analytics", "heatmap", params] as const,
    TREND: (params: any) => ["analytics", "trend", params] as const,
    HISTORY: (params: any) => ["analytics", "history", params] as const,
  },
} as const
