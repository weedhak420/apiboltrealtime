import redis, { isConnected } from './redis-optimized'
import memoryCache from './memory-cache'

// Hybrid cache system: Redis primary, Memory fallback
class HybridCache {
  private async tryRedis<T>(operation: () => Promise<T>, fallback: () => T): Promise<T> {
    if (!isConnected) {
      console.log('🔄 Redis not connected, using fallback')
      return fallback()
    }

    try {
      return await operation()
    } catch (error) {
      console.warn('⚠️ Redis operation failed, using fallback:', error)
      return fallback()
    }
  }

  async get(key: string): Promise<any | null> {
    // Try Redis first
    const redisValue = await this.tryRedis(
      async () => await redis.get(key),
      () => null
    )

    if (redisValue !== null) {
      console.log(`✅ Redis cache hit: ${key}`)
      return JSON.parse(redisValue)
    }

    // Fallback to memory cache
    const memoryValue = memoryCache.get(key)
    if (memoryValue !== null) {
      console.log(`✅ Memory cache hit: ${key}`)
      return memoryValue
    }

    console.log(`❌ Cache miss: ${key}`)
    return null
  }

  async set(key: string, value: any, ttl: number = 300): Promise<void> {
    const serializedValue = JSON.stringify(value)
    
    // Try Redis first
    await this.tryRedis(
      async () => {
        await redis.setex(key, ttl, serializedValue)
        console.log(`✅ Redis cache set: ${key} (TTL: ${ttl}s)`)
      },
      () => {
        // Fallback to memory cache
        memoryCache.set(key, value, ttl * 1000)
        console.log(`✅ Memory cache set: ${key} (TTL: ${ttl}s)`)
      }
    )
  }

  async delete(key: string): Promise<boolean> {
    let deleted = false

    // Try Redis first
    await this.tryRedis(
      async () => {
        const result = await redis.del(key)
        deleted = result > 0
        if (deleted) {
          console.log(`✅ Redis cache deleted: ${key}`)
        }
      },
      () => {
        // Fallback to memory cache
        deleted = memoryCache.delete(key)
      }
    )

    return deleted
  }

  async clear(): Promise<void> {
    // Clear both Redis and memory cache
    await this.tryRedis(
      async () => {
        await redis.flushdb()
        console.log('✅ Redis cache cleared')
      },
      () => {
        memoryCache.clear()
        console.log('✅ Memory cache cleared')
      }
    )
  }

  // Get cache statistics
  getStats() {
    const memoryStats = memoryCache.getStats()
    
    return {
      redis: {
        connected: isConnected,
        status: isConnected ? 'active' : 'disconnected'
      },
      memory: memoryStats,
      hybrid: {
        totalItems: memoryStats.total,
        hitRate: 'N/A', // Would need to track hits/misses
        status: isConnected ? 'redis-primary' : 'memory-fallback'
      }
    }
  }

  // Health check
  async healthCheck(): Promise<{
    redis: boolean
    memory: boolean
    status: 'healthy' | 'degraded' | 'unhealthy'
  }> {
    const redisHealthy = isConnected
    const memoryHealthy = memoryCache.size() >= 0 // Memory cache is always available
    
    let status: 'healthy' | 'degraded' | 'unhealthy'
    
    if (redisHealthy && memoryHealthy) {
      status = 'healthy'
    } else if (memoryHealthy) {
      status = 'degraded' // Redis down, but memory cache works
    } else {
      status = 'unhealthy' // Both down
    }

    return {
      redis: redisHealthy,
      memory: memoryHealthy,
      status
    }
  }
}

// Create singleton instance
const hybridCache = new HybridCache()

export default hybridCache
export { HybridCache }
