import Redis from "ioredis"

// Redis connection configuration
const REDIS_URL = process.env.REDIS_URL ?? "redis://57.158.24.174:6379/0"

console.log('🔗 Attempting optimized Redis connection to:', REDIS_URL)

// Create optimized Redis client
const redis = new Redis(REDIS_URL, {
  // Connection pooling optimization
  maxRetriesPerRequest: 1,           // ลดจาก 3
  retryDelayOnFailover: 100,         // ลดจาก 100
  enableReadyCheck: false,
  lazyConnect: true,
  
  // Timeout optimization
  connectTimeout: 2000,              // ลดจาก 5000ms
  commandTimeout: 1000,              // ลดจาก 3000ms
  
  // Connection pooling
  family: 4,                         // Force IPv4
  keepAlive: 10000,                  // ลดจาก 30000ms
  
  // Circuit breaker
  enableOfflineQueue: false,         // ปิด queue เมื่อ offline
  retryOnFailover: false,            // ปิด retry เมื่อ failover
  retryDelayOnClusterDown: 100,      // ลดจาก 300ms
})

// Track connection status
let isConnected = false
let connectionAttempts = 0
const maxConnectionAttempts = 2 // ลดจาก 3

// Handle Redis connection events
redis.on('error', (err) => {
  connectionAttempts++
  console.warn(`⚠️ Redis connection error (attempt ${connectionAttempts}):`, err.message)
  
  if (connectionAttempts >= maxConnectionAttempts) {
    console.warn('⚠️ Redis connection failed. Continuing without Redis cache.')
    isConnected = false
  }
})

redis.on('connect', () => {
  console.log('✅ Redis connected successfully to:', REDIS_URL)
  isConnected = true
  connectionAttempts = 0
})

redis.on('ready', () => {
  console.log('✅ Redis ready for operations')
  isConnected = true
})

redis.on('close', () => {
  console.log('🔌 Redis connection closed')
  isConnected = false
})

redis.on('reconnecting', () => {
  console.log('🔄 Redis reconnecting...')
  isConnected = false
})

// Optimized connection test with shorter timeout
const testConnection = async () => {
  try {
    const result = await Promise.race([
      redis.ping(),
      new Promise((_, reject) => 
        setTimeout(() => reject(new Error('Connection timeout')), 2000) // ลดจาก 5000ms
      )
    ])
    console.log('✅ Redis ping successful:', result)
    isConnected = true
  } catch (err) {
    console.warn('⚠️ Redis ping failed:', err.message)
    console.log('🔄 Continuing without Redis cache - using fallback data only')
    isConnected = false
  }
}

// Test connection after a short delay
setTimeout(testConnection, 200) // ลดจาก 500ms

// Graceful shutdown
process.on('SIGINT', () => {
  console.log('🛑 Shutting down Redis connection...')
  redis.disconnect()
})

process.on('SIGTERM', () => {
  console.log('🛑 Shutting down Redis connection...')
  redis.disconnect()
})

// Export Redis client with connection status
export default redis
export { isConnected }
