import redis, { isConnected } from "./redis"

// Cache configuration
export const CACHE_KEYS = {
  VEHICLES_LATEST: "vehicles_latest_cache",
  HEATMAP: "heatmap_cache", 
  TREND: "trend_cache",
  VEHICLES_HISTORY: "vehicles_history_cache",
  ANALYTICS_HISTORY: "analytics_history_cache"
} as const

export const CACHE_TTL = {
  VEHICLES_LATEST: 30,    // 30 seconds for real-time data
  HEATMAP: 60,            // 60 seconds for analytics
  TREND: 60,              // 60 seconds for analytics
  VEHICLES_HISTORY: 300,  // 5 minutes for historical data
  ANALYTICS_HISTORY: 300  // 5 minutes for historical data
} as const

// Cache utility functions
export class CacheManager {
  static async get<T>(key: string): Promise<T | null> {
    try {
      const cached = await Promise.race([
        redis.get(key),
        new Promise((_, reject) => 
          setTimeout(() => reject(new Error('Cache get timeout')), 2000)
        )
      ])
      
      if (cached) {
        console.log(`✅ Cache hit for key: ${key}`)
        return JSON.parse(cached as string)
      }
      console.log(`❌ Cache miss for key: ${key}`)
      return null
    } catch (error) {
      // Handle specific Redis connection errors gracefully
      if (error.message.includes('Stream isn\'t writeable') || 
          error.message.includes('Connection is closed') ||
          error.message.includes('Cache get timeout')) {
        console.log(`⚠️ Redis temporarily unavailable for key: ${key}, skipping cache`)
        return null
      }
      console.warn(`⚠️ Failed to get cache for key ${key}:`, error.message)
      return null
    }
  }

  static async set(key: string, data: any, ttl: number): Promise<boolean> {
    try {
      await Promise.race([
        redis.set(key, JSON.stringify(data), "EX", ttl),
        new Promise((_, reject) => 
          setTimeout(() => reject(new Error('Cache set timeout')), 2000)
        )
      ])
      console.log(`✅ Cache set for key: ${key} (TTL: ${ttl}s)`)
      return true
    } catch (error) {
      // Handle specific Redis connection errors gracefully
      if (error.message.includes('Stream isn\'t writeable') || 
          error.message.includes('Connection is closed') ||
          error.message.includes('Cache set timeout')) {
        console.log(`⚠️ Redis temporarily unavailable for key: ${key}, skipping cache set`)
        return false
      }
      console.warn(`⚠️ Failed to set cache for key ${key}:`, error.message)
      return false
    }
  }

  static async del(key: string): Promise<boolean> {
    try {
      await redis.del(key)
      return true
    } catch (error) {
      console.warn(`⚠️ Failed to delete cache for key ${key}:`, error)
      return false
    }
  }

  static async clearAll(): Promise<boolean> {
    try {
      await redis.flushdb()
      console.log("✅ All cache cleared")
      return true
    } catch (error) {
      console.warn("⚠️ Failed to clear all cache:", error)
      return false
    }
  }

  static async getStats(): Promise<{
    connected: boolean
    keys: number
    memory: string
  }> {
    try {
      const info = await redis.info("memory")
      const keys = await redis.dbsize()
      
      return {
        connected: true,
        keys,
        memory: info
      }
    } catch (error) {
      return {
        connected: false,
        keys: 0,
        memory: "Unknown"
      }
    }
  }
}

// Cache warming function for high-load scenarios
export async function warmCache() {
  console.log("🔥 Warming cache for high-load scenarios...")
  
  try {
    // Pre-populate cache with fallback data if empty
    const keys = Object.values(CACHE_KEYS)
    
    for (const key of keys) {
      const exists = await redis.exists(key)
      if (!exists) {
        console.log(`🔄 Pre-warming cache for ${key}...`)
        // This would be called by individual endpoints
        // when they detect cache miss
      }
    }
    
    console.log("✅ Cache warming completed")
  } catch (error) {
    console.warn("⚠️ Cache warming failed:", error)
  }
}

// Cache invalidation strategies
export class CacheInvalidation {
  static async invalidateVehicles() {
    await CacheManager.del(CACHE_KEYS.VEHICLES_LATEST)
    console.log("🗑️ Vehicles cache invalidated")
  }

  static async invalidateAnalytics() {
    await CacheManager.del(CACHE_KEYS.HEATMAP)
    await CacheManager.del(CACHE_KEYS.TREND)
    await CacheManager.del(CACHE_KEYS.ANALYTICS_HISTORY)
    // Also invalidate interval-specific trend caches
    await CacheManager.del("trend_cache_hour")
    await CacheManager.del("trend_cache_day")
    console.log("🗑️ Analytics cache invalidated")
  }

  static async invalidateHistory() {
    await CacheManager.del(CACHE_KEYS.VEHICLES_HISTORY)
    await CacheManager.del(CACHE_KEYS.ANALYTICS_HISTORY)
    console.log("🗑️ History cache invalidated")
  }
}
