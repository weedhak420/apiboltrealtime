import { 
  Vehicle, 
  VehicleHistoryResponse, 
  AnalyticsHistory, 
  HeatmapResponse, 
  TrendResponse, 
  LatestVehiclesResponse 
} from "@/types/vehicles"

export async function fetchLatestVehicles(): Promise<LatestVehiclesResponse> {
  const response = await fetch("/api/vehicles/latest", { 
    cache: "no-store",
    headers: {
      'Content-Type': 'application/json',
    }
  })
  
  if (!response.ok) {
    throw new Error(`Failed to fetch latest vehicles: ${response.status}`)
  }
  
  return response.json()
}

export async function fetchVehicleHistory(params: {
  vehicle_id?: string
  limit?: number
  start_time?: string
  end_time?: string
}): Promise<VehicleHistoryResponse> {
  const searchParams = new URLSearchParams()
  
  if (params.vehicle_id) searchParams.set("vehicle_id", params.vehicle_id)
  if (params.limit) searchParams.set("limit", String(params.limit))
  if (params.start_time) searchParams.set("start_time", params.start_time)
  if (params.end_time) searchParams.set("end_time", params.end_time)
  
  const response = await fetch(`/api/vehicles/history?${searchParams.toString()}`, { 
    cache: "no-store",
    headers: {
      'Content-Type': 'application/json',
    }
  })
  
  if (!response.ok) {
    throw new Error(`Failed to fetch vehicle history: ${response.status}`)
  }
  
  return response.json()
}

export async function fetchAnalyticsHistory(params: {
  start?: string
  end?: string
  vehicle_id?: string
  bbox?: string
  limit?: number
  offset?: number
  grid?: number
  stop_min_sec?: number
  stop_max_move_m?: number
}): Promise<AnalyticsHistory> {
  const searchParams = new URLSearchParams()
  
  Object.entries(params).forEach(([key, value]) => {
    if (value !== undefined && value !== null) {
      searchParams.set(key, String(value))
    }
  })
  
  const response = await fetch(`/api/analytics/history?${searchParams.toString()}`, { 
    cache: "no-store",
    headers: {
      'Content-Type': 'application/json',
    }
  })
  
  if (!response.ok) {
    throw new Error(`Failed to fetch analytics history: ${response.status}`)
  }
  
  return response.json()
}

export async function fetchHeatmap(limit: number = 50): Promise<HeatmapResponse> {
  const response = await fetch(`/api/analytics/heatmap?limit=${limit}`, { 
    cache: "no-store",
    headers: {
      'Content-Type': 'application/json',
    }
  })
  
  if (!response.ok) {
    throw new Error(`Failed to fetch heatmap: ${response.status}`)
  }
  
  return response.json()
}

export async function fetchTrend(interval: "hour" | "day" = "hour"): Promise<TrendResponse> {
  const response = await fetch(`/api/analytics/trend?interval=${interval}`, { 
    cache: "no-store",
    headers: {
      'Content-Type': 'application/json',
    }
  })
  
  if (!response.ok) {
    throw new Error(`Failed to fetch trend: ${response.status}`)
  }
  
  return response.json()
}

export async function fetchJWTStatus(): Promise<any> {
  const response = await fetch("/api/jwt/status", { 
    cache: "no-store",
    headers: {
      'Content-Type': 'application/json',
    }
  })
  
  if (!response.ok) {
    throw new Error(`Failed to fetch JWT status: ${response.status}`)
  }
  
  return response.json()
}

export async function fetchHealth(): Promise<any> {
  const response = await fetch("/api/health", { 
    cache: "no-store",
    headers: {
      'Content-Type': 'application/json',
    }
  })
  
  if (!response.ok) {
    throw new Error(`Failed to fetch health: ${response.status}`)
  }
  
  return response.json()
}

export async function fetchPerformance(): Promise<any> {
  const response = await fetch("/api/performance", { 
    cache: "no-store",
    headers: {
      'Content-Type': 'application/json',
    }
  })
  
  if (!response.ok) {
    throw new Error(`Failed to fetch performance: ${response.status}`)
  }
  
  return response.json()
}
