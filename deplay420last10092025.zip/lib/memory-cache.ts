// In-memory cache fallback when Redis is unavailable
interface CacheItem {
  value: any
  expiry: number
}

class MemoryCache {
  private cache = new Map<string, CacheItem>()
  private maxSize = 1000 // Maximum number of items
  private defaultTTL = 300000 // 5 minutes in milliseconds

  set(key: string, value: any, ttl: number = this.defaultTTL): void {
    // Remove oldest items if cache is full
    if (this.cache.size >= this.maxSize) {
      const firstKey = this.cache.keys().next().value
      this.cache.delete(firstKey)
    }

    const expiry = Date.now() + ttl
    this.cache.set(key, { value, expiry })
    
    console.log(`💾 Memory cache set: ${key} (TTL: ${ttl}ms)`)
  }

  get(key: string): any | null {
    const item = this.cache.get(key)
    
    if (!item) {
      console.log(`❌ Memory cache miss: ${key}`)
      return null
    }

    if (Date.now() > item.expiry) {
      this.cache.delete(key)
      console.log(`⏰ Memory cache expired: ${key}`)
      return null
    }

    console.log(`✅ Memory cache hit: ${key}`)
    return item.value
  }

  delete(key: string): boolean {
    const deleted = this.cache.delete(key)
    if (deleted) {
      console.log(`🗑️ Memory cache deleted: ${key}`)
    }
    return deleted
  }

  clear(): void {
    this.cache.clear()
    console.log('🧹 Memory cache cleared')
  }

  size(): number {
    return this.cache.size
  }

  // Clean up expired items
  cleanup(): void {
    const now = Date.now()
    let cleaned = 0
    
    for (const [key, item] of this.cache.entries()) {
      if (now > item.expiry) {
        this.cache.delete(key)
        cleaned++
      }
    }
    
    if (cleaned > 0) {
      console.log(`🧹 Memory cache cleanup: removed ${cleaned} expired items`)
    }
  }

  // Get cache statistics
  getStats() {
    const now = Date.now()
    let expired = 0
    let active = 0
    
    for (const item of this.cache.values()) {
      if (now > item.expiry) {
        expired++
      } else {
        active++
      }
    }
    
    return {
      total: this.cache.size,
      active,
      expired,
      maxSize: this.maxSize
    }
  }
}

// Create singleton instance
const memoryCache = new MemoryCache()

// Cleanup expired items every 5 minutes
setInterval(() => {
  memoryCache.cleanup()
}, 300000)

export default memoryCache
export { MemoryCache }
