# คู่มือการติดตั้ง Bolt Taxi Tracker ด้วย Docker บน Ubuntu 22

## 🐳 ข้อดีของการใช้ Docker

- **ง่ายต่อการติดตั้ง**: ไม่ต้องติดตั้ง dependencies หลายตัว
- **Isolated Environment**: แยก environment แต่ละ service
- **Easy Scaling**: ขยายระบบได้ง่าย
- **Easy Backup**: backup และ restore ง่าย
- **Consistent**: ทำงานเหมือนกันทุก environment

## 📋 ข้อกำหนดระบบ

- **OS**: Ubuntu 22.04 LTS
- **RAM**: อย่างน้อย 4GB (แนะนำ 8GB+)
- **Storage**: อย่างน้อย 20GB
- **Docker**: 20.10+
- **Docker Compose**: 2.0+

## 🚀 ขั้นตอนการติดตั้ง

### 1. ติดตั้ง Docker และ Docker Compose

```bash
# อัปเดตระบบ
sudo apt update && sudo apt upgrade -y

# ติดตั้ง dependencies
sudo apt install -y apt-transport-https ca-certificates curl gnupg lsb-release

# เพิ่ม Docker GPG key
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /usr/share/keyrings/docker-archive-keyring.gpg

# เพิ่ม Docker repository
echo "deb [arch=amd64 signed-by=/usr/share/keyrings/docker-archive-keyring.gpg] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

# ติดตั้ง Docker
sudo apt update
sudo apt install -y docker-ce docker-ce-cli containerd.io docker-compose-plugin

# เพิ่ม user เข้า docker group
sudo usermod -aG docker $USER
newgrp docker

# ตรวจสอบการติดตั้ง
docker --version
docker compose version
```

### 2. Clone โปรเจค

```bash
# สร้างโฟลเดอร์โปรเจค
mkdir -p /opt/bolt-tracker
cd /opt/bolt-tracker

# Clone repository
git clone https://github.com/your-username/boltapilastver004.git .
```

### 3. สร้างไฟล์ Docker Configuration

#### docker-compose.yml

```yaml
version: '3.8'

services:
  # Redis Cache
  redis:
    image: redis:7-alpine
    container_name: bolt-redis
    restart: unless-stopped
    ports:
      - "6379:6379"
    volumes:
      - redis_data:/data
    command: redis-server --appendonly yes
    networks:
      - bolt-network

  # Backend API (Go)
  api:
    build:
      context: ./backend
      dockerfile: Dockerfile
    container_name: bolt-api
    restart: unless-stopped
    ports:
      - "8000:8000"
    environment:
      - REDIS_HOST=redis
      - REDIS_PORT=6379
      - API_PORT=8000
      - CORS_ORIGIN=http://localhost:3000
      - LOG_LEVEL=info
    depends_on:
      - redis
    networks:
      - bolt-network
    volumes:
      - ./backend:/app
      - /var/run/docker.sock:/var/run/docker.sock

  # Frontend (Next.js)
  frontend:
    build:
      context: .
      dockerfile: Dockerfile.frontend
    container_name: bolt-frontend
    restart: unless-stopped
    ports:
      - "3000:3000"
    environment:
      - NODE_ENV=production
      - NEXT_PUBLIC_API_URL=http://localhost:8000
    depends_on:
      - api
    networks:
      - bolt-network
    volumes:
      - ./:/app
      - /app/node_modules

  # Nginx Reverse Proxy
  nginx:
    image: nginx:alpine
    container_name: bolt-nginx
    restart: unless-stopped
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx/nginx.conf:/etc/nginx/nginx.conf
      - ./nginx/ssl:/etc/nginx/ssl
    depends_on:
      - frontend
      - api
    networks:
      - bolt-network

volumes:
  redis_data:

networks:
  bolt-network:
    driver: bridge
```

#### backend/Dockerfile

```dockerfile
FROM golang:1.21-alpine AS builder

WORKDIR /app

# ติดตั้ง dependencies
RUN apk add --no-cache git

# Copy go mod files
COPY go.mod go.sum ./
RUN go mod download

# Copy source code
COPY . .

# Build application
RUN CGO_ENABLED=0 GOOS=linux go build -a -installsuffix cgo -o main .

# Final stage
FROM alpine:latest

RUN apk --no-cache add ca-certificates tzdata

WORKDIR /root/

# Copy binary
COPY --from=builder /app/main .

# Expose port
EXPOSE 8000

# Run application
CMD ["./main"]
```

#### Dockerfile.frontend

```dockerfile
FROM node:20-alpine AS base

# Install dependencies only when needed
FROM base AS deps
RUN apk add --no-cache libc6-compat
WORKDIR /app

# Install dependencies
COPY package.json package-lock.json* ./
RUN npm ci

# Rebuild the source code only when needed
FROM base AS builder
WORKDIR /app
COPY --from=deps /app/node_modules ./node_modules
COPY . .

# Build application
RUN npm run build

# Production image
FROM base AS runner
WORKDIR /app

ENV NODE_ENV production

RUN addgroup --system --gid 1001 nodejs
RUN adduser --system --uid 1001 nextjs

COPY --from=builder /app/public ./public

# Set the correct permission for prerender cache
RUN mkdir .next
RUN chown nextjs:nodejs .next

# Automatically leverage output traces to reduce image size
COPY --from=builder --chown=nextjs:nodejs /app/.next/standalone ./
COPY --from=builder --chown=nextjs:nodejs /app/.next/static ./.next/static

USER nextjs

EXPOSE 3000

ENV PORT 3000

CMD ["node", "server.js"]
```

#### nginx/nginx.conf

```nginx
events {
    worker_connections 1024;
}

http {
    upstream frontend {
        server frontend:3000;
    }

    upstream api {
        server api:8000;
    }

    server {
        listen 80;
        server_name your-domain.com;

        # Frontend
        location / {
            proxy_pass http://frontend;
            proxy_http_version 1.1;
            proxy_set_header Upgrade $http_upgrade;
            proxy_set_header Connection 'upgrade';
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto $scheme;
            proxy_cache_bypass $http_upgrade;
        }

        # API
        location /api/ {
            proxy_pass http://api/;
            proxy_http_version 1.1;
            proxy_set_header Upgrade $http_upgrade;
            proxy_set_header Connection 'upgrade';
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto $scheme;
            proxy_cache_bypass $http_upgrade;
        }
    }
}
```

### 4. สร้างไฟล์ Environment

```bash
# สร้างไฟล์ .env
cat > .env << EOF
# Database
DB_HOST=localhost
DB_PORT=5432
DB_USER=bolt_user
DB_PASSWORD=your_password
DB_NAME=bolt_tracker

# Redis
REDIS_HOST=redis
REDIS_PORT=6379
REDIS_PASSWORD=

# JWT
JWT_SECRET=your_jwt_secret_key_here

# API
API_PORT=8000
CORS_ORIGIN=http://localhost:3000

# Frontend
NEXT_PUBLIC_API_URL=http://localhost:8000
NEXT_PUBLIC_APP_NAME=Bolt Taxi Tracker

# Logging
LOG_LEVEL=info
EOF
```

### 5. Build และรัน Docker Containers

```bash
# Build images
docker compose build

# รัน containers
docker compose up -d

# ตรวจสอบสถานะ
docker compose ps

# ดู logs
docker compose logs -f
```

### 6. ตั้งค่า SSL Certificate

```bash
# ติดตั้ง Certbot
sudo apt install certbot -y

# สร้าง SSL certificate
sudo certbot certonly --standalone -d your-domain.com

# Copy certificates ไปยัง nginx
sudo cp /etc/letsencrypt/live/your-domain.com/fullchain.pem ./nginx/ssl/
sudo cp /etc/letsencrypt/live/your-domain.com/privkey.pem ./nginx/ssl/

# อัปเดต nginx config สำหรับ SSL
cat > nginx/nginx-ssl.conf << 'EOF'
events {
    worker_connections 1024;
}

http {
    upstream frontend {
        server frontend:3000;
    }

    upstream api {
        server api:8000;
    }

    server {
        listen 80;
        server_name your-domain.com;
        return 301 https://$server_name$request_uri;
    }

    server {
        listen 443 ssl http2;
        server_name your-domain.com;

        ssl_certificate /etc/nginx/ssl/fullchain.pem;
        ssl_certificate_key /etc/nginx/ssl/privkey.pem;

        # Frontend
        location / {
            proxy_pass http://frontend;
            proxy_http_version 1.1;
            proxy_set_header Upgrade $http_upgrade;
            proxy_set_header Connection 'upgrade';
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto $scheme;
            proxy_cache_bypass $http_upgrade;
        }

        # API
        location /api/ {
            proxy_pass http://api/;
            proxy_http_version 1.1;
            proxy_set_header Upgrade $http_upgrade;
            proxy_set_header Connection 'upgrade';
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto $scheme;
            proxy_cache_bypass $http_upgrade;
        }
    }
}
EOF

# รีสตาร์ท nginx container
docker compose restart nginx
```

## 🔧 การจัดการระบบ

### ตรวจสอบสถานะ

```bash
# ตรวจสอบ containers
docker compose ps

# ดู logs
docker compose logs -f api
docker compose logs -f frontend
docker compose logs -f nginx
docker compose logs -f redis

# ตรวจสอบ resource usage
docker stats
```

### รีสตาร์ท Services

```bash
# รีสตาร์ท service เดียว
docker compose restart api
docker compose restart frontend

# รีสตาร์ททั้งหมด
docker compose restart

# รีสตาร์ทและ rebuild
docker compose up -d --build
```

### อัปเดตระบบ

```bash
# อัปเดตโค้ด
git pull origin main

# Rebuild และ restart
docker compose down
docker compose up -d --build
```

### Backup และ Restore

```bash
# Backup volumes
docker run --rm -v bolt-tracker_redis_data:/data -v $(pwd):/backup alpine tar czf /backup/redis_backup.tar.gz -C /data .

# Restore volumes
docker run --rm -v bolt-tracker_redis_data:/data -v $(pwd):/backup alpine tar xzf /backup/redis_backup.tar.gz -C /data
```

## 🚨 การแก้ไขปัญหา

### ปัญหา Port ถูกใช้งาน

```bash
# ตรวจสอบ port
sudo netstat -tlnp | grep :80
sudo netstat -tlnp | grep :3000
sudo netstat -tlnp | grep :8000

# ฆ่า process
sudo kill -9 <PID>
```

### ปัญหา Container ไม่เริ่ม

```bash
# ดู logs
docker compose logs api
docker compose logs frontend

# ตรวจสอบ images
docker images

# Rebuild images
docker compose build --no-cache
```

### ปัญหา Memory

```bash
# ตรวจสอบ memory usage
docker stats

# จำกัด memory usage
# แก้ไข docker-compose.yml:
# services:
#   api:
#     deploy:
#       resources:
#         limits:
#           memory: 512M
```

## 📊 การตรวจสอบประสิทธิภาพ

```bash
# ตรวจสอบ resource usage
docker stats

# ตรวจสอบ logs
docker compose logs --tail=100 -f

# ตรวจสอบ network
docker network ls
docker network inspect bolt-tracker_bolt-network
```

## 🔐 การตั้งค่าความปลอดภัย

### ตั้งค่า Firewall

```bash
# เปิดใช้งาน UFW
sudo ufw enable

# อนุญาต SSH
sudo ufw allow ssh

# อนุญาต HTTP และ HTTPS
sudo ufw allow 80
sudo ufw allow 443

# ตรวจสอบสถานะ
sudo ufw status
```

### ตั้งค่า Auto Backup

```bash
# สร้าง backup script
cat > backup.sh << 'EOF'
#!/bin/bash
DATE=$(date +%Y%m%d_%H%M%S)

# Backup volumes
docker run --rm -v bolt-tracker_redis_data:/data -v $(pwd):/backup alpine tar czf /backup/redis_backup_$DATE.tar.gz -C /data .

# Backup code
tar -czf code_backup_$DATE.tar.gz --exclude=node_modules --exclude=.git .

# ลบ backup เก่า (เก็บ 7 วัน)
find . -name "*_backup_*.tar.gz" -mtime +7 -delete
EOF

chmod +x backup.sh

# ตั้งค่า cron
crontab -e
# เพิ่มบรรทัด:
# 0 2 * * * /opt/bolt-tracker/backup.sh
```

## ✅ การตรวจสอบการติดตั้ง

1. **ตรวจสอบ Frontend**: เปิด `http://your-domain.com`
2. **ตรวจสอบ API**: เปิด `http://your-domain.com/api/status`
3. **ตรวจสอบ Redis**: `docker exec bolt-redis redis-cli ping`
4. **ตรวจสอบ Containers**: `docker compose ps`

## 🚀 การขยายระบบ (Scaling)

### Horizontal Scaling

```yaml
# แก้ไข docker-compose.yml
services:
  api:
    # ... existing config ...
    deploy:
      replicas: 3
      
  frontend:
    # ... existing config ...
    deploy:
      replicas: 2
```

### Load Balancing

```nginx
# แก้ไข nginx/nginx.conf
upstream api {
    server api_1:8000;
    server api_2:8000;
    server api_3:8000;
}

upstream frontend {
    server frontend_1:3000;
    server frontend_2:3000;
}
```

## 📞 การสนับสนุน

หากมีปัญหาการติดตั้ง กรุณาติดต่อ:
- Email: support@bolt-tracker.com
- GitHub Issues: https://github.com/your-username/boltapilastver004/issues

---

**หมายเหตุ**: แทนที่ `your-domain.com` ด้วย domain จริงของคุณ และปรับแต่งการตั้งค่าตามความต้องการของระบบ
