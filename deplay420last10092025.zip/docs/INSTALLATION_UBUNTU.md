# คู่มือการติดตั้ง Bolt Taxi Tracker บน Ubuntu 22 Server

## 📋 ข้อกำหนดระบบ

- **OS**: Ubuntu 22.04 LTS
- **RAM**: อย่างน้อย 4GB (แนะนำ 8GB+)
- **Storage**: อย่างน้อย 20GB
- **CPU**: 2 cores ขึ้นไป
- **Network**: Internet connection

## 🚀 ขั้นตอนการติดตั้ง

### 1. อัปเดตระบบ

```bash
sudo apt update && sudo apt upgrade -y
```

### 2. ติดตั้ง Dependencies

```bash
# ติดตั้ง Node.js 20.x
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs

# ติดตั้ง Go 1.21+
wget https://go.dev/dl/go1.21.5.linux-amd64.tar.gz
sudo tar -C /usr/local -xzf go1.21.5.linux-amd64.tar.gz
echo 'export PATH=$PATH:/usr/local/go/bin' >> ~/.bashrc
source ~/.bashrc

# ติดตั้ง Redis
sudo apt install redis-server -y
sudo systemctl enable redis-server
sudo systemctl start redis-server

# ติดตั้ง Git
sudo apt install git -y

# ติดตั้ง Build tools
sudo apt install build-essential -y
```

### 3. ตั้งค่า Redis

```bash
# แก้ไข Redis config
sudo nano /etc/redis/redis.conf

# เปลี่ยนบรรทัด:
# bind 127.0.0.1 ::1
# เป็น:
# bind 0.0.0.0

# รีสตาร์ท Redis
sudo systemctl restart redis-server
```

### 4. Clone โปรเจค

```bash
# สร้างโฟลเดอร์โปรเจค
mkdir -p /opt/bolt-tracker
cd /opt/bolt-tracker

# Clone repository
git clone https://github.com/your-username/boltapilastver004.git .
# หรือใช้ SSH: git clone git@github.com:your-username/boltapilastver004.git .
```

### 5. ติดตั้ง Backend (Go API)

```bash
cd backend

# ติดตั้ง dependencies
go mod tidy

# สร้างไฟล์ .env
cat > .env << EOF
# Database
DB_HOST=localhost
DB_PORT=5432
DB_USER=bolt_user
DB_PASSWORD=your_password
DB_NAME=bolt_tracker

# Redis
REDIS_HOST=localhost
REDIS_PORT=6379
REDIS_PASSWORD=

# JWT
JWT_SECRET=your_jwt_secret_key_here

# API
API_PORT=8000
CORS_ORIGIN=http://localhost:3000

# Logging
LOG_LEVEL=info
EOF

# Build และรัน
go build -o bolt-api main.go
./bolt-api
```

### 6. ติดตั้ง Frontend (Next.js)

```bash
cd ../

# ติดตั้ง dependencies
npm install

# สร้างไฟล์ .env.local
cat > .env.local << EOF
# API Configuration
NEXT_PUBLIC_API_URL=http://localhost:8000
NEXT_PUBLIC_APP_NAME=Bolt Taxi Tracker

# Development
NODE_ENV=production
EOF

# Build production
npm run build

# รัน production server
npm start
```

### 7. ตั้งค่า Nginx (Reverse Proxy)

```bash
# ติดตั้ง Nginx
sudo apt install nginx -y

# สร้างไฟล์ config
sudo nano /etc/nginx/sites-available/bolt-tracker

# ใส่เนื้อหาดังนี้:
cat > /tmp/nginx-config << 'EOF'
server {
    listen 80;
    server_name your-domain.com;  # เปลี่ยนเป็น domain ของคุณ

    # Frontend (Next.js)
    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }

    # Backend API
    location /api/ {
        proxy_pass http://localhost:8000/;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}
EOF

sudo cp /tmp/nginx-config /etc/nginx/sites-available/bolt-tracker

# Enable site
sudo ln -s /etc/nginx/sites-available/bolt-tracker /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

### 8. ตั้งค่า SSL Certificate (Let's Encrypt)

```bash
# ติดตั้ง Certbot
sudo apt install certbot python3-certbot-nginx -y

# สร้าง SSL certificate
sudo certbot --nginx -d your-domain.com

# ตั้งค่า auto-renewal
sudo crontab -e
# เพิ่มบรรทัด:
# 0 12 * * * /usr/bin/certbot renew --quiet
```

### 9. ตั้งค่า Systemd Services

#### Backend Service

```bash
sudo nano /etc/systemd/system/bolt-api.service

# ใส่เนื้อหาดังนี้:
cat > /tmp/bolt-api.service << 'EOF'
[Unit]
Description=Bolt API Server
After=network.target

[Service]
Type=simple
User=www-data
WorkingDirectory=/opt/bolt-tracker/backend
ExecStart=/opt/bolt-tracker/backend/bolt-api
Restart=always
RestartSec=5
Environment=NODE_ENV=production

[Install]
WantedBy=multi-user.target
EOF

sudo cp /tmp/bolt-api.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable bolt-api
sudo systemctl start bolt-api
```

#### Frontend Service

```bash
sudo nano /etc/systemd/system/bolt-frontend.service

# ใส่เนื้อหาดังนี้:
cat > /tmp/bolt-frontend.service << 'EOF'
[Unit]
Description=Bolt Frontend Server
After=network.target

[Service]
Type=simple
User=www-data
WorkingDirectory=/opt/bolt-tracker
ExecStart=/usr/bin/npm start
Restart=always
RestartSec=5
Environment=NODE_ENV=production

[Install]
WantedBy=multi-user.target
EOF

sudo cp /tmp/bolt-frontend.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable bolt-frontend
sudo systemctl start bolt-frontend
```

### 10. ตั้งค่า Firewall

```bash
# เปิดใช้งาน UFW
sudo ufw enable

# อนุญาต SSH
sudo ufw allow ssh

# อนุญาต HTTP และ HTTPS
sudo ufw allow 80
sudo ufw allow 443

# อนุญาต API port (ถ้าต้องการเข้าถึงโดยตรง)
sudo ufw allow 8000

# ตรวจสอบสถานะ
sudo ufw status
```

### 11. ตั้งค่า Database (PostgreSQL - Optional)

```bash
# ติดตั้ง PostgreSQL
sudo apt install postgresql postgresql-contrib -y

# สร้าง database และ user
sudo -u postgres psql
CREATE DATABASE bolt_tracker;
CREATE USER bolt_user WITH PASSWORD 'your_password';
GRANT ALL PRIVILEGES ON DATABASE bolt_tracker TO bolt_user;
\q

# แก้ไข pg_hba.conf
sudo nano /etc/postgresql/14/main/pg_hba.conf
# เพิ่มบรรทัด:
# local   bolt_tracker   bolt_user   md5

# รีสตาร์ท PostgreSQL
sudo systemctl restart postgresql
```

### 12. ตั้งค่า Monitoring

```bash
# ติดตั้ง htop สำหรับ monitoring
sudo apt install htop -y

# ตรวจสอบ services
sudo systemctl status bolt-api
sudo systemctl status bolt-frontend
sudo systemctl status nginx
sudo systemctl status redis-server
```

## 🔧 การจัดการระบบ

### ตรวจสอบสถานะ Services

```bash
# ตรวจสอบสถานะ
sudo systemctl status bolt-api
sudo systemctl status bolt-frontend
sudo systemctl status nginx
sudo systemctl status redis-server

# ดู logs
sudo journalctl -u bolt-api -f
sudo journalctl -u bolt-frontend -f
```

### รีสตาร์ท Services

```bash
# รีสตาร์ท backend
sudo systemctl restart bolt-api

# รีสตาร์ท frontend
sudo systemctl restart bolt-frontend

# รีสตาร์ท nginx
sudo systemctl restart nginx
```

### อัปเดตระบบ

```bash
# อัปเดตโค้ด
cd /opt/bolt-tracker
git pull origin main

# อัปเดต backend
cd backend
go mod tidy
go build -o bolt-api main.go
sudo systemctl restart bolt-api

# อัปเดต frontend
cd ../
npm install
npm run build
sudo systemctl restart bolt-frontend
```

## 🚨 การแก้ไขปัญหา

### ปัญหา Port ถูกใช้งาน

```bash
# ตรวจสอบ port ที่ใช้งาน
sudo netstat -tlnp | grep :3000
sudo netstat -tlnp | grep :8000

# ฆ่า process
sudo kill -9 <PID>
```

### ปัญหา Permission

```bash
# แก้ไข permission
sudo chown -R www-data:www-data /opt/bolt-tracker
sudo chmod -R 755 /opt/bolt-tracker
```

### ปัญหา Memory

```bash
# ตรวจสอบ memory usage
free -h
htop

# เพิ่ม swap (ถ้าจำเป็น)
sudo fallocate -l 2G /swapfile
sudo chmod 600 /swapfile
sudo mkswap /swapfile
sudo swapon /swapfile
```

## 📊 การตรวจสอบประสิทธิภาพ

```bash
# ตรวจสอบ CPU และ Memory
htop

# ตรวจสอบ Disk usage
df -h

# ตรวจสอบ Network
sudo netstat -tlnp

# ตรวจสอบ Logs
sudo journalctl -u bolt-api --since "1 hour ago"
sudo journalctl -u bolt-frontend --since "1 hour ago"
```

## 🔐 การตั้งค่าความปลอดภัย

### ตั้งค่า Fail2Ban

```bash
sudo apt install fail2ban -y
sudo systemctl enable fail2ban
sudo systemctl start fail2ban
```

### ตั้งค่า Auto Backup

```bash
# สร้าง backup script
sudo nano /opt/backup.sh

# ใส่เนื้อหา:
#!/bin/bash
DATE=$(date +%Y%m%d_%H%M%S)
tar -czf /opt/backup_$DATE.tar.gz /opt/bolt-tracker
find /opt -name "backup_*.tar.gz" -mtime +7 -delete

# ตั้งค่า cron
sudo crontab -e
# เพิ่มบรรทัด:
# 0 2 * * * /opt/backup.sh
```

## ✅ การตรวจสอบการติดตั้ง

1. **ตรวจสอบ Frontend**: เปิด `http://your-domain.com`
2. **ตรวจสอบ API**: เปิด `http://your-domain.com/api/status`
3. **ตรวจสอบ Redis**: `redis-cli ping`
4. **ตรวจสอบ Services**: `sudo systemctl status bolt-api bolt-frontend nginx`

## 📞 การสนับสนุน

หากมีปัญหาการติดตั้ง กรุณาติดต่อ:
- Email: support@bolt-tracker.com
- GitHub Issues: https://github.com/your-username/boltapilastver004/issues

---

**หมายเหตุ**: แทนที่ `your-domain.com` ด้วย domain จริงของคุณ และปรับแต่งการตั้งค่าตามความต้องการของระบบ
