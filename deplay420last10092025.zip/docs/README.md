# Bolt Taxi Tracker

A real-time taxi tracking dashboard for monitoring Bolt vehicles in Chiang Mai, Thailand.

## Features

- 🗺️ **Live Vehicle Map** - Real-time vehicle tracking with interactive map
- 📊 **Analytics Dashboard** - Heatmap hotspots and trend analysis
- 🔧 **System Monitoring** - Health checks and performance metrics
- 🌐 **Bilingual Support** - English and Thai language support

## Getting Started

### Prerequisites

- Go 1.21 or higher
- Node.js 18 or higher
- MySQL database
- Redis (optional, for caching)

### 1. Start the Go API Backend

First, make sure your Go API server is running:

\`\`\`bash
# Navigate to the project directory
cd boltapilastver

# Run the Go API server
go run *.go
\`\`\`

The API will start on `http://localhost:8000`

### 2. Start the Next.js Frontend

In a new terminal:

\`\`\`bash
# Install dependencies (first time only)
npm install

# Start the development server
npm run dev
\`\`\`

The frontend will be available at `http://localhost:3000`

## Configuration

### Environment Variables

Create a `.env.local` file if you need to customize the API URL:

\`\`\`env
NEXT_PUBLIC_API_URL=http://localhost:8000
\`\`\`

### Go API Configuration

Edit `config.json` to configure:
- Database connection
- Redis connection
- API endpoints
- Monitoring locations
- Update intervals

## Project Structure

\`\`\`
boltapilastver/
├── app/                    # Next.js app directory
│   ├── api/               # API routes (proxy to Go backend)
│   ├── analytics/         # Analytics page
│   ├── system/            # System monitoring page
│   └── page.tsx           # Dashboard home page
├── components/            # React components
│   ├── dashboard-layout.tsx
│   ├── live-map.tsx
│   ├── stats-overview.tsx
│   ├── analytics-charts.tsx
│   └── system-status.tsx
├── *.go                   # Go backend files
├── config.json            # Go API configuration
└── README.md
\`\`\`

## API Endpoints

The Go backend provides these endpoints:

- `GET /api/vehicles/latest` - Get latest vehicle data
- `GET /api/analytics/heatmap` - Get heatmap hotspots
- `GET /api/analytics/trend` - Get vehicle trends
- `GET /api/health` - Health check
- `GET /api/performance` - Performance metrics
- `GET /api/status` - API status

## Troubleshooting

### "Go API Not Connected" Error

If you see this error in the dashboard:

1. Make sure the Go API is running: `go run *.go`
2. Check that it's accessible at `http://localhost:8000`
3. Verify your database and Redis connections in `config.json`

### CORS Errors

The frontend uses Next.js API routes to proxy requests to the Go backend, avoiding CORS issues. Make sure you're accessing the frontend through `http://localhost:3000` and not directly opening the HTML files.

## Technologies Used

- **Frontend**: Next.js 15, React, TypeScript, Tailwind CSS
- **Backend**: Go, Gin framework
- **Database**: MySQL
- **Cache**: Redis
- **UI Components**: shadcn/ui

## License

MIT
