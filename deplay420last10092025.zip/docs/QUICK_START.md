# 🚀 Quick Start - Bolt Taxi Tracker

## ⚡ การติดตั้งแบบเร็ว (5 นาที)

### วิธีที่ 1: Docker (แนะนำ)

```bash
# 1. Clone โปรเจค
git clone https://github.com/your-username/boltapilastver004.git
cd boltapilastver004

# 2. รันด้วย Docker
docker compose up -d

# 3. เปิดเว็บไซต์
# Frontend: http://localhost:3000
# API: http://localhost:8000
```

### วิธีที่ 2: Manual Installation

```bash
# 1. ติดตั้ง Node.js และ Go
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs

# 2. ติดตั้ง Redis
sudo apt install redis-server -y
sudo systemctl start redis-server

# 3. Clone และติดตั้ง
git clone https://github.com/your-username/boltapilastver004.git
cd boltapilastver004

# 4. ติดตั้ง Frontend
npm install
npm run build
npm start &

# 5. ติดตั้ง Backend
cd backend
go mod tidy
go run main.go &
```

## 🎯 Features หลัก

- ✅ **Real-time Vehicle Tracking**: ติดตามรถแบบเรียลไทม์
- ✅ **Interactive Maps**: แผนที่แบบ interactive พร้อม clustering
- ✅ **Analytics Dashboard**: วิเคราะห์ข้อมูลการเดินทาง
- ✅ **History Tracking**: ประวัติการเดินทาง
- ✅ **Performance Optimized**: โหลดเร็ว smooth animations
- ✅ **Responsive Design**: รองรับทุกอุปกรณ์

## 🔧 Configuration

### Environment Variables

```bash
# API Configuration
NEXT_PUBLIC_API_URL=http://localhost:8000
NEXT_PUBLIC_APP_NAME=Bolt Taxi Tracker

# Backend Configuration
REDIS_HOST=localhost
REDIS_PORT=6379
API_PORT=8000
CORS_ORIGIN=http://localhost:3000
```

### Database Setup (Optional)

```bash
# PostgreSQL
sudo apt install postgresql -y
sudo -u postgres createdb bolt_tracker
sudo -u postgres createuser bolt_user
```

## 📱 การใช้งาน

### 1. Live Map
- ดูรถทั้งหมดแบบเรียลไทม์
- Clustering สำหรับประสิทธิภาพ
- Zoom และ Pan แบบ smooth

### 2. History Analysis
- เลือกรถและช่วงเวลา
- ดูเส้นทางการเดินทาง
- วิเคราะห์ข้อมูลการเดินทาง

### 3. Analytics Dashboard
- สถิติการใช้งาน
- กราฟการวิเคราะห์
- Heatmap ของพื้นที่

## 🚨 การแก้ไขปัญหา

### Port ถูกใช้งาน
```bash
sudo lsof -i :3000
sudo lsof -i :8000
sudo kill -9 <PID>
```

### Redis Connection Error
```bash
sudo systemctl restart redis-server
redis-cli ping
```

### Build Error
```bash
rm -rf node_modules package-lock.json
npm install
npm run build
```

## 📊 Performance Tips

### 1. Optimize Map Performance
- ใช้ clustering สำหรับรถจำนวนมาก
- จำกัด zoom level
- ใช้ canvas rendering

### 2. Optimize API Performance
- ใช้ Redis caching
- จำกัด API response size
- ใช้ connection pooling

### 3. Optimize Frontend Performance
- ใช้ dynamic imports
- ใช้ lazy loading
- ใช้ service workers

## 🔐 Security

### Basic Security
```bash
# ตั้งค่า firewall
sudo ufw enable
sudo ufw allow ssh
sudo ufw allow 80
sudo ufw allow 443

# ตั้งค่า SSL
sudo apt install certbot -y
sudo certbot --nginx -d your-domain.com
```

### Advanced Security
```bash
# ตั้งค่า fail2ban
sudo apt install fail2ban -y
sudo systemctl enable fail2ban

# ตั้งค่า auto updates
sudo apt install unattended-upgrades -y
sudo dpkg-reconfigure -plow unattended-upgrades
```

## 📈 Monitoring

### System Monitoring
```bash
# ตรวจสอบ CPU และ Memory
htop

# ตรวจสอบ Disk usage
df -h

# ตรวจสอบ Network
sudo netstat -tlnp
```

### Application Monitoring
```bash
# ตรวจสอบ logs
tail -f /var/log/nginx/access.log
tail -f /var/log/nginx/error.log

# ตรวจสอบ API health
curl http://localhost:8000/api/status
```

## 🚀 Production Deployment

### 1. Domain Setup
```bash
# ตั้งค่า DNS
# A record: your-domain.com -> server-ip
# CNAME: www.your-domain.com -> your-domain.com
```

### 2. SSL Certificate
```bash
# ติดตั้ง SSL
sudo certbot --nginx -d your-domain.com
```

### 3. Performance Optimization
```bash
# ตั้งค่า Nginx caching
# ตั้งค่า Gzip compression
# ตั้งค่า CDN (ถ้าต้องการ)
```

## 📞 Support

### Documentation
- [Installation Guide](INSTALLATION_UBUNTU.md)
- [Docker Guide](DOCKER_INSTALLATION.md)
- [API Documentation](backend/API_DOCS.md)

### Contact
- Email: support@bolt-tracker.com
- GitHub: https://github.com/your-username/boltapilastver004
- Issues: https://github.com/your-username/boltapilastver004/issues

---

**Happy Tracking! 🚗💨**
