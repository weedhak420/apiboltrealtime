# Bolt Taxi Tracker Frontend

## 🚀 Quick Start

### 1. Install Dependencies
```bash
npm install
```

### 2. Start Development Server
```bash
npm run dev
```

### 3. Access the Application
- **Main Dashboard**: http://localhost:3000
- **Live Map**: http://localhost:3000/map
- **History & Analytics**: http://localhost:3000/history
- **System Status**: http://localhost:3000/status

## 🔧 Backend Integration

### Option 1: With Go Backend (Recommended)
1. Start your Go API server on port 8000
2. The frontend will automatically connect and use real-time data
3. WebSocket support for live updates

### Option 2: Standalone Mode (Fallback)
- The application works without the Go backend
- Uses fallback data for demonstration
- All features are functional with sample data

## 📊 Features

### Real-time Vehicle Tracking
- **Animated markers** with bearing rotation
- **WebSocket support** with polling fallback
- **Dynamic animations** based on timestamp differences
- **Jump detection** for unrealistic movements

### History & Analytics
- **Route visualization** with polylines
- **Speed and distance charts**
- **Bearing distribution** (compass rose)
- **Vehicle hotspots** analysis
- **Time-based filtering**

### Performance Features
- **EMA smoothing** to reduce GPS jitter
- **RequestAnimationFrame** for smooth animations
- **Dynamic icon sizing** based on zoom level
- **Efficient chart rendering**

## 🛠️ Configuration

### Environment Variables
```bash
# Backend API URL (optional)
NEXT_PUBLIC_API_URL=http://localhost:8000

# WebSocket URL (optional)
NEXT_PUBLIC_WS_URL=ws://localhost:8000
```

### API Endpoints
The frontend provides these API routes:
- `/api/vehicles/latest` - Real-time vehicle data
- `/api/vehicles/history` - Historical vehicle records
- `/api/analytics/heatmap` - Vehicle hotspots
- `/api/analytics/trend` - Time-based trends
- `/api/analytics/history` - Comprehensive analytics

## 🎯 Usage

### Live Map
1. Navigate to `/map`
2. See real-time vehicle positions
3. Click markers for vehicle details
4. WebSocket connection status shown in UI

### History Analysis
1. Go to `/history`
2. Filter by vehicle ID and time range
3. View route on map
4. Analyze charts and statistics

### System Status
1. Visit `/status`
2. Check backend connectivity
3. Monitor API response times
4. View configuration details

## 🔍 Troubleshooting

### Backend Connection Issues
- Check if Go server is running on port 8000
- Verify firewall settings
- Check system status page for details

### WebSocket Issues
- Application automatically falls back to polling
- Check browser console for connection errors
- Ensure WebSocket URL is correct

### Performance Issues
- Reduce animation duration in settings
- Limit data points in charts
- Check browser developer tools for memory usage

## 📱 Browser Support
- Chrome/Edge (recommended)
- Firefox
- Safari
- Mobile browsers (responsive design)

## 🎨 Customization

### Vehicle Markers
- Edit `styles/vehicle-marker.css` for animations
- Modify `components/animated-vehicle-marker.tsx` for behavior
- Update `public/car.svg` for fallback icon

### Charts
- Customize in `components/history-charts.tsx`
- Modify colors and styling
- Add new chart types

### API Integration
- Update `lib/api.ts` for new endpoints
- Modify `types/vehicles.ts` for data structures
- Add new API routes in `app/api/`

## 🚀 Production Deployment

### Build for Production
```bash
npm run build
npm start
```

### Environment Setup
```bash
# Production API URL
NEXT_PUBLIC_API_URL=https://your-api-domain.com
NEXT_PUBLIC_WS_URL=wss://your-api-domain.com
```

### Performance Optimization
- Enable gzip compression
- Use CDN for static assets
- Configure caching headers
- Monitor bundle size

## 📚 API Documentation

The frontend integrates with the Go backend API documented in `API_DOCS.md`. Key endpoints:

- **Real-time**: `GET /api/vehicles/latest`
- **History**: `GET /api/vehicles/history`
- **Analytics**: `GET /api/analytics/history`
- **Heatmap**: `GET /api/analytics/heatmap`
- **Trends**: `GET /api/analytics/trend`
- **WebSocket**: `ws://localhost:8000/socket.io/`

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## 📄 License

This project is part of the Bolt Taxi Tracker system.
